"""CBF / imgCIF adapter.

Deliberately a byte-level scanner, not a CIF parser
====================================================

Signing must never round-trip the file through a parser and a serialiser.  A
parser normalises whitespace, reorders items, rewrites number formats and
silently drops what it does not understand -- and every one of those is a
place where "the bytes I signed" and "the bytes on disk" quietly diverge.  So
this module locates byte ranges and never rewrites the file except by
appending.

That also means no dependency on CBFlib/pycbf.  A verifier that a referee or a
journal can build from source in thirty seconds is worth more than one that
needs a working crystallographic toolchain.

Format facts this relies on (CBF/imgCIF spec, IT Vol. G ch. 2.3)
----------------------------------------------------------------

* A binary section opens with the boundary ``--CIF-BINARY-FORMAT-SECTION--``
  on its own line, followed by RFC 822-style MIME headers, a blank line, then
  the four-octet sequence ``0C 1A 04 D5`` (Ctrl-L, Ctrl-Z, Ctrl-D, flag).
* ``X-Binary-Size`` gives the octet count of the (possibly compressed) data,
  excluding the 8-byte compression bookkeeping prefix.
* The section closes with ``\\n--CIF-BINARY-FORMAT-SECTION----\\n;``.
* Headers may be folded onto continuation lines beginning with whitespace --
  ``Content-Type`` with its ``conversions=`` parameter usually is.
"""

from __future__ import annotations

import base64
import re
import struct
from typing import Dict, Iterator, List, Optional, Tuple

from .base import FormatAdapter, FormatError, FrameLayout, Payload

__all__ = ["CbfAdapter", "BLOCK_MARKER", "decode_byte_offset"]

BOUNDARY = b"--CIF-BINARY-FORMAT-SECTION--"
END_BOUNDARY = b"--CIF-BINARY-FORMAT-SECTION----"
START_OF_BIN = b"\x0c\x1a\x04\xd5"

#: The signature block is introduced by a CIF comment line, so a CIF reader
#: that knows nothing about framesig skips it.  It is always the file's
#: suffix, which makes "the signed range" a prefix -- the simplest possible
#: rule for an independent verifier to implement.
BLOCK_MARKER = b"###FRAMESIG-BLOCK-V1"

_ELEMENT_TYPES = {
    "signed 8-bit integer": ("int", 1, True),
    "unsigned 8-bit integer": ("int", 1, False),
    "signed 16-bit integer": ("int", 2, True),
    "unsigned 16-bit integer": ("int", 2, False),
    "signed 32-bit integer": ("int", 4, True),
    "unsigned 32-bit integer": ("int", 4, False),
    "signed 64-bit integer": ("int", 8, True),
    "unsigned 64-bit integer": ("int", 8, False),
    "signed 32-bit real IEEE": ("real", 4, True),
    "signed 64-bit real IEEE": ("real", 8, True),
}

_VALUE_CHUNK = 16384


# --------------------------------------------------------------------------
# decompression
# --------------------------------------------------------------------------

def decode_byte_offset(buf: bytes, n_elements: Optional[int] = None) -> Iterator[List[int]]:
    """Decode ``X-CBF_BYTE_OFFSET``, yielding chunks of integer values.

    Delta coding with an escape ladder: an int8 delta, escaping to int16 via
    -128, to int32 via -32768, to int64 via -2**31.  Yields in chunks so a
    2500x2500 frame does not materialise six million Python ints at once.
    """
    out: List[int] = []
    value = 0
    i = 0
    n = len(buf)
    produced = 0
    while i < n:
        if n_elements is not None and produced >= n_elements:
            break
        d = buf[i]
        i += 1
        if d != 0x80:
            delta = d - 256 if d > 127 else d
        else:
            if i + 2 > n:
                raise FormatError("truncated byte-offset stream at 16-bit escape")
            delta = int.from_bytes(buf[i : i + 2], "little", signed=True)
            i += 2
            if delta == -32768:
                if i + 4 > n:
                    raise FormatError("truncated byte-offset stream at 32-bit escape")
                delta = int.from_bytes(buf[i : i + 4], "little", signed=True)
                i += 4
                if delta == -2147483648:
                    if i + 8 > n:
                        raise FormatError("truncated byte-offset stream at 64-bit escape")
                    delta = int.from_bytes(buf[i : i + 8], "little", signed=True)
                    i += 8
        value += delta
        out.append(value)
        produced += 1
        if len(out) >= _VALUE_CHUNK:
            yield out
            out = []
    if out:
        yield out
    if n_elements is not None and produced != n_elements:
        raise FormatError(
            f"byte-offset stream decoded {produced} values, header declares {n_elements}"
        )


def _decode_byte_offset_np(np, buf: bytes, n_elements: Optional[int]):
    """``decode_byte_offset`` as one int64 array, or None to take the slow path.

    Runs of int8 deltas between 0x80 escapes are one ``frombuffer`` each;
    only the escapes (Bragg peaks, a few per cent of pixels) cost a Python
    step. A 64-bit escape returns None: the pure-Python decoder then raises
    on int64 overflow exactly as before. Without one, |sum| <= len(buf)/7 * 2**31,
    which cannot overflow int64 below ~30 GB of stream.
    """
    parts, esc = [], []
    i, n, produced = 0, len(buf), 0
    while i < n and (n_elements is None or produced < n_elements):
        j = buf.find(b"\x80", i)
        if j < 0:
            j = n
        if n_elements is not None:
            j = min(j, i + n_elements - produced)
        if j > i:
            if esc:
                parts.append(np.array(esc, np.int64))
                esc = []
            parts.append(np.frombuffer(buf, np.int8, j - i, i))
            produced += j - i
            i = j
            continue
        if i + 3 > n:
            raise FormatError("truncated byte-offset stream at 16-bit escape")
        delta = int.from_bytes(buf[i + 1 : i + 3], "little", signed=True)
        i += 3
        if delta == -32768:
            if i + 4 > n:
                raise FormatError("truncated byte-offset stream at 32-bit escape")
            delta = int.from_bytes(buf[i : i + 4], "little", signed=True)
            i += 4
            if delta == -2147483648:
                return None
        esc.append(delta)
        produced += 1
    if esc:
        parts.append(np.array(esc, np.int64))
    if n_elements is not None and produced != n_elements:
        raise FormatError(
            f"byte-offset stream decoded {produced} values, header declares {n_elements}"
        )
    if not parts:
        return np.zeros(0, np.int64)
    return np.cumsum(np.concatenate([p.astype(np.int64) for p in parts]))


def _iter_raw_ints(buf: bytes, width: int, signed: bool, little: bool,
                   n_elements: Optional[int]) -> Iterator[List[int]]:
    order = "little" if little else "big"
    total = len(buf) // width
    if n_elements is not None:
        total = min(total, n_elements)
    for base in range(0, total, _VALUE_CHUNK):
        stop = min(base + _VALUE_CHUNK, total)
        yield [
            int.from_bytes(buf[k * width : (k + 1) * width], order, signed=signed)
            for k in range(base, stop)
        ]


# --------------------------------------------------------------------------
# MIME header scanning
# --------------------------------------------------------------------------

def _parse_mime_headers(data: bytes, pos: int) -> Tuple[Dict[str, str], int]:
    """Parse RFC 822-style headers with folding.  Returns (headers, next_pos)."""
    headers: Dict[str, str] = {}
    current_key: Optional[str] = None
    while True:
        nl = data.find(b"\n", pos)
        if nl < 0:
            raise FormatError("unterminated MIME header block in binary section")
        line = data[pos:nl].rstrip(b"\r")
        pos = nl + 1
        if not line.strip():
            return headers, pos
        if line[:1] in (b" ", b"\t"):
            if current_key is None:
                raise FormatError("MIME continuation line with no preceding header")
            headers[current_key] += " " + line.strip().decode("ascii", "replace")
            continue
        if b":" not in line:
            raise FormatError(f"malformed MIME header line {line[:60]!r}")
        key, _, val = line.partition(b":")
        current_key = key.strip().decode("ascii", "replace").lower()
        headers[current_key] = val.strip().decode("ascii", "replace")


def _conversion_of(content_type: str) -> str:
    m = re.search(r'conversions\s*=\s*"?([A-Za-z0-9_\-]+)"?', content_type, re.I)
    return m.group(1).lower() if m else "none"


def _int_header(headers: Dict[str, str], key: str) -> Optional[int]:
    raw = headers.get(key)
    if raw is None:
        return None
    m = re.search(r"-?\d+", raw)
    return int(m.group(0)) if m else None


# --------------------------------------------------------------------------
# adapter
# --------------------------------------------------------------------------

class CbfAdapter(FormatAdapter):
    name = "cbf"
    supports_embedding = True
    profile = "cbf/1"

    def sniff(self, data: bytes) -> bool:
        head = data[:4096]
        return head.startswith(b"###CBF:") or BOUNDARY in data[: 1 << 20]

    # -- signature block placement -----------------------------------------

    def _find_block(self, data: bytes) -> Optional[int]:
        """Offset of the signature block, or None.

        Uses the *last* start-of-line occurrence of the marker.  Binary payload
        bytes could in principle contain the marker sequence; the manifest
        additionally records ``signed_length``, and verification rejects a block
        whose recorded length disagrees with its offset, so a planted marker
        cannot shift the signed range.
        """
        needle = b"\n" + BLOCK_MARKER
        idx = data.rfind(needle)
        if idx >= 0:
            return idx + 1
        if data.startswith(BLOCK_MARKER):
            return 0
        return None

    def strip(self, data: bytes) -> bytes:
        off = self._find_block(data)
        return data if off is None else data[:off]

    def embed(self, data: bytes, block: bytes) -> bytes:
        base = self.strip(data)
        if base and not base.endswith(b"\n"):
            raise FormatError(
                "internal error: base must be newline-terminated before embedding"
            )
        return base + block

    @staticmethod
    def normalise_base(data: bytes) -> bytes:
        """The bytes that get signed: stripped, and newline-terminated.

        Terminating the newline *before* signing rather than after is the whole
        trick -- otherwise appending the block would change the last line of the
        signed region.
        """
        if data and not data.endswith(b"\n"):
            return data + b"\n"
        return data

    # -- structure ----------------------------------------------------------

    def parse(self, data: bytes) -> FrameLayout:
        block_offset = self._find_block(data)
        body_end = len(data) if block_offset is None else block_offset
        payloads = list(self._scan_binary_sections(data, body_end))
        # The skeleton digest elides payload ranges in order, so anything other
        # than strictly ascending, non-overlapping ranges would corrupt it.
        previous = 0
        for p in payloads:
            if p.start < previous or p.end < p.start:
                raise FormatError(
                    f"binary payload {p.id!r} has an invalid byte range "
                    f"({p.start}..{p.end})"
                )
            previous = p.end
        return FrameLayout(
            profile=self.profile,
            signed_length=body_end,
            payloads=payloads,
            block_offset=block_offset,
            block_bytes=None if block_offset is None else data[block_offset:],
        )

    def _scan_binary_sections(self, data: bytes, limit: int) -> Iterator[Payload]:
        pos = 0
        seq = 0
        while pos < limit:
            i = data.find(BOUNDARY, pos, limit)
            if i < 0:
                return
            # END_BOUNDARY is BOUNDARY + "--", so distinguish them explicitly.
            if data[i : i + len(END_BOUNDARY)] == END_BOUNDARY:
                pos = i + len(END_BOUNDARY)
                continue
            nl = data.find(b"\n", i)
            if nl < 0:
                raise FormatError("binary section boundary is not newline-terminated")
            headers, hdr_end = _parse_mime_headers(data, nl + 1)

            sob = data.find(START_OF_BIN, hdr_end, limit)
            if sob < 0:
                raise FormatError("binary section has no START_OF_BIN marker")
            start = sob + len(START_OF_BIN)

            size = _int_header(headers, "x-binary-size")
            if size is None:
                # Tolerated fallback: some minimal writers omit X-Binary-Size.
                close = data.find(b"\n" + END_BOUNDARY, start, limit)
                if close < 0:
                    raise FormatError(
                        "binary section has neither X-Binary-Size nor a closing boundary"
                    )
                end = close
                padding = 0
            else:
                if size < 0:
                    # Without this the payload range comes out inverted
                    # (end < start), which then silently hashes an empty slice
                    # and reports a corrupt file as intact.
                    raise FormatError(f"X-Binary-Size {size} is negative")
                end = start + size
                padding = _int_header(headers, "x-binary-size-padding") or 0
                if padding < 0:
                    raise FormatError(f"X-Binary-Size-Padding {padding} is negative")
                if end > limit:
                    raise FormatError(
                        f"X-Binary-Size {size} runs past the end of the file"
                    )
                # A section whose closing boundary is missing means the file was
                # truncated after the payload.  Without this check the payload
                # parses as complete and a truncated frame can verify.
                if data.find(b"\n" + END_BOUNDARY, end, limit) < 0:
                    raise FormatError(
                        "binary section is not terminated by a closing boundary; "
                        "the file appears to be truncated"
                    )

            seq += 1
            n_declared = _int_header(headers, "x-binary-number-of-elements")
            if n_declared is not None:
                if n_declared < 0:
                    raise FormatError(
                        f"X-Binary-Number-of-Elements {n_declared} is negative"
                    )
                # A header field cannot be allowed to size an allocation. Even
                # the densest encoding spends at least one byte per element, so
                # a count larger than the payload is a lie -- and left unchecked
                # it is a one-line denial of service against any viewer that
                # opens the file.
                if n_declared > (end - start):
                    raise FormatError(
                        f"X-Binary-Number-of-Elements {n_declared} exceeds the "
                        f"{end - start}-byte payload; no encoding is that dense"
                    )
            elem = headers.get("x-binary-element-type", "unknown").strip().strip('"')
            byte_order = (
                "big"
                if "big" in headers.get("x-binary-element-byte-order", "").lower()
                else "little"
            )
            dims = [
                d
                for d in (
                    _int_header(headers, "x-binary-size-fastest-dimension"),
                    _int_header(headers, "x-binary-size-second-dimension"),
                    _int_header(headers, "x-binary-size-third-dimension"),
                )
                if d is not None
            ]
            yield Payload(
                id=str(headers.get("x-binary-id", seq)),
                start=start,
                end=end,
                encoding=_conversion_of(headers.get("content-type", "")),
                element_type=elem,
                byte_order=byte_order,
                dimensions=dims,
                n_elements=_int_header(headers, "x-binary-number-of-elements"),
                extra={
                    "content_md5": headers.get("content-md5"),
                    "transfer_encoding": headers.get("content-transfer-encoding"),
                },
            )
            pos = end + padding

    # -- canonical decoded form --------------------------------------------

    def canonical_payload_stream(self, data: bytes, payload: Payload):
        """Decode to a container-independent byte stream.

        Integer arrays canonicalise to **signed 64-bit little-endian**, not to
        their stored width.  That is on purpose: a 16-bit and a 32-bit
        encoding of the same photon counts then produce the same digest, so
        converting Eiger HDF5 to CBF, or recompressing byte-offset to none,
        preserves the pixel digest even though every stored byte changes.
        Real-valued arrays keep their IEEE-754 width, since widening a float
        is not value-preserving in the same clean way.
        """
        raw = data[payload.start : payload.end]
        kind, width, signed = _ELEMENT_TYPES.get(payload.element_type, ("int", 4, True))
        little = payload.byte_order == "little"
        n = payload.n_elements
        if n is None and payload.dimensions:
            n = 1
            for d in payload.dimensions:
                n *= d

        if kind == "real":
            if payload.encoding not in ("none", "x-cbf_none"):
                raise FormatError(
                    f"cannot decode real-valued array with encoding {payload.encoding!r}"
                )
            form = f"ieee754-{width * 8}-le"
            if little:
                return form, iter([raw])
            return form, iter([_swap_widths(raw, width)])

        if payload.encoding in ("x-cbf_byte_offset", "x-cbf-byte-offset"):
            try:
                import numpy as np
            except ImportError:
                np = None
            fast = _decode_byte_offset_np(np, raw, n) if np is not None else None
            if fast is not None:
                return "int64-le", iter([fast.astype("<i8").tobytes()])
            values = decode_byte_offset(raw, n)
        elif payload.encoding in ("none", "x-cbf_none", ""):
            values = _iter_raw_ints(raw, width, signed, little, n)
        else:
            raise FormatError(
                f"unsupported CBF compression {payload.encoding!r}; "
                "supported: x-CBF_BYTE_OFFSET, none"
            )
        return "int64-le", _pack_int64(values)


def make_block(envelope_json: bytes) -> bytes:
    """Wrap an envelope into the appended CBF signature block.

    The result is simultaneously (a) a CIF comment line followed by a legal
    CIF data block, so CIF-aware readers can pick the envelope up as an
    ordinary text field, and (b) a byte-delimited suffix, so a verifier in any
    language can find it with a single ``rfind``.
    """
    payload = base64.b64encode(envelope_json).decode("ascii")
    lines = [payload[i : i + 76] for i in range(0, len(payload), 76)] or [""]
    out = [BLOCK_MARKER, b"data_framesig", b"_framesig.envelope", b";"]
    out += [line.encode("ascii") for line in lines]
    out += [b";", b""]
    return b"\n".join(out)


def read_block(block: bytes) -> bytes:
    """Inverse of :func:`make_block`: return the envelope JSON bytes."""
    if not block.startswith(BLOCK_MARKER):
        raise FormatError("signature block does not start with the framesig marker")
    text = block.decode("ascii", "replace")
    lines = text.splitlines()
    # The block's CIF boilerplate is not covered by the signature -- the reader
    # finds the envelope by its ';' delimiters -- so corrupting it would
    # otherwise pass unnoticed.  It is still corruption, and SPEC 10.2 fixes
    # these two lines verbatim, so say so rather than quietly carrying on.
    for required in ("data_framesig", "_framesig.envelope"):
        if required not in lines:
            raise FormatError(
                f"signature block is missing its {required!r} line; the block is malformed"
            )
    try:
        start = lines.index(";") + 1
        end = lines.index(";", start)
    except ValueError:
        raise FormatError("signature block has no delimited envelope field") from None
    b64 = "".join(line.strip() for line in lines[start:end])
    try:
        return base64.b64decode(b64, validate=True)
    except Exception as exc:
        raise FormatError(f"signature block payload is not valid base64: {exc}") from exc


def _pack_int64(chunks: Iterator[List[int]]) -> Iterator[bytes]:
    for values in chunks:
        yield struct.pack("<%dq" % len(values), *values)


def _swap_widths(raw: bytes, width: int) -> bytes:
    return b"".join(raw[i : i + width][::-1] for i in range(0, len(raw), width))
