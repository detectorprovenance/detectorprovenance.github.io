"""Format adapter interface.

A signature scheme that only understands CBF is a crystallography tool.  The
adapter boundary is what keeps this general: the core knows about *payloads*
(opaque byte ranges that carry the measurement) and a *skeleton* (everything
else, i.e. the metadata), and nothing about detectors or diffraction.

To support a new container, implement :class:`FormatAdapter`.  Nothing in
``manifest.py``, ``keys.py`` or ``pki.py`` changes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterator, List, Optional, Sequence, Tuple

__all__ = ["Payload", "FrameLayout", "FormatAdapter", "FormatError"]


class FormatError(ValueError):
    """The file is not well-formed for this adapter."""


@dataclass
class Payload:
    """One opaque measurement blob inside the container.

    ``start``/``end`` are byte offsets into the file as stored.  ``encoding``
    names the on-disk compression so a verifier can reproduce the decoded
    values; the decoded canonical form is what survives format conversion.
    """

    id: str
    start: int
    end: int
    encoding: str = "none"
    element_type: str = "unknown"
    byte_order: str = "little"
    dimensions: List[int] = field(default_factory=list)
    n_elements: Optional[int] = None
    # Free-form, adapter-specific; recorded in the manifest for diagnostics.
    extra: dict = field(default_factory=dict)

    @property
    def length(self) -> int:
        return self.end - self.start


@dataclass
class FrameLayout:
    """Everything the core needs to know about one container file."""

    profile: str
    #: Bytes ``[0, signed_length)`` are what the signature covers.
    signed_length: int
    payloads: List[Payload] = field(default_factory=list)
    #: Byte offset where an already-present signature block begins, if any.
    block_offset: Optional[int] = None
    #: The raw bytes of an already-present signature block, if any.
    block_bytes: Optional[bytes] = None

    def payload_ranges(self) -> List[Tuple[int, int]]:
        return [(p.start, p.end) for p in self.payloads]


class FormatAdapter:
    """Interface every container adapter implements."""

    name: str = "abstract"
    #: Whether a signature block can live inside the container itself.
    supports_embedding: bool = False

    def sniff(self, data: bytes) -> bool:  # pragma: no cover - interface
        raise NotImplementedError

    def parse(self, data: bytes) -> FrameLayout:  # pragma: no cover - interface
        raise NotImplementedError

    def canonical_payload_stream(
        self, data: bytes, payload: Payload
    ) -> Tuple[str, Iterator[bytes]]:
        """Return ``(canonical_form_name, chunks)`` for the decoded measurement.

        The canonical form is what makes a digest survive re-compression or
        conversion to another container: two files holding the same counts
        produce the same digest even if one is byte-offset compressed and the
        other is not.
        """
        raise NotImplementedError

    def strip(self, data: bytes) -> bytes:
        """Return *data* with any signature block removed, ready for signing."""
        raise NotImplementedError

    def embed(self, data: bytes, block: bytes) -> bytes:  # pragma: no cover
        raise NotImplementedError


def elide_ranges(data: bytes, ranges: Sequence[Tuple[int, int]], marker: bytes) -> Iterator[bytes]:
    """Yield *data* with each byte range replaced by *marker*.

    Used to build the "skeleton" digest: the file with its bulk measurement
    payloads removed, so that a header edit and a pixel edit are
    distinguishable in the verification report rather than collapsing into one
    undifferentiated "file changed".
    """
    pos = 0
    for start, end in sorted(ranges):
        if start < pos:
            raise FormatError("overlapping payload ranges")
        yield data[pos:start]
        yield marker
        pos = end
    yield data[pos:]
