"""Generic adapter: treat the whole file as one opaque payload.

This is the escape hatch that keeps the tool usable outside crystallography
on day one.  It gives byte-exact tamper detection for any file at all -- a
NeXus/HDF5 master file, an electron-microscope MRC stack, a mass spectrum, a
CSV of instrument readings -- at the cost of the two things a real adapter
adds: survival across format conversion, and the ability to say *which part*
of the file changed.

Signatures are always sidecar here, since we cannot append to an arbitrary
container without risking corrupting it.
"""

from __future__ import annotations

from typing import Iterator, Tuple

from .base import FormatAdapter, FrameLayout, Payload

__all__ = ["RawFileAdapter"]


class RawFileAdapter(FormatAdapter):
    name = "raw"
    supports_embedding = False
    profile = "raw/1"

    def sniff(self, data: bytes) -> bool:
        return True  # last resort; the registry tries it last

    def parse(self, data: bytes) -> FrameLayout:
        return FrameLayout(
            profile=self.profile,
            signed_length=len(data),
            payloads=[
                Payload(
                    id="file",
                    start=0,
                    end=len(data),
                    encoding="none",
                    element_type="opaque",
                )
            ],
        )

    def strip(self, data: bytes) -> bytes:
        return data

    @staticmethod
    def normalise_base(data: bytes) -> bytes:
        return data

    def canonical_payload_stream(self, data: bytes, payload: Payload) -> Tuple[str, Iterator[bytes]]:
        return "opaque", iter([data[payload.start : payload.end]])
