"""Container format adapters."""

from __future__ import annotations

from typing import List

from .base import FormatAdapter, FormatError, FrameLayout, Payload, elide_ranges
from .cbf import CbfAdapter
from .rawfile import RawFileAdapter

__all__ = [
    "FormatAdapter",
    "FormatError",
    "FrameLayout",
    "Payload",
    "elide_ranges",
    "CbfAdapter",
    "RawFileAdapter",
    "ADAPTERS",
    "adapter_for",
    "adapter_by_name",
]

#: Ordered most-specific first; RawFileAdapter always matches, so it is last.
ADAPTERS: List[FormatAdapter] = [CbfAdapter(), RawFileAdapter()]


def adapter_for(data: bytes) -> FormatAdapter:
    for adapter in ADAPTERS:
        if adapter.sniff(data):
            return adapter
    raise FormatError("no adapter matched")  # pragma: no cover - Raw always matches


def adapter_by_name(name: str) -> FormatAdapter:
    for adapter in ADAPTERS:
        if adapter.name == name:
            return adapter
    raise FormatError(f"unknown format adapter {name!r}")


def adapter_by_profile(profile: str) -> FormatAdapter:
    for adapter in ADAPTERS:
        if getattr(adapter, "profile", None) == profile:
            return adapter
    raise FormatError(f"unknown profile {profile!r}")
