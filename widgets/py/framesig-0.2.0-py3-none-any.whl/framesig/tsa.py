"""A reference RFC 3161 timestamp authority.

Why the project ships one
-------------------------

Two reasons, and the second is the important one.

**Testing.** RFC 3161 verification cannot be tested against a public TSA: the
test suite would need a network, would be at the mercy of somebody else's
uptime, and could never exercise the failure cases -- a token over the wrong
digest, a TSA certificate with the wrong extended key usage, a backdated
``genTime``. Those are precisely the cases worth testing, and reaching them
requires being able to mint tokens.

**Deployment.** The design asks a detector vendor to run a TSA alongside its
public-key server, and asks a facility to run a second, independent one. That is
a much easier request when there is a working implementation to point at than
when it is a paragraph in a requirements document. A synchrotron can stand this
up without waiting for any vendor firmware cycle -- and the facility timestamp
is the independent one anyway.

What this is not
----------------

It is not a production TSA. A real one needs an audited clock, a key in an HSM,
monotonic serial numbers that survive a restart, an accuracy claim it can
actually honour, and an operational policy someone is answerable for. This has
none of those, and :func:`make_tsa_certificate` marks its certificates under the
framesig arc so a token from it is identifiable as what it is.

What it does get right is the encoding, which is where implementations
usually go wrong: the ``signedAttrs`` set is signed as a universal ``SET OF``
rather than in its ``[0] IMPLICIT`` wire form, and the certificate carries
``id-kp-timeStamping`` as its only extended key usage, marked critical.
"""

from __future__ import annotations

import datetime as _dt
import secrets
from typing import Optional, Sequence

from cryptography import x509

from . import _der as der
from .digest import sha256
from .keys import ALG_ECDSA_P256, ALG_ED25519, Signer
from .oids import timestamp_policy_oid
from .timestamp import (
    OID_ATTR_CONTENT_TYPE,
    OID_ATTR_MESSAGE_DIGEST,
    OID_CT_TSTINFO,
    OID_ECDSA_SHA256,
    OID_ED25519,
    OID_SHA256,
    OID_SIGNED_DATA,
    OID_TIME_STAMPING,
    TimestampError,
)

__all__ = ["make_tsa_certificate", "ReferenceTSA"]


def make_tsa_certificate(
    ca_key,
    ca_cert: x509.Certificate,
    public_key,
    common_name: str,
    org: str,
    days: int = 3650,
) -> x509.Certificate:
    """A certificate that may timestamp and may do nothing else.

    ``id-kp-timeStamping`` alone, marked critical, exactly as RFC 3161 §2.3
    requires. That requirement is what stops a CA's general-purpose key from
    also minting timestamps -- the concrete risk when a vendor runs its TSA on
    the same infrastructure as its key server. Co-locating the service is fine;
    this is what keeps the *key* separate.
    """
    from .pki import _base_builder, _name, _sign_cert

    builder = (
        _base_builder(_name(common_name, org), ca_cert.subject, public_key, days)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            x509.ExtendedKeyUsage([x509.ObjectIdentifier(OID_TIME_STAMPING)]),
            critical=True,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, content_commitment=True, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=False,
                crl_sign=False, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(
            x509.CertificatePolicies([
                x509.PolicyInformation(
                    x509.ObjectIdentifier(timestamp_policy_oid()), policy_qualifiers=None
                )
            ]),
            critical=False,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(public_key), critical=False)
    )
    return _sign_cert(builder, ca_key)


def _algorithm(oid: str) -> bytes:
    """An AlgorithmIdentifier with absent parameters.

    RFC 5754 requires the parameters field to be *absent* for the SHA-2 family,
    not NULL. Both appear in the wild; emitting the one the RFC mandates and
    accepting either when reading is the right way round.
    """
    return der.der_seq(der.der_oid(oid))


class ReferenceTSA:
    """Mints RFC 3161 tokens with a framesig :class:`~framesig.keys.Signer`."""

    def __init__(
        self,
        signer: Signer,
        certificate: x509.Certificate,
        chain: Sequence[x509.Certificate] = (),
        *,
        policy: Optional[str] = None,
        accuracy_seconds: int = 1,
    ):
        self.signer = signer
        self.certificate = certificate
        self.chain = list(chain)
        self.policy = policy or timestamp_policy_oid()
        self.accuracy_seconds = accuracy_seconds

    # -- the signature algorithm identifier -------------------------------
    @property
    def _signature_algorithm(self) -> str:
        if self.signer.algorithm == ALG_ED25519:
            return OID_ED25519
        if self.signer.algorithm == ALG_ECDSA_P256:
            return OID_ECDSA_SHA256
        raise TimestampError(f"cannot timestamp with {self.signer.algorithm}")

    # -- TSTInfo -----------------------------------------------------------
    def _tstinfo(self, digest: bytes, gen_time: _dt.datetime,
                 nonce: Optional[int], serial: int) -> bytes:
        parts = [
            der.der_int(1),
            der.der_oid(self.policy),
            der.der_seq(_algorithm(OID_SHA256), der.der_octet(digest)),
            der.der_int(serial),
            der.der_gentime(gen_time),
        ]
        if self.accuracy_seconds:
            parts.append(der.der_seq(der.der_int(self.accuracy_seconds)))
        if nonce is not None:
            parts.append(der.der_int(nonce))
        return der.der_seq(*parts)

    # -- CMS ---------------------------------------------------------------
    def _signed_attributes(self, tstinfo: bytes) -> bytes:
        """The attributes that actually get signed.

        Returned as a universal ``SET OF``. It travels in the token as
        ``[0] IMPLICIT``, and the difference is the classic CMS trap: sign the
        wire form and the token verifies nowhere.
        """
        return der.der_set(
            der.der_seq(
                der.der_oid(OID_ATTR_CONTENT_TYPE),
                der.der_set(der.der_oid(OID_CT_TSTINFO)),
            ),
            der.der_seq(
                der.der_oid(OID_ATTR_MESSAGE_DIGEST),
                der.der_set(der.der_octet(sha256(tstinfo))),
            ),
        )

    def stamp(
        self,
        digest: bytes,
        *,
        nonce: Optional[int] = None,
        gen_time: Optional[_dt.datetime] = None,
        serial: Optional[int] = None,
    ) -> bytes:
        """Mint a token over *digest* and return the DER ``TimeStampToken``."""
        if len(digest) != 32:
            raise TimestampError(f"expected a 32-byte SHA-256 digest, got {len(digest)}")
        gen_time = gen_time or _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0)
        serial = serial if serial is not None else secrets.randbits(64)

        tstinfo = self._tstinfo(digest, gen_time, nonce, serial)
        signed_attrs = self._signed_attributes(tstinfo)

        from .keys import sign_and_verify

        # Through sign_and_verify like every other signature in the project: a
        # token nobody can verify is worse than a refusal, because it looks like
        # evidence right up until somebody needs it.
        signature = sign_and_verify(self.signer, signed_attrs)

        issuer_and_serial = der.der_seq(
            self.certificate.issuer.public_bytes(),
            der.der_int(self.certificate.serial_number),
        )
        signer_info = der.der_seq(
            der.der_int(1),
            issuer_and_serial,
            _algorithm(OID_SHA256),
            der.retag(der.parse(signed_attrs), der.context(0)),
            _algorithm(self._signature_algorithm),
            der.der_octet(signature),
        )

        from cryptography.hazmat.primitives.serialization import Encoding

        certificates = b"".join(
            c.public_bytes(Encoding.DER) for c in [self.certificate, *self.chain]
        )
        signed_data = der.der_seq(
            der.der_int(3),
            der.der_set(_algorithm(OID_SHA256)),
            der.der_seq(
                der.der_oid(OID_CT_TSTINFO),
                der.explicit(0, der.der_octet(tstinfo)),
            ),
            der.implicit(0, certificates),
            der.der_set(signer_info),
        )
        return der.der_seq(
            der.der_oid(OID_SIGNED_DATA),
            der.explicit(0, signed_data),
        )

    # -- the service surface ----------------------------------------------
    def respond(self, request_der: bytes) -> bytes:
        """Answer a ``TimeStampReq`` with a full ``TimeStampResp``.

        This is the whole protocol surface a facility would expose over HTTP,
        so the round trip is exercised rather than assumed.
        """
        try:
            fields = der.parse(request_der).expect(der.SEQUENCE).children()
            if fields[0].as_int() != 1:
                raise TimestampError("unsupported TimeStampReq version")
            imprint = fields[1].expect(der.SEQUENCE).children()
            if imprint[0].expect(der.SEQUENCE).child(0).as_oid() != OID_SHA256:
                raise TimestampError("only SHA-256 imprints are accepted")
            digest = imprint[1].as_octets()
            nonce = None
            for node in fields[2:]:
                if node.tag == der.INTEGER:
                    nonce = node.as_int()
        except (der.DerError, IndexError, TimestampError) as exc:
            # PKIStatus 2 = rejection, with the reason as PKIFreeText.
            return der.der_seq(
                der.der_seq(
                    der.der_int(2),
                    der.der_seq(der.tlv(der.UTF8_STRING, str(exc).encode("utf-8"))),
                )
            )

        token = self.stamp(digest, nonce=nonce)
        return der.der_seq(der.der_seq(der.der_int(0)), token)
