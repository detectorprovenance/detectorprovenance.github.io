"""Array-HDF5: one n-dimensional array, its axes and metadata, signed in one file.

Why this exists
---------------

CBF covers single diffraction frames. Images, movies, spectra, spectrum images
and 4D-STEM datasets arrive in many proprietary containers, and the open
container they should end up in is HDF5. This module signs such an array
together with its calibrations and metadata, in a NeXus-style layout that
generic HDF5 tools and NeXus readers open directly:

    /entry/data/data            the array, any integer or float type, any rank
    /entry/data/<axis>          one coordinate vector per axis, with @units
    /framesig/metadata          the signed metadata document (UTF-8 JSON bytes)
    /framesig/envelope          the signature (SPEC §6) over a profile array/1 manifest

As in Run-HDF5 (``run_h5.py``) nothing signs HDF5 bytes, because an HDF5 file is
not byte-reproducible. The manifest signs

* the canonical digest of the array values (SPEC §5.2: integers widened to
  int64-le, floats as IEEE-754 little-endian, C order), with the shape and
  element type, and
* the digest of the metadata document exactly as stored.

Reader-facing calibration that HDF5 tools act on -- the axis vectors, their
units, the NXdata attributes -- is derived from the signed metadata and checked
against it on verification, and the file may hold nothing else. A verifier
therefore never shows a value or a calibration that the signature does not
cover.

The metadata document is opaque bytes for the digest, so it may hold floats
(calibrations are floats); the manifest itself stays float-free (SPEC §2).

h5py and numpy are optional dependencies (``pip install framesig[hdf5]``).
"""

from __future__ import annotations

import base64
import hashlib
import json
import math
import os
import pathlib
import re
from typing import List, Optional, Sequence

from . import manifest as _m
from ._canon import canonicalize
from .keys import Signer, sign_and_verify

__all__ = ["ARRAY_SPEC", "PROFILE", "HDF5_MAGIC", "write_array_h5", "verify_array_h5",
           "is_array_h5", "metadata_bytes"]

ARRAY_SPEC = "framesig-array-h5/1"
PROFILE = "array/1"
HDF5_MAGIC = b"\x89HDF\r\n\x1a\n"
DATA = "entry/data/data"
#: deflate, shuffle, fletcher32: built into libhdf5, no plugin library loaded.
_FILTERS = {1, 2, 3}
#: Slabs of about this many bytes are hashed at a time, so a large array is
#: never widened to int64 in memory all at once.
_SLAB_BYTES = 32 * 1024 * 1024

_INT_KINDS = {"i", "u", "b"}


# --------------------------------------------------------------------------
# canonical values (SPEC §5.2)
# --------------------------------------------------------------------------

def canonical_form(dtype) -> str:
    """The SPEC §5.2 form an array of *dtype* is digested in, or raise."""
    if dtype.kind in _INT_KINDS:
        if dtype.kind == "u" and dtype.itemsize >= 8:
            # uint64 does not fit int64; refusing beats wrapping into negatives.
            raise ValueError("uint64 arrays cannot be canonicalised to int64-le")
        return "int64-le"
    if dtype.kind == "f":
        if dtype.itemsize <= 4:
            return "ieee754-32-le"
        if dtype.itemsize == 8:
            return "ieee754-64-le"
    raise ValueError(f"unsupported element type {dtype}; integer or float arrays only")


def _canonical_dtype(form: str) -> str:
    return {"int64-le": "<i8", "ieee754-32-le": "<f4", "ieee754-64-le": "<f8"}[form]


def _slabs(np, array):
    """Yield C-order slabs along the first axis (works for numpy and h5py)."""
    shape = array.shape
    if len(shape) == 0:
        yield np.asarray(array[()]).reshape(1)
        return
    row = max(1, int(np.prod(shape[1:], dtype=np.int64)) * max(array.dtype.itemsize, 8))
    step = max(1, _SLAB_BYTES // row)
    for i in range(0, shape[0], step):
        yield np.asarray(array[i : i + step])


def canonical_digest(np, array) -> str:
    form = canonical_form(array.dtype)
    target = _canonical_dtype(form)
    h = hashlib.sha256()
    for slab in _slabs(np, array):
        # casting="safe": a value that does not fit the canonical type fails
        # here instead of being truncated or wrapped.
        h.update(np.ascontiguousarray(slab.astype(target, casting="safe")).tobytes())
    return "sha256:" + h.hexdigest()


def element_type(dtype) -> str:
    """A plain, byte-order-free name for the signed element type."""
    return "bool" if dtype.kind == "b" else dtype.name


# --------------------------------------------------------------------------
# metadata
# --------------------------------------------------------------------------

def _plain(value):
    """JSON-safe copy of metadata: numpy scalars to Python, non-finite floats
    and anything unrecognised to strings, so the document always serialises."""
    if isinstance(value, dict):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    if hasattr(value, "tolist"):  # numpy scalar or small array
        return _plain(value.tolist())
    if isinstance(value, float):
        return value if math.isfinite(value) else str(value)
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, bytes):
        return base64.b64encode(value).decode("ascii")
    return str(value)


def metadata_bytes(document: dict) -> bytes:
    """Serialise the metadata document once, at signing time.

    Its digest is over these exact bytes, which the file stores verbatim, so
    nothing needs to reproduce the serialisation later.
    """
    return json.dumps(_plain(document), sort_keys=True, ensure_ascii=False,
                      allow_nan=False, separators=(",", ":")).encode("utf-8")


def _axis_names(axes: Sequence[dict]) -> List[str]:
    """HDF5 dataset names for the axis vectors: the axis name made safe, or axis_<i>."""
    names, seen = [], {"data"}
    for i, ax in enumerate(axes):
        name = re.sub(r"[^A-Za-z0-9_]", "_", str(ax.get("name") or "")).strip("_")
        if not name or name in seen:
            name = f"axis_{i}"
        seen.add(name)
        names.append(name)
    return names


def _axis_vector(np, ax: dict):
    """The coordinate vector an axis entry implies: offset + scale * index, float64."""
    return float(ax.get("offset", 0.0)) + float(ax.get("scale", 1.0)) * np.arange(int(ax["size"]), dtype="<f8")


def _default_axes(shape) -> List[dict]:
    return [{"name": f"axis_{i}", "size": int(n), "scale": 1.0, "offset": 0.0, "units": ""}
            for i, n in enumerate(shape)]


# --------------------------------------------------------------------------
# writing
# --------------------------------------------------------------------------

def _h5():
    """h5py and numpy, with HDF5 filter plugins disabled (see ``run_h5._h5``).

    Kept separate from run_h5, which imports multiprocessing: this module also
    runs in a browser (Pyodide), where multiprocessing does not exist.
    """
    os.environ["HDF5_PLUGIN_PRELOAD"] = "::"
    try:
        import h5py
        import numpy as np
    except ImportError as exc:  # pragma: no cover - depends on the install
        raise SystemExit("Array-HDF5 needs h5py and numpy: pip install framesig[hdf5]") from exc
    while h5py.h5pl.size():
        h5py.h5pl.remove(0)
    return h5py, np


def write_array_h5(
    path,
    data,
    signer: Signer,
    *,
    axes: Optional[Sequence[dict]] = None,
    metadata: Optional[dict] = None,
    original_metadata: Optional[dict] = None,
    source: Optional[dict] = None,
    certificates_der: Sequence[bytes] = (),
    claims: Optional[dict] = None,
    attestation: Optional[dict] = None,
    compression: Optional[int] = 1,
) -> dict:
    """Write *data* as a signed Array-HDF5 file at *path*.

    *axes* lists one entry per dimension, slowest first, with ``name``,
    ``size``, ``scale``, ``offset`` and ``units`` (HyperSpy's axis dicts fit
    as they are). *metadata* and *original_metadata* are stored and signed
    as given. *source* describes the file the array came from, for example
    ``{"filename": ..., "sha256": ..., "size": ...}``, so that anyone holding
    the original can check the link.

    Returns ``{"path", "manifest_digest", "shape", "element_type"}``. The file
    is verified before this returns.
    """
    h5py, np = _h5()
    data = np.asarray(data)
    form = canonical_form(data.dtype)
    axes = [dict(ax) for ax in (axes or _default_axes(data.shape))]
    if len(axes) != data.ndim or any(int(ax["size"]) != n for ax, n in zip(axes, data.shape)):
        raise ValueError(f"axes {[ax.get('size') for ax in axes]} do not match the array shape {data.shape}")
    names = _axis_names(axes)
    for ax, name in zip(axes, names):
        ax["dataset"] = name

    document = {"axes": axes, "metadata": metadata or {}, "original_metadata": original_metadata or {}}
    if source:
        document["source"] = source
    meta = metadata_bytes(document)
    signed_axes = json.loads(meta)["axes"]  # what a verifier will read back

    signer_info = {"key_id": signer.key_id, "alg": signer.algorithm}
    if certificates_der:
        from cryptography import x509

        from .pki import subject_string

        signer_info["subject"] = subject_string(x509.load_der_x509_certificate(certificates_der[0]))

    manifest = {
        "spec": _m.SPEC,
        "profile": PROFILE,
        "created": _m.utc_now(),
        "digests": {"metadata": "sha256:" + hashlib.sha256(meta).hexdigest()},
        "payloads": [{
            "id": "data",
            "element_type": element_type(data.dtype),
            "dimensions": [int(n) for n in data.shape],
            "canonical_form": form,
            "canonical": canonical_digest(np, data),
        }],
        "signer": signer_info,
        "software": _m.software(),
    }
    if attestation:
        manifest["attestation"] = attestation
    if claims:
        manifest["claims"] = claims
    manifest_bytes = canonicalize(manifest)
    signature = sign_and_verify(signer, _m.signing_input(manifest_bytes))
    from .keys import public_key_bytes

    envelope = _m.encode_envelope(manifest_bytes, signature, signer.algorithm,
                                  certificates=list(certificates_der),
                                  public_key_der=public_key_bytes(signer.public_key))

    kwargs = {}
    if compression is not None and data.size:
        kwargs = {"compression": "gzip", "compression_opts": compression, "shuffle": True,
                  "chunks": True}
    with h5py.File(path, "w") as h:
        entry = h.create_group("entry")
        entry.attrs["NX_class"] = "NXentry"
        nxdata = entry.create_group("data")
        nxdata.attrs["NX_class"] = "NXdata"
        nxdata.attrs["signal"] = "data"
        nxdata.attrs["axes"] = names
        nxdata.create_dataset("data", data=data, **kwargs)
        for i, (ax, name) in enumerate(zip(signed_axes, names)):
            nxdata.attrs[f"{name}_indices"] = i
            vec = nxdata.create_dataset(name, data=_axis_vector(np, ax))
            vec.attrs["units"] = str(ax.get("units") or "")
        fs = h.create_group("framesig")
        fs.attrs["spec"] = ARRAY_SPEC
        fs.create_dataset("metadata", data=np.frombuffer(meta, dtype=np.uint8))
        fs.create_dataset("envelope", data=json.dumps(envelope))

    check = verify_array_h5(path, public_keys=[signer.public_key])
    if check.status != "valid":
        raise RuntimeError(f"the file just written does not verify: {check.problems}")
    return {"path": str(path), "manifest_digest": _m.manifest_digest(manifest_bytes),
            "shape": list(data.shape), "element_type": element_type(data.dtype)}


# --------------------------------------------------------------------------
# verification
# --------------------------------------------------------------------------

def is_array_h5(path) -> bool:
    """Cheap test: an HDF5 file whose /framesig group declares this spec."""
    with open(path, "rb") as fh:
        if fh.read(8) != HDF5_MAGIC:
            return False
    try:
        h5py, _ = _h5()
        with h5py.File(path, "r") as h:
            link = h.get("framesig", getlink=True)
            return isinstance(link, h5py.HardLink) and h["framesig"].attrs.get("spec") == ARRAY_SPEC
    except (OSError, KeyError, ValueError, TypeError):
        return False


def _check_structure(h5py, h, axis_names: Optional[Sequence[str]]) -> List[str]:
    """Gate run before any value is read. Empty list = clean.

    With *axis_names* None (metadata not yet authenticated) any extra
    datasets under /entry/data are allowed through, but links, storage and
    filters are already enforced; the exact set is checked once the signed
    axis list is known.
    """
    bad: List[str] = []
    fixed = {"entry", "entry/data", DATA, "framesig", "framesig/metadata", "framesig/envelope"}

    def visit(name, link):
        if not isinstance(link, h5py.HardLink):
            bad.append(f"/{name} is a {type(link).__name__}; only hard links are allowed")
        elif name in fixed:
            return
        elif axis_names is None and name.startswith("entry/data/") and name.count("/") == 2:
            return
        elif axis_names is not None and name in {f"entry/data/{a}" for a in axis_names}:
            return
        else:
            bad.append(f"/{name} is not part of an Array-HDF5")

    h.visititems_links(visit)
    if bad:
        return bad  # never follow a soft or external link below
    missing = [n for n in fixed if n not in h]
    if axis_names is not None:
        missing += [f"entry/data/{a}" for a in axis_names if f"entry/data/{a}" not in h]
    if missing:
        return [f"missing /{n}" for n in missing]

    allowed = {"": set(), "entry": {"NX_class"}, "framesig": {"spec"},
               "framesig/metadata": set(), "framesig/envelope": set(), DATA: set()}
    if axis_names is not None:
        allowed["entry/data"] = {"NX_class", "signal", "axes"} | {f"{a}_indices" for a in axis_names}
        for a in axis_names:
            allowed[f"entry/data/{a}"] = {"units"}

    def objects():
        yield "", h
        for name in sorted(fixed) + [f"entry/data/{a}" for a in (axis_names or [])]:
            yield name, h[name]

    for name, obj in objects():
        if name in allowed:
            extra = set(obj.attrs) - allowed[name]
            if extra:
                bad.append(f"/{name} carries unsigned attributes {sorted(extra)}")
        if isinstance(obj, h5py.Dataset):
            if obj.is_virtual:
                bad.append(f"/{name} is a virtual dataset")
            plist = obj.id.get_create_plist()
            if plist.get_external_count():
                bad.append(f"/{name} keeps its data in external files")
            filters = {plist.get_filter(i)[0] for i in range(plist.get_nfilters())}
            if filters - _FILTERS:
                bad.append(f"/{name} uses filters {sorted(filters - _FILTERS)}")
    if not isinstance(h[DATA], h5py.Dataset):
        bad.append(f"/{DATA} is not a dataset")
    return bad


def verify_array_h5(
    path,
    *,
    roots=(),
    public_keys: Sequence[object] = (),
    at_time=None,
    timestamp_roots=(),
):
    """Verify an Array-HDF5 file. Returns a :class:`api.VerificationResult`.

    ``valid``: the signature holds and both the array values and the metadata
    (with every calibration a reader would act on) are the signed ones.
    ``metadata-modified``: the values are intact, the metadata or a derived
    calibration is not. ``tampered``: the values changed, or the file holds
    content the signature does not cover. A malformed or hostile file gives a
    verdict, never an exception.
    """
    from cryptography.exceptions import UnsupportedAlgorithm

    from .api import VerificationResult

    result = VerificationResult(status="invalid")
    try:
        h5py, np = _h5()
        with h5py.File(path, "r") as h:
            _verify_open(h5py, np, h, result, roots, public_keys, at_time, timestamp_roots)
    except (KeyError, TypeError, ValueError, OSError, AttributeError, IndexError,
            UnicodeDecodeError, UnsupportedAlgorithm, _m.EnvelopeError) as exc:
        result.problems.append(f"malformed Array-HDF5: {type(exc).__name__}: {exc}")
        if result.status in ("valid", "metadata-modified"):
            result.status = "tampered" if result.signature_valid else "invalid"
    return result


def _verify_open(h5py, np, h, result, roots, public_keys, at_time, timestamp_roots):
    from .api import _assess_timestamps, _assess_trust, _authenticate_single
    from .attestation import assess_assurance

    problems = result.problems
    if "framesig" not in h:
        result.status = "unsigned"
        problems.append("no signature found: the file has no /framesig group")
        return
    bad = _check_structure(h5py, h, None)
    if bad:
        problems.extend(bad)
        # Content was added or relinked. If the signature itself is still
        # readable through plain hard links, say whether it is genuine: a
        # genuine signature next to unsigned content is "tampered", not
        # "invalid". Nothing else is read from the file.
        if all(isinstance(h.get(n, getlink=True), h5py.HardLink)
               for n in ("framesig", "framesig/envelope")) and \
                isinstance(h["framesig/envelope"], h5py.Dataset):
            envelope = json.loads(h["framesig/envelope"][()])
            _authenticate_single(envelope, list(public_keys), result)
            if result.signature_valid:
                result.status = "tampered"
        return
    if h["framesig"].attrs.get("spec") != ARRAY_SPEC:
        problems.append(f"/framesig@spec is not {ARRAY_SPEC!r}")
        return

    envelope = json.loads(h["framesig/envelope"][()])
    manifest_bytes, certs, signing_key = _authenticate_single(envelope, list(public_keys), result)
    manifest = json.loads(manifest_bytes.decode("utf-8"))
    result.manifest = manifest

    def finish():
        result.trust_status, result.trust = _assess_trust(certs, roots, signing_key, manifest,
                                                         at_time, result)
        result.assurance = assess_assurance(signature_valid=result.signature_valid,
                                            trust_status=result.trust_status,
                                            certificates=certs, manifest=manifest)
        result.time = _assess_timestamps(envelope, certs, timestamp_roots)

    if not result.signature_valid:
        finish()
        return  # status stays "invalid"
    if manifest.get("spec") != _m.SPEC or manifest.get("profile") != PROFILE:
        problems.append(f"manifest is not a {PROFILE} manifest")
        finish()
        return

    # From here the manifest is signed. Bound every read by signed numbers.
    payloads = manifest.get("payloads") or []
    if len(payloads) != 1 or payloads[0].get("id") != "data":
        problems.append("an Array-HDF5 manifest has exactly one payload, 'data'")
        result.status = "tampered"
        finish()
        return
    p = payloads[0]
    ds = h[DATA]
    values_ok = False
    if list(ds.shape) != list(p.get("dimensions", [])):
        problems.append(f"array is {list(ds.shape)}, signed array is {p.get('dimensions')}")
    elif element_type(ds.dtype) != p.get("element_type"):
        problems.append(f"array holds {element_type(ds.dtype)}, signed array is {p.get('element_type')}")
    else:
        try:
            values_ok = (canonical_form(ds.dtype) == p.get("canonical_form")
                         and canonical_digest(np, ds) == p.get("canonical"))
        except ValueError as exc:
            problems.append(str(exc))
        if not values_ok and not problems:
            problems.append("array values differ from the signed values")

    meta = bytes(h["framesig/metadata"][()])
    meta_ok = "sha256:" + hashlib.sha256(meta).hexdigest() == manifest.get("digests", {}).get("metadata")
    result.skeleton_intact = meta_ok
    axes_ok = False
    if not meta_ok:
        problems.append("metadata differs from the signed metadata")
    else:
        document = json.loads(meta)
        axes = document.get("axes", [])
        names = [ax.get("dataset") for ax in axes]
        structure = _check_structure(h5py, h, names)
        if structure:
            problems.extend(structure)
            result.status = "tampered"  # unsigned content a reader would act on
            finish()
            return
        axes_ok = _axes_match(np, h, axes, names, problems)

    result.payload_reports = [{"id": "data", "canonical_ok": values_ok}]
    if not values_ok:
        result.status = "tampered"
    elif not (meta_ok and axes_ok):
        result.status = "metadata-modified"
    else:
        result.status = "valid"
    finish()


def _axes_match(np, h, axes, names, problems) -> bool:
    """The reader-facing calibration must be exactly what the signed metadata implies."""
    nx = h["entry/data"]
    ok = True
    if nx.attrs.get("NX_class") != "NXdata" or nx.attrs.get("signal") != "data":
        problems.append("/entry/data must be NXdata with signal 'data'")
        ok = False
    if h["entry"].attrs.get("NX_class") != "NXentry":
        problems.append("/entry must be NXentry")
        ok = False
    stored_axes = [a.decode() if isinstance(a, bytes) else str(a) for a in np.atleast_1d(nx.attrs.get("axes", []))]
    if stored_axes != names:
        problems.append(f"/entry/data@axes is {stored_axes}, signed axes are {names}")
        ok = False
    if len(axes) != h[DATA].ndim:
        problems.append("signed axes do not match the array rank")
        return False
    for i, (ax, name) in enumerate(zip(axes, names)):
        if int(np.asarray(nx.attrs.get(f"{name}_indices", -1)).reshape(-1)[0]) != i:
            problems.append(f"/entry/data@{name}_indices is not {i}")
            ok = False
        vec = h[f"entry/data/{name}"]
        if vec.shape != (int(ax["size"]),) or vec.dtype != np.dtype("<f8"):
            problems.append(f"/entry/data/{name} has the wrong shape or type")
            ok = False
        elif not np.array_equal(vec[()], _axis_vector(np, ax)):
            problems.append(f"/entry/data/{name} calibration differs from the signed axis")
            ok = False
        units = vec.attrs.get("units", "")
        units = units.decode() if isinstance(units, bytes) else str(units)
        if units != str(ax.get("units") or ""):
            problems.append(f"/entry/data/{name}@units is {units!r}, signed units are {ax.get('units')!r}")
            ok = False
    return ok
