"""Revocation: withdrawing a key, and deciding what that does to old data.

The question this answers
------------------------

A vendor announces that a detector key is compromised. For every frame that key
ever signed, the question is: **was this signed before or after?** Get the answer
wrong in one direction and a routine key rotation invalidates ten years of good
measurements; wrong in the other and a stolen key keeps certifying forgeries.

X.509 already has the field for this, and it is easy to overlook. A CRL entry
carries two dates:

``revocationDate``
    when the CA processed the revocation -- an administrative fact.

``invalidityDate`` (RFC 5280 §5.3.2, OID 2.5.29.24)
    **when the key actually stopped being trustworthy.** The RFC states
    explicitly that this "may be earlier than the revocation date".

That separation is the whole mechanism. It lets an issuer say *we recorded this
on Tuesday, but the break-in was in April*, and it covers three cases with one
field rather than needing three kinds of notice:

===========================  ====================  ==========================
case                         reason                invalidity_date
===========================  ====================  ==========================
end of trust period          cessationOfOperation  date operations ceased
partial compromise           keyCompromise         date of the break-in
total compromise             keyCompromise         the certificate's notBefore
===========================  ====================  ==========================

The middle row is the one that will actually be issued. Nobody learns that a key
was bad from birth; they learn that a lab was broken into, or that a firmware CVE
was published. The two extremes are the endpoints of a continuum.

The asymmetry that makes this safe
----------------------------------

Time evidence is often missing -- ``manifest.created`` is asserted by the signer,
so a compromised key backdates it for free, and RFC 3161 timestamping is not
implemented yet. What a verifier does with no trustworthy time depends on the
reason, and the two directions are deliberately not symmetric:

* **retirement** (``superseded``, ``cessationOfOperation``, ...) with no time
  evidence -> ``suspect``. We cannot show the signature predates the retirement,
  but a retirement is not an accusation, and answering ``revoked`` here would
  destroy a decade of good data every time a detector is decommissioned.
* **compromise** (``keyCompromise``, ``cACompromise``, ``aACompromise``) with no
  time evidence -> ``revoked``. **Fail closed.** If you cannot show the signature
  predates the compromise, you do not get the benefit of the doubt, because the
  adversary is exactly the party who would like it.

That asymmetry is why ``suspect`` has to exist as a third state. It is also why
the humane, date-scoped answer is the one that needs timestamping infrastructure,
while the destructive all-or-nothing answer works without it.

Strict on write, tolerant and loud on read
------------------------------------------

:func:`build_revocation_list` **refuses** to issue a compromise entry without an
``invalidity_date``: an issuer who is withdrawing a key knows since when, and
making them say so costs nothing. :class:`RevocationSet` still handles lists that
omit it -- vendors will issue those -- but says so in the result rather than
guessing quietly.

Format
------

Signed canonical JSON, not DER. The field names, reason strings and semantics are
RFC 5280's, so a list maps one-to-one onto a real CRL and nobody has to learn new
vocabulary -- but the browser verifier would need a full DER CRL parser to read
the real thing, and cross-implementation agreement is worth more here than
format purity.
"""

from __future__ import annotations

import base64
import datetime as _dt
import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

from ._canon import canonicalize
from . import manifest as _m
from .inventory import SignerRef
from .keys import Signer, sign_and_verify, verify_signature

__all__ = [
    "REVOCATION_SPEC",
    "REVOCATION_ENVELOPE_SPEC",
    "DOMAIN_REVOCATION",
    "REASONS",
    "RETROACTIVE_REASONS",
    "STATE_CLEAN",
    "STATE_SUSPECT",
    "STATE_REVOKED",
    "RevocationError",
    "RevocationStatus",
    "RevocationSet",
    "build_revocation_list",
    "verify_revocation_list",
    "parse_time",
]

REVOCATION_SPEC = "framesig-revocation/1"
REVOCATION_ENVELOPE_SPEC = "framesig-revocation-envelope/1"

#: Distinct from every other domain, so a revocation signature can never be
#: replayed as a frame, series, bundle or collection signature -- nor the
#: reverse, which is the dangerous direction: a detector signature accepted as a
#: revocation list would let anyone with a detector withdraw anyone's key.
DOMAIN_REVOCATION = b"framesig/1\x00revocation\x00"

#: RFC 5280 §5.3.1 CRLReason, spelled as the ASN.1 identifiers so that a list
#: maps onto a real CRL without translation. Value 7 is unused in the RFC.
REASONS = (
    "unspecified",
    "keyCompromise",
    "cACompromise",
    "affiliationChanged",
    "superseded",
    "cessationOfOperation",
    "certificateHold",
    "privilegeWithdrawn",
    "aACompromise",
    "removeFromCRL",
)

#: Reasons that poison signatures made *before* the revocation was recorded.
#: Everything else is a retirement: previously-signed data stays good.
RETROACTIVE_REASONS = frozenset({"keyCompromise", "cACompromise", "aACompromise"})

STATE_CLEAN = "clean"
STATE_SUSPECT = "suspect"
STATE_REVOKED = "revoked"


class RevocationError(ValueError):
    """A revocation list is malformed, or an entry cannot be issued as asked."""


def parse_time(text: Optional[str]) -> Optional[_dt.datetime]:
    """Parse an RFC 3339 UTC timestamp of the form framesig writes."""
    if not text:
        return None
    try:
        parsed = _dt.datetime.strptime(text, "%Y-%m-%dT%H:%M:%SZ")
    except (TypeError, ValueError):
        try:
            parsed = _dt.datetime.fromisoformat(str(text).replace("Z", "+00:00"))
        except (TypeError, ValueError):
            return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=_dt.timezone.utc)
    return parsed.astimezone(_dt.timezone.utc)


def _fmt(when: _dt.datetime) -> str:
    if when.tzinfo is None:
        when = when.replace(tzinfo=_dt.timezone.utc)
    return when.astimezone(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# --------------------------------------------------------------------------
# issuing
# --------------------------------------------------------------------------

def build_revocation_list(
    entries: Sequence[dict],
    signer: Signer,
    *,
    issuer: str,
    this_update: Optional[str] = None,
    next_update: Optional[str] = None,
    certificates_der: Sequence[bytes] = (),
    public_key_der: Optional[bytes] = None,
) -> dict:
    """Sign a withdrawal list.

    Each entry names **either** a ``key_id`` or a ``cert`` digest (or both), a
    ``reason`` from :data:`REASONS`, a ``revocation_date``, and -- for the
    compromise reasons -- an ``invalidity_date``.
    """
    if not issuer:
        raise RevocationError("a revocation list must name its issuer")

    normalised: List[dict] = []
    for i, raw in enumerate(entries):
        if not isinstance(raw, dict):
            raise RevocationError(f"entry {i} is not an object")
        reason = raw.get("reason")
        if reason not in REASONS:
            raise RevocationError(
                f"entry {i}: unknown reason {reason!r}; expected one of {', '.join(REASONS)}"
            )
        key_ref = raw.get("key_id")
        cert_ref = raw.get("cert")
        if not key_ref and not cert_ref:
            raise RevocationError(
                f"entry {i}: names neither a key_id nor a certificate digest, so nothing matches it"
            )
        revocation_date = raw.get("revocation_date") or _m.utc_now()
        invalidity_date = raw.get("invalidity_date")

        if reason in RETROACTIVE_REASONS and not invalidity_date:
            # Refusing here rather than defaulting: RFC 5280 says an absent
            # invalidityDate falls back to the revocation date, which for a
            # compromise silently means "trustworthy right up until we noticed"
            # and leaves every earlier signature valid. That is the dangerous
            # direction, and an issuer withdrawing a key knows the answer.
            raise RevocationError(
                f"entry {i}: {reason} requires an explicit invalidity_date -- the date "
                "the key stopped being trustworthy. Without it a verifier cannot tell "
                "which signatures to distrust. For a key that must be distrusted for "
                "its whole life, pass the certificate's not_before."
            )
        if parse_time(revocation_date) is None:
            raise RevocationError(f"entry {i}: unparseable revocation_date {revocation_date!r}")
        if invalidity_date is not None and parse_time(invalidity_date) is None:
            raise RevocationError(f"entry {i}: unparseable invalidity_date {invalidity_date!r}")

        entry = {"reason": reason, "revocation_date": revocation_date}
        if key_ref:
            entry["key_id"] = key_ref
        if cert_ref:
            entry["cert"] = cert_ref
        if invalidity_date:
            entry["invalidity_date"] = invalidity_date
        for optional in ("serial", "issuer_name", "note"):
            if raw.get(optional):
                entry[optional] = raw[optional]
        normalised.append(entry)

    normalised.sort(key=lambda e: (e.get("key_id") or "", e.get("cert") or "", e["reason"]))

    body = {
        "spec": REVOCATION_SPEC,
        "issuer": issuer,
        "this_update": this_update or _m.utc_now(),
        "entries": normalised,
        "signer": {"key_id": signer.key_id, "alg": signer.algorithm},
    }
    if next_update:
        body["next_update"] = next_update

    body_bytes = canonicalize(body)
    signature = sign_and_verify(signer, DOMAIN_REVOCATION + body_bytes)

    envelope = {
        "spec": REVOCATION_ENVELOPE_SPEC,
        "manifest": base64.b64encode(body_bytes).decode("ascii"),
        "signature": {
            "alg": signer.algorithm,
            "value": base64.b64encode(signature).decode("ascii"),
        },
    }
    if certificates_der:
        envelope["certificates"] = [
            base64.b64encode(c).decode("ascii") for c in certificates_der
        ]
    else:
        from .keys import public_key_bytes

        envelope["public_key"] = base64.b64encode(
            public_key_der or public_key_bytes(signer.public_key)
        ).decode("ascii")
    return envelope


# --------------------------------------------------------------------------
# consuming
# --------------------------------------------------------------------------

@dataclass
class RevocationStatus:
    """What a revocation set says about one identity."""

    state: str = STATE_CLEAN
    reason: Optional[str] = None
    #: The instant from which the identity is untrustworthy, if one is stated.
    since: Optional[str] = None
    entry: Optional[dict] = None
    notes: List[str] = field(default_factory=list)

    @property
    def clean(self) -> bool:
        return self.state == STATE_CLEAN

    def headline(self) -> str:
        if self.state == STATE_CLEAN:
            return "not revoked"
        if self.reason is None and self.notes:  # not listed, but nothing ruled it out
            return f"{self.state} ({self.notes[0]})"
        what = f"{self.state} ({self.reason}"
        if self.since:
            what += f" since {self.since}"
        return what + ")"


@dataclass
class RevocationSet:
    """A checked withdrawal list, ready to be intersected with an inventory."""

    entries: List[dict] = field(default_factory=list)
    issuer: Optional[str] = None
    this_update: Optional[str] = None
    next_update: Optional[str] = None
    signature_valid: bool = False
    #: True when the signature was checked against a key or certificate the
    #: *caller* supplied, rather than the one the list carried with it.
    #:
    #: A list that authenticates only to its own embedded key proves internal
    #: consistency and nothing about who issued it -- and for a withdrawal that
    #: matters more than it does for a frame, because a forged withdrawal is a
    #: denial-of-service against somebody else's data. The entries are still
    #: honoured (failing closed is the safe direction for integrity), but a
    #: report must never present an unpinned list as though the vendor had
    #: spoken.
    pinned: bool = False
    #: False when no list was supplied at all. **Absence is not cleanliness**:
    #: a verifier with no list and no network otherwise just proceeds, so
    #: deleting the CRL must not become a way to launder a withdrawn key.
    consulted: bool = True
    source: Optional[str] = None
    problems: List[str] = field(default_factory=list)

    @classmethod
    def absent(cls) -> "RevocationSet":
        return cls(consulted=False)

    # -- indexing ----------------------------------------------------------
    def _index(self) -> Dict[str, List[dict]]:
        idx: Dict[str, List[dict]] = {}
        for entry in self.entries:
            for key in ("key_id", "cert"):
                value = entry.get(key)
                if value:
                    idx.setdefault(value, []).append(entry)
        return idx

    def is_stale(self, now: Optional[_dt.datetime] = None) -> bool:
        """Past its own ``next_update``, if it declared one."""
        limit = parse_time(self.next_update)
        if limit is None:
            return False
        return (now or _dt.datetime.now(_dt.timezone.utc)) > limit

    def describe(self) -> str:
        if not self.consulted:
            return "no revocation data was consulted"
        parts = [f"revocation list from {self.issuer or 'an unnamed issuer'}"]
        if self.this_update:
            parts.append(f"dated {self.this_update}")
        if not self.signature_valid:
            parts.append("SIGNATURE NOT VALID")
        elif self.pinned:
            parts.append("signature valid against a pinned key")
        else:
            parts.append(
                "signature valid ONLY against the key the list carries -- "
                "nothing establishes who issued it"
            )
        if self.is_stale():
            parts.append(f"STALE (next_update {self.next_update})")
        return ", ".join(parts)

    # -- the decision ------------------------------------------------------
    def status_of(
        self,
        ref: SignerRef,
        *,
        trusted_time: Optional[_dt.datetime] = None,
    ) -> RevocationStatus:
        """Decide what this list says about *ref*.

        ``trusted_time`` is time evidence a verifier is willing to rely on --
        an RFC 3161 timestamp token, or a transparency log position. **Never
        pass ``manifest["created"]``**: it is asserted by the signer, so a
        compromised key sets it to whatever exonerates itself. The parameter is
        named to make that misuse look wrong at the call site.
        """
        if not self.consulted:
            return RevocationStatus(
                state=STATE_SUSPECT,
                notes=["no revocation data was consulted, so withdrawal could not be ruled out"],
            )

        matches = self._index().get(ref.key_id, []) + (
            self._index().get(ref.cert, []) if ref.cert else []
        )
        if not matches:
            status = RevocationStatus(state=STATE_CLEAN)
            if not self.signature_valid:
                status.state = STATE_SUSPECT
                status.notes.append(
                    "the revocation list's own signature does not verify, so its silence "
                    "about this key means nothing"
                )
            elif self.is_stale():
                status.notes.append(
                    f"the revocation list expired at {self.next_update}; a newer one may "
                    "withdraw this key"
                )
            return status

        # Worst match wins: an identity named twice is as bad as its worst entry.
        best: Optional[RevocationStatus] = None
        for entry in matches:
            candidate = self._status_for_entry(entry, ref, trusted_time)
            if best is None or _severity(candidate.state) > _severity(best.state):
                best = candidate
        assert best is not None
        if not self.signature_valid:
            best.notes.append(
                "the revocation list's own signature does not verify; treat this entry as "
                "an unverified report"
            )
        elif not self.pinned and best.state != STATE_CLEAN:
            best.notes.append(
                "this withdrawal authenticates only to the key carried inside the list, so "
                "anyone could have issued it; pin the issuer's key to rely on it"
            )
        return best

    def _status_for_entry(
        self, entry: dict, ref: SignerRef, trusted_time: Optional[_dt.datetime]
    ) -> RevocationStatus:
        reason = entry.get("reason", "unspecified")
        notes: List[str] = []

        if reason == "removeFromCRL":
            # A delta-CRL construct: it un-revokes. It should not appear in a
            # standalone list, and silently honouring it would be a way to
            # cancel a withdrawal.
            return RevocationStatus(
                state=STATE_SUSPECT, reason=reason, entry=entry,
                notes=["removeFromCRL has no meaning in a standalone list; ignoring the un-revocation"],
            )

        if reason == "certificateHold":
            return RevocationStatus(
                state=STATE_SUSPECT, reason=reason, entry=entry,
                since=entry.get("invalidity_date") or entry.get("revocation_date"),
                notes=["the certificate is suspended, not permanently withdrawn"],
            )

        retroactive = reason in RETROACTIVE_REASONS
        invalidity = parse_time(entry.get("invalidity_date"))
        revocation = parse_time(entry.get("revocation_date"))
        since = invalidity or revocation
        since_text = entry.get("invalidity_date") or entry.get("revocation_date")

        if retroactive and invalidity is None:
            notes.append(
                "this compromise entry states no invalidity_date, so the date from which "
                "the key was untrustworthy is unknown; RFC 5280 would fall back to the "
                "revocation date, which is likely to be later than the actual compromise"
            )

        if since is None:
            return RevocationStatus(
                state=STATE_REVOKED if retroactive else STATE_SUSPECT,
                reason=reason, entry=entry,
                notes=notes + ["the entry carries no usable date at all"],
            )

        if trusted_time is None:
            # The asymmetry described in the module docstring. Retirement gets
            # the benefit of the doubt; compromise does not.
            if retroactive:
                notes.append(
                    "no trustworthy signing time is available, so it cannot be shown that "
                    "this signature predates the compromise"
                )
                return RevocationStatus(STATE_REVOKED, reason, since_text, entry, notes)
            notes.append(
                "no trustworthy signing time is available, so it cannot be shown that this "
                "signature predates the withdrawal"
            )
            return RevocationStatus(STATE_SUSPECT, reason, since_text, entry, notes)

        if trusted_time < since:
            notes.append(
                f"signed at {_fmt(trusted_time)}, before the stated {since_text}"
            )
            return RevocationStatus(STATE_CLEAN, reason, since_text, entry, notes)

        notes.append(f"signed at {_fmt(trusted_time)}, at or after the stated {since_text}")
        return RevocationStatus(STATE_REVOKED, reason, since_text, entry, notes)


def _severity(state: str) -> int:
    return {STATE_CLEAN: 0, STATE_SUSPECT: 1, STATE_REVOKED: 2}.get(state, 1)


class RevocationSets:
    """Several lists consulted together, e.g. one per distribution point.

    An identity is as bad as its worst verdict across the lists. One list that
    could not be obtained therefore makes every identity *suspect*: each list
    speaks only for the certificates its issuer signed, and the missing one may
    be the one that withdraws this key. With no lists at all, everything is
    suspect -- the caller asked for a check that did not happen.
    """

    def __init__(self, sets: Sequence[RevocationSet]):
        self.sets = list(sets) or [RevocationSet(
            consulted=False, problems=["no revocation list could be located"])]

    @property
    def consulted(self) -> bool:
        return any(s.consulted for s in self.sets)

    @property
    def problems(self) -> List[str]:
        return [f"{s.source}: {p}" if s.source else p for s in self.sets for p in s.problems]

    def describe(self) -> str:
        return "\n".join(f"{s.source}: {s.describe()}" if s.source else s.describe()
                         for s in self.sets)

    def status_of(self, ref: SignerRef, *,
                  trusted_time: Optional[_dt.datetime] = None) -> RevocationStatus:
        return max((s.status_of(ref, trusted_time=trusted_time) for s in self.sets),
                   key=lambda status: _severity(status.state))


def verify_revocation_list(
    envelope: dict,
    *,
    public_keys: Sequence[object] = (),
    source: Optional[str] = None,
) -> RevocationSet:
    """Check a withdrawal list's own signature and return a usable set.

    A list whose signature does not verify is **not** discarded: its entries are
    still returned, marked unverified. Dropping them would mean an attacker who
    can corrupt one byte of the list gets the same outcome as one who deletes it
    -- silence -- which is the wrong incentive entirely.
    """
    result = RevocationSet(source=source)

    if not isinstance(envelope, dict) or envelope.get("spec") != REVOCATION_ENVELOPE_SPEC:
        got = envelope.get("spec") if isinstance(envelope, dict) else None
        result.problems.append(f"not a revocation envelope (spec={got!r})")
        return result

    try:
        body_bytes = base64.b64decode(envelope["manifest"], validate=True)
        signature = base64.b64decode(envelope["signature"]["value"], validate=True)
        algorithm = envelope["signature"]["alg"]
    except (KeyError, TypeError, ValueError) as exc:
        result.problems.append(f"malformed revocation envelope: {exc}")
        return result

    # Caller-supplied keys are tried first and tracked separately, so that
    # "verified" can be distinguished from "verified against something the file
    # brought with it". An explicitly pinned key is never mixed with the
    # embedded one: pinning that silently falls back is not pinning.
    pinned_keys = list(public_keys)

    # Everything the *file* carries is self-carried, certificate or bare key
    # alike. A certificate only becomes evidence of identity once it has been
    # chained to a trust anchor, which this function does not do -- so it counts
    # as self-carried here and the caller is told to pin.
    self_carried = []
    if envelope.get("certificates"):
        from cryptography import x509

        try:
            leaf = x509.load_der_x509_certificate(
                base64.b64decode(envelope["certificates"][0], validate=True)
            )
            self_carried.append(leaf.public_key())
        except Exception as exc:  # noqa: BLE001
            result.problems.append(f"unreadable certificate in revocation list: {exc}")
    if envelope.get("public_key"):
        from cryptography.hazmat.primitives.serialization import load_der_public_key

        try:
            self_carried.append(
                load_der_public_key(base64.b64decode(envelope["public_key"], validate=True))
            )
        except Exception as exc:  # noqa: BLE001
            result.problems.append(f"unreadable public key in revocation list: {exc}")

    message = DOMAIN_REVOCATION + body_bytes
    for key in pinned_keys:
        if verify_signature(key, message, signature, algorithm):
            result.signature_valid = True
            result.pinned = True
            break
    if not result.signature_valid and not public_keys:
        # Only fall back when the caller pinned nothing. A pin that silently
        # falls back to the file's own key is not a pin.
        for key in self_carried:
            if verify_signature(key, message, signature, algorithm):
                result.signature_valid = True
                break
    if not result.signature_valid:
        result.problems.append("the revocation list's signature does not verify")
    elif not result.pinned:
        result.problems.append(
            "this list authenticates only to a key it carries itself, so it establishes "
            "internal consistency and nothing about who issued it"
        )

    try:
        body = json.loads(body_bytes.decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        result.problems.append(f"revocation list is not valid JSON: {exc}")
        return result

    if body.get("spec") != REVOCATION_SPEC:
        result.problems.append(f"unsupported revocation spec {body.get('spec')!r}")

    result.issuer = body.get("issuer")
    result.this_update = body.get("this_update")
    result.next_update = body.get("next_update")
    entries = body.get("entries")
    if not isinstance(entries, list):
        result.problems.append("revocation list has no entries array")
        return result

    for entry in entries:
        if not isinstance(entry, dict):
            result.problems.append("skipping a revocation entry that is not an object")
            continue
        if entry.get("reason") not in REASONS:
            # Kept, not dropped: an unrecognised reason from a future spec
            # revision is a withdrawal we do not understand, and ignoring it
            # would silently restore a key somebody deliberately withdrew.
            result.problems.append(
                f"revocation entry names an unrecognised reason {entry.get('reason')!r}; "
                "treating it as a withdrawal of unknown kind"
            )
        result.entries.append(entry)
    return result
