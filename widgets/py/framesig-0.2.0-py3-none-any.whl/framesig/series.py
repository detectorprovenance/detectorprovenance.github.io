"""Series signing: one signature for a whole run.

Why this exists
---------------

Per-frame signing does not survive contact with a real detector.  A secure
element of the class that would hold a detector key -- ATECC608, SE050, a
TPM -- needs tens of milliseconds per ECDSA operation.  That caps per-frame
signing at roughly 10 Hz.  An Eiger runs at hundreds to thousands of frames
per second.  Hashing, by contrast, is a few tens of milliseconds per frame on
a CPU and essentially free in an FPGA, and it pipelines.

So: hash every frame's manifest, accumulate the digests into a Merkle tree,
and sign the root once at the end of the run (or once per few seconds, for a
long run).  Each frame then carries its own manifest plus a log2(N)-sized
inclusion proof, and remains individually verifiable, offline, from the single
series signature.

The second reason is stronger than the throughput one: a per-frame signature
says "the detector produced this frame", but says nothing about *which run it
belonged to or where in it*.  Dropping the frames that disagree with your
hypothesis, duplicating a good frame over a bad one, or splicing frames from
another crystal all survive per-frame signing untouched.  A Merkle root over
the run, with each frame's manifest declaring its own index and the run's
frame count, does not.
"""

from __future__ import annotations

import base64
from typing import List, Optional, Sequence, Tuple

from ._canon import canonicalize
from . import manifest as _m
from .digest import merkle_levels, merkle_proof, merkle_root, merkle_verify, sha256
from .keys import Signer, sign_and_verify, verify_signature

__all__ = [
    "SERIES_SPEC",
    "SERIES_ENVELOPE_SPEC",
    "DOMAIN_SERIES",
    "build_series",
    "series_signing_input",
    "verify_series_membership",
]

SERIES_SPEC = "framesig-series/1"
SERIES_ENVELOPE_SPEC = "framesig-series-envelope/1"

#: Distinct from DOMAIN_MANIFEST so a series manifest signature can never be
#: replayed as a frame manifest signature.
DOMAIN_SERIES = b"framesig/1\x00series\x00"


def series_signing_input(series_manifest_bytes: bytes) -> bytes:
    return DOMAIN_SERIES + series_manifest_bytes


def leaf_of(frame_manifest_bytes: bytes) -> bytes:
    """A frame's Merkle leaf input is its canonical manifest bytes."""
    return frame_manifest_bytes


def build_series(
    frame_manifests: Sequence[bytes],
    signer: Signer,
    *,
    series_id: str,
    certificates_der: Sequence[bytes] = (),
    claims: Optional[dict] = None,
    created: Optional[str] = None,
) -> Tuple[dict, List[dict]]:
    """Sign a run.

    Returns ``(series_envelope, per_frame_envelopes)``.  ``frame_manifests``
    must be the canonical manifest bytes of each frame, in acquisition order;
    each frame's manifest is expected to already declare its own
    ``series.index`` and ``series.count``.
    """
    leaves = [leaf_of(m) for m in frame_manifests]
    root = merkle_root(leaves)

    series_manifest = {
        "spec": SERIES_SPEC,
        "series_id": series_id,
        "created": created or _m.utc_now(),
        "count": len(leaves),
        "merkle_root": "sha256:" + root.hex(),
        "signer": {"key_id": signer.key_id, "alg": signer.algorithm},
        "software": _m.software(),
    }
    if claims:
        series_manifest["claims"] = claims

    series_bytes = canonicalize(series_manifest)
    signature = sign_and_verify(signer, series_signing_input(series_bytes))

    series_envelope = {
        "spec": SERIES_ENVELOPE_SPEC,
        "manifest": base64.b64encode(series_bytes).decode("ascii"),
        "signature": {
            "alg": signer.algorithm,
            "value": base64.b64encode(signature).decode("ascii"),
        },
    }
    if certificates_der:
        series_envelope["certificates"] = [
            base64.b64encode(c).decode("ascii") for c in certificates_der
        ]
    else:
        from .keys import public_key_bytes

        series_envelope["public_key"] = base64.b64encode(
            public_key_bytes(signer.public_key)
        ).decode("ascii")

    levels = merkle_levels(leaves)
    envelopes = []
    for i, mb in enumerate(frame_manifests):
        envelopes.append(
            {
                "spec": _m.ENVELOPE_SPEC,
                "manifest": base64.b64encode(mb).decode("ascii"),
                "series": {
                    "index": i,
                    "proof": merkle_proof(leaves, i, levels),
                    "envelope": series_envelope,
                },
            }
        )
    return series_envelope, envelopes


def verify_series_membership(
    frame_manifest_bytes: bytes,
    series_block: dict,
    public_keys: Sequence[object],
) -> Tuple[bool, Optional[dict], List[str]]:
    """Check a frame belongs to a signed run.

    Returns ``(ok, series_manifest, problems)``.  The order matters: the series
    signature is checked first, then the inclusion proof against the root that
    signature covers.  Checking the proof against an unverified root would
    prove nothing at all.
    """
    problems: List[str] = []
    env = series_block.get("envelope")
    if not isinstance(env, dict) or env.get("spec") != SERIES_ENVELOPE_SPEC:
        return False, None, ["frame carries no valid series envelope"]

    try:
        series_bytes = base64.b64decode(env["manifest"], validate=True)
        signature = base64.b64decode(env["signature"]["value"], validate=True)
        algorithm = env["signature"]["alg"]
    except (KeyError, TypeError, ValueError) as exc:
        return False, None, [f"malformed series envelope: {exc}"]

    message = series_signing_input(series_bytes)
    if not any(verify_signature(k, message, signature, algorithm) for k in public_keys):
        return False, None, ["series signature does not verify"]

    import json

    try:
        series_manifest = json.loads(series_bytes.decode("utf-8"))
    except Exception as exc:  # noqa: BLE001 - report, do not crash
        return False, None, [f"series manifest is not valid JSON: {exc}"]

    root_hex = str(series_manifest.get("merkle_root", "")).removeprefix("sha256:")
    try:
        root = bytes.fromhex(root_hex)
    except ValueError:
        return False, series_manifest, ["series manifest has a malformed Merkle root"]

    index = series_block.get("index")
    proof = series_block.get("proof", [])
    if not isinstance(index, int):
        return False, series_manifest, ["series block has no integer frame index"]

    if not merkle_verify(leaf_of(frame_manifest_bytes), index, proof, root):
        return False, series_manifest, [
            f"frame does not prove membership at index {index} of the signed series"
        ]

    # Bind the frame's own claim about its position to the series that signed
    # it.  Without this, frame 7's manifest could be presented with frame 3's
    # proof only if the digests collided -- but the frame's *self-declared*
    # index and count must still agree with the run, or a frame from a
    # differently-sized run has been spliced in.
    import json as _json  # local: the frame manifest was already validated upstream

    try:
        frame = _json.loads(frame_manifest_bytes.decode("utf-8"))
    except Exception:  # noqa: BLE001
        frame = {}
    declared = frame.get("series") or {}
    if declared.get("index") is not None and declared["index"] != index:
        problems.append(
            f"frame declares series index {declared['index']} but proves index {index}"
        )
    if declared.get("count") is not None and declared["count"] != series_manifest.get("count"):
        problems.append(
            f"frame declares a run of {declared['count']} frames, "
            f"the signed series has {series_manifest.get('count')}"
        )
    if declared.get("id") and declared["id"] != series_manifest.get("series_id"):
        problems.append(
            f"frame declares series {declared['id']!r}, signed series is "
            f"{series_manifest.get('series_id')!r}"
        )

    return (not problems), series_manifest, problems
