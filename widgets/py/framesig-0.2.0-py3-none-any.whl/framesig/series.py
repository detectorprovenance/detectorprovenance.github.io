"""Series signing: one signature for a whole run.

Why this exists
---------------

Per-frame signing does not survive contact with a real detector.  A secure
element of the class that would hold a detector key -- ATECC608, SE050, a
TPM -- needs tens of milliseconds per ECDSA operation.  That caps per-frame
signing at roughly 10 Hz.  An Eiger runs at hundreds to thousands of frames
per second.  Hashing, by contrast, is a few tens of milliseconds per frame on
a CPU and essentially free in an FPGA, and it pipelines.

So: hash every frame's manifest, accumulate the digests into a Merkle tree,
and sign the root once at the end of the run (or once per few seconds, for a
long run).  Each frame then carries its own manifest plus a log2(N)-sized
inclusion proof, and remains individually verifiable, offline, from the single
series signature.

The second reason is stronger than the throughput one: a per-frame signature
says "the detector produced this frame", but says nothing about *which run it
belonged to or where in it*.  Dropping the frames that disagree with your
hypothesis, duplicating a good frame over a bad one, or splicing frames from
another crystal all survive per-frame signing untouched.  A Merkle root over
the run, with each frame's manifest declaring its own index and the run's
frame count, does not.
"""

from __future__ import annotations

import base64
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from ._canon import canonicalize
from . import manifest as _m
from .digest import merkle_levels, merkle_proof, merkle_root, merkle_verify, sha256
from .keys import Signer, sign_and_verify, verify_signature

__all__ = [
    "SERIES_SPEC",
    "SERIES_ENVELOPE_SPEC",
    "CHECKPOINT_SPEC",
    "CHECKPOINT_ENVELOPE_SPEC",
    "DOMAIN_SERIES",
    "DOMAIN_CHAIN",
    "DOMAIN_CHECKPOINT",
    "build_series",
    "series_signing_input",
    "verify_series_membership",
    "chain_seed",
    "chain_link",
    "chain_head",
    "SeriesChain",
    "verify_chain",
    "verify_checkpoints",
    "series_completeness",
    "describe_indices",
]

SERIES_SPEC = "framesig-series/1"
SERIES_ENVELOPE_SPEC = "framesig-series-envelope/1"
CHECKPOINT_SPEC = "framesig-checkpoint/1"
CHECKPOINT_ENVELOPE_SPEC = "framesig-checkpoint-envelope/1"

#: Distinct from DOMAIN_MANIFEST so a series manifest signature can never be
#: replayed as a frame manifest signature.
DOMAIN_SERIES = b"framesig/1\x00series\x00"
#: The running hash. Its own prefix, so a link is never a Merkle node or leaf.
DOMAIN_CHAIN = b"framesig/1\x00chain\x00"
#: A checkpoint says "the first k frames were these", not "the run had k
#: frames": it must never verify as a series signature, nor the reverse.
DOMAIN_CHECKPOINT = b"framesig/1\x00checkpoint\x00"


def series_signing_input(series_manifest_bytes: bytes) -> bytes:
    return DOMAIN_SERIES + series_manifest_bytes


def leaf_of(frame_manifest_bytes: bytes) -> bytes:
    """A frame's Merkle leaf input is its canonical manifest bytes."""
    return frame_manifest_bytes


# --------------------------------------------------------------------------
# Running hash (SPEC §7.1)
# --------------------------------------------------------------------------
#
# The Merkle root exists only once the run has ended. A run killed at frame
# 2000 of 3600 has no root and so no signature: nothing is verifiable. The
# chain is O(1) state the acquisition loop folds each frame into; signing the
# current link every K frames or T seconds leaves a verifiable prefix behind
# a crash, and a later checkpoint extends an earlier one by replaying only the
# frames in between (Merkle prefixes would need RFC 6962 consistency proofs).
#
# Links take the frame-manifest *digest*, so frames can be hashed in parallel
# workers and only this 64-byte fold runs in sequence.


def chain_seed(series_id: str) -> bytes:
    """link_{-1}: binds the chain to its run, so two runs never share a link."""
    return sha256(DOMAIN_CHAIN, b"\x00", series_id.encode("utf-8"))


def chain_link(prev: bytes, frame_manifest_digest: bytes) -> bytes:
    return sha256(DOMAIN_CHAIN, b"\x01", prev, frame_manifest_digest)


def chain_head(series_id: str, frame_manifests: Sequence[bytes]) -> bytes:
    link = chain_seed(series_id)
    for mb in frame_manifests:
        link = chain_link(link, sha256(mb))
    return link


def _seal(manifest: dict, domain: bytes, envelope_spec: str, signer: Signer,
          certificates_der: Sequence[bytes]) -> dict:
    """Sign a canonical manifest into a series-style envelope."""
    mbytes = canonicalize(manifest)
    signature = sign_and_verify(signer, domain + mbytes)
    env = {
        "spec": envelope_spec,
        "manifest": base64.b64encode(mbytes).decode("ascii"),
        "signature": {
            "alg": signer.algorithm,
            "value": base64.b64encode(signature).decode("ascii"),
        },
    }
    if certificates_der:
        env["certificates"] = [base64.b64encode(c).decode("ascii") for c in certificates_der]
    else:
        from .keys import public_key_bytes

        env["public_key"] = base64.b64encode(
            public_key_bytes(signer.public_key)
        ).decode("ascii")
    return env


#: kind -> (envelope spec, signing domain)
_SEALS = {
    "series": (SERIES_ENVELOPE_SPEC, DOMAIN_SERIES),
    "checkpoint": (CHECKPOINT_ENVELOPE_SPEC, DOMAIN_CHECKPOINT),
}


def _open(env, kind: str, public_keys: Sequence[object]):
    """Signature first, parse second. Returns ``(manifest or None, problems)``."""
    import json

    envelope_spec, domain = _SEALS[kind]
    if not isinstance(env, dict) or env.get("spec") != envelope_spec:
        return None, [f"not a {envelope_spec} envelope"]
    try:
        mbytes = base64.b64decode(env["manifest"], validate=True)
        signature = base64.b64decode(env["signature"]["value"], validate=True)
        algorithm = env["signature"]["alg"]
    except (KeyError, TypeError, ValueError) as exc:
        return None, [f"malformed {kind} envelope: {exc}"]
    if not any(verify_signature(k, domain + mbytes, signature, algorithm)
               for k in public_keys):
        return None, [f"{kind} signature does not verify"]
    try:
        return json.loads(mbytes.decode("utf-8")), []
    except Exception as exc:  # noqa: BLE001 - report, do not crash
        return None, [f"{kind} manifest is not valid JSON: {exc}"]


class SeriesChain:
    """The running hash of a run in progress, for signed checkpoints.

    ``add`` each frame's canonical manifest bytes in acquisition order;
    ``checkpoint`` signs the first ``count`` frames. Signing costs one
    hardware-key operation, so call it every K frames or T seconds, not per
    frame.
    """

    def __init__(self, series_id: str):
        self.series_id = series_id
        self.count = 0
        self.head = chain_seed(series_id)

    def add(self, frame_manifest_bytes: bytes) -> bytes:
        self.head = chain_link(self.head, sha256(frame_manifest_bytes))
        self.count += 1
        return self.head

    def checkpoint(self, signer: Signer, *, certificates_der: Sequence[bytes] = (),
                   created: Optional[str] = None) -> dict:
        return _seal({
            "spec": CHECKPOINT_SPEC,
            "series_id": self.series_id,
            "created": created or _m.utc_now(),
            "count": self.count,
            "chain_head": "sha256:" + self.head.hex(),
            "signer": {"key_id": signer.key_id, "alg": signer.algorithm},
            "software": _m.software(),
        }, DOMAIN_CHECKPOINT, CHECKPOINT_ENVELOPE_SPEC, signer, certificates_der)


def _declared(mb: bytes) -> dict:
    import json

    try:
        d = json.loads(mb.decode("utf-8")).get("series")
    except Exception:  # noqa: BLE001 - a garbled manifest just breaks the chain
        return {}
    # Unsigned input reaches here: keep only what is a dict with a usable index.
    if not isinstance(d, dict):
        return {}
    return d if isinstance(d.get("index"), (int, type(None))) else {**d, "index": None}


def verify_chain(frame_manifests: Sequence[bytes], series_id: str,
                 anchors: Sequence[Tuple[int, bytes]]) -> List[str]:
    """Replay the chain over *frame_manifests* (in file order) against signed
    ``(count, link)`` anchors. Empty list = every anchor reproduces.

    The anchors are the authority; the frames' self-declared ``series.index``
    only names what went wrong (dropped, duplicated, reordered, foreign).
    """
    anchors = sorted(anchors)
    if not anchors:
        return ["no signed checkpoint or chain head to verify against"]
    link, prev_count = chain_seed(series_id), 0
    for count, expect in anchors:
        if count > len(frame_manifests):
            return [f"a signed checkpoint covers {count} frames, only "
                    f"{len(frame_manifests)} present"] + _diagnose(
                        frame_manifests, series_id, count)
        for mb in frame_manifests[prev_count:count]:
            link = chain_link(link, sha256(mb))
        if link != expect:
            return [f"frames {prev_count}..{count - 1} do not reproduce the signed "
                    f"chain link at frame {count - 1}"] + _diagnose(
                        frame_manifests[:count], series_id, count)
        prev_count = count
    return []


def _diagnose(frame_manifests: Sequence[bytes], series_id: str, upto: int) -> List[str]:
    """Name the damage from the frames' declared indices. Advisory only."""
    found: List[str] = []
    seen: dict = {}
    for pos, mb in enumerate(frame_manifests):
        d = _declared(mb)
        if d.get("id") != series_id:
            origin = (f"of series {d['id']!r}" if d.get("id") is not None
                      else "signed outside any series")
            found.append(f"position {pos} holds a frame {origin} (inserted)")
        else:
            seen.setdefault(d.get("index"), []).append(pos)
    found += [f"frame {i} appears at positions {w} (duplicated)"
              for i, w in seen.items() if len(w) > 1]
    # A signed count can be anything a file's own key chose: only the frames
    # present drive the loops, a shortfall past them is named as one span.
    present = min(upto, len(frame_manifests))
    missing = [i for i in range(present) if i not in seen]
    if missing and not found:
        found.append(f"frames {missing} are missing (dropped)")
    if upto > present and not found:
        found.append(f"frames {present}..{upto - 1} are missing (dropped)")
    if not found:
        moved = [f"frame {i} at position {seen[i][0]}" for i in range(upto)
                 if seen[i][0] != i]
        found.append("frames out of order: " + ", ".join(moved) if moved
                     else "a frame manifest was altered or replaced")
    return found


def verify_checkpoints(envelopes: Sequence[dict], frame_manifests: Sequence[bytes],
                       public_keys: Sequence[object]) -> Tuple[bool, int, List[str]]:
    """Verify frames against signed checkpoints and/or a final series envelope.

    Returns ``(ok, covered, problems)``: *covered* is how many leading frames
    the signatures vouch for. Frames past it -- acquired after the last
    checkpoint before a crash -- are unauthenticated, not failures.
    """
    kinds = {spec: kind for kind, (spec, _) in _SEALS.items()}
    problems: List[str] = []
    anchors, ids = [], set()
    for env in envelopes:
        spec = env.get("spec") if isinstance(env, dict) else None
        kind = kinds.get(spec) if isinstance(spec, str) else None
        if kind is None:
            problems.append("not a checkpoint or series envelope")
            continue
        m, p = _open(env, kind, public_keys)
        problems.extend(p)
        if m is None:
            continue
        try:
            count, series_id = m["count"], m["series_id"]
            if type(count) is not int or count < 0 or not isinstance(series_id, str):
                raise TypeError("count or series_id")
            anchors.append((count,
                            bytes.fromhex(str(m["chain_head"]).removeprefix("sha256:"))))
        except (KeyError, TypeError, ValueError):
            # an old series manifest without chain_head cannot anchor a chain;
            # neither can one signed by a key the file carries over hostile values
            problems.append(f"{kind} manifest carries no usable count and chain_head")
            continue
        ids.add(series_id)
    if len(ids) > 1:
        problems.append(f"checkpoints come from different series {sorted(map(str, ids))}")
    if problems:
        return False, 0, problems
    problems = verify_chain(frame_manifests, ids.pop() if ids else "", anchors)
    covered = max((c for c, _ in anchors), default=0)
    return not problems, (0 if problems else covered), problems


def build_series(
    frame_manifests: Sequence[bytes],
    signer: Signer,
    *,
    series_id: str,
    certificates_der: Sequence[bytes] = (),
    claims: Optional[dict] = None,
    created: Optional[str] = None,
) -> Tuple[dict, List[dict]]:
    """Sign a run.

    Returns ``(series_envelope, per_frame_envelopes)``.  ``frame_manifests``
    must be the canonical manifest bytes of each frame, in acquisition order;
    each frame's manifest is expected to already declare its own
    ``series.index`` and ``series.count``.
    """
    leaves = [leaf_of(m) for m in frame_manifests]
    root = merkle_root(leaves)

    series_manifest = {
        "spec": SERIES_SPEC,
        "series_id": series_id,
        "created": created or _m.utc_now(),
        "count": len(leaves),
        "merkle_root": "sha256:" + root.hex(),
        "chain_head": "sha256:" + chain_head(series_id, frame_manifests).hex(),
        "signer": {"key_id": signer.key_id, "alg": signer.algorithm},
        "software": _m.software(),
    }
    if claims:
        series_manifest["claims"] = claims

    series_envelope = _seal(series_manifest, DOMAIN_SERIES, SERIES_ENVELOPE_SPEC,
                            signer, certificates_der)

    levels = merkle_levels(leaves)
    envelopes = []
    for i, mb in enumerate(frame_manifests):
        envelopes.append(
            {
                "spec": _m.ENVELOPE_SPEC,
                "manifest": base64.b64encode(mb).decode("ascii"),
                "series": {
                    "index": i,
                    "proof": merkle_proof(leaves, i, levels),
                    "envelope": series_envelope,
                },
            }
        )
    return series_envelope, envelopes


def verify_series_membership(
    frame_manifest_bytes: bytes,
    series_block: dict,
    public_keys: Sequence[object],
) -> Tuple[bool, Optional[dict], List[str]]:
    """Check a frame belongs to a signed run.

    Returns ``(ok, series_manifest, problems)``.  The order matters: the series
    signature is checked first, then the inclusion proof against the root that
    signature covers.  Checking the proof against an unverified root would
    prove nothing at all.
    """
    problems: List[str] = []
    env = series_block.get("envelope")
    if not isinstance(env, dict) or env.get("spec") != SERIES_ENVELOPE_SPEC:
        return False, None, ["frame carries no valid series envelope"]
    series_manifest, opened = _open(env, "series", public_keys)
    if series_manifest is None:
        return False, None, opened

    root_hex = str(series_manifest.get("merkle_root", "")).removeprefix("sha256:")
    try:
        root = bytes.fromhex(root_hex)
    except ValueError:
        return False, series_manifest, ["series manifest has a malformed Merkle root"]

    index = series_block.get("index")
    proof = series_block.get("proof", [])
    if not isinstance(index, int):
        return False, series_manifest, ["series block has no integer frame index"]

    if not merkle_verify(leaf_of(frame_manifest_bytes), index, proof, root):
        return False, series_manifest, [
            f"frame does not prove membership at index {index} of the signed series"
        ]

    # Bind the frame's own claim about its position to the series that signed
    # it.  Without this, frame 7's manifest could be presented with frame 3's
    # proof only if the digests collided -- but the frame's *self-declared*
    # index and count must still agree with the run, or a frame from a
    # differently-sized run has been spliced in.
    import json as _json  # local: the frame manifest was already validated upstream

    try:
        frame = _json.loads(frame_manifest_bytes.decode("utf-8"))
    except Exception:  # noqa: BLE001
        frame = {}
    declared = frame.get("series") or {}
    if declared.get("index") is not None and declared["index"] != index:
        problems.append(
            f"frame declares series index {declared['index']} but proves index {index}"
        )
    if declared.get("count") is not None and declared["count"] != series_manifest.get("count"):
        problems.append(
            f"frame declares a run of {declared['count']} frames, "
            f"the signed series has {series_manifest.get('count')}"
        )
    if declared.get("id") and declared["id"] != series_manifest.get("series_id"):
        problems.append(
            f"frame declares series {declared['id']!r}, signed series is "
            f"{series_manifest.get('series_id')!r}"
        )

    return (not problems), series_manifest, problems



def series_completeness(frames: Iterable[Tuple[str, Optional[dict]]]) -> List[dict]:
    """Which positions of each signed series are present among a set of frames.

    The series manifest signs the run's frame count and every frame proves its
    own index, so dropping a frame is *detectable* -- but only by someone who
    looks at the run as a whole. A frame on its own cannot show that its
    neighbours are still there. This is that look.

    ``frames`` yields ``(name, series)`` pairs, ``series`` being
    :attr:`framesig.api.VerificationResult.series` -- set only once the series
    signature and the frame's inclusion proof have both verified, so nothing
    here rests on a claim the frame merely makes about itself. Frames with no
    series (signed individually, or not at all) are ignored.

    Returns one record per signed series, in the order first seen::

        {"series_id", "count", "root", "present": [index, ...],
         "missing": [index, ...], "duplicates": {index: [name, ...]},
         "complete": bool}

    A run is identified by its signed Merkle root, not by its ``series_id``:
    two runs given the same id are still two runs.
    """
    runs: Dict[tuple, dict] = {}
    for name, series in frames:
        if not isinstance(series, dict):
            continue
        key = (series.get("root"), series.get("id"), series.get("count"))
        run = runs.setdefault(key, {
            "series_id": series.get("id"),
            "count": series.get("count"),
            "root": series.get("root"),
            "_seen": {},
        })
        run["_seen"].setdefault(series.get("index"), []).append(name)

    out = []
    for run in runs.values():
        seen = run.pop("_seen")
        count = run["count"] if isinstance(run["count"], int) and run["count"] >= 0 else 0
        run["present"] = sorted(i for i in seen if isinstance(i, int))
        run["missing"] = [i for i in range(count) if i not in seen]
        run["duplicates"] = {i: names for i, names in sorted(seen.items(),
                                                              key=lambda kv: str(kv[0]))
                             if len(names) > 1}
        run["complete"] = not run["missing"] and not run["duplicates"]
        out.append(run)
    return out


def describe_indices(indices: Sequence[int], limit: int = 12) -> str:
    """``[2, 5, 6, 7, 9]`` -> ``"2, 5-7, 9"``; long lists are cut short."""
    spans: List[str] = []
    ordered = sorted(indices)
    i = 0
    while i < len(ordered):
        j = i
        while j + 1 < len(ordered) and ordered[j + 1] == ordered[j] + 1:
            j += 1
        spans.append(str(ordered[i]) if i == j else f"{ordered[i]}-{ordered[j]}")
        i = j + 1
    if len(spans) > limit:
        return ", ".join(spans[:limit]) + f", ... ({len(ordered)} in all)"
    return ", ".join(spans)
