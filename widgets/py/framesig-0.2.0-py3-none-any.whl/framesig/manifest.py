"""Manifest and envelope: what actually gets signed, and how it travels.

The layering is the C2PA one, renamed and simplified:

    payload digests + metadata digest + provenance claims
        -> a *manifest* (canonical JSON, a few hundred bytes)
            -> one signature over the manifest
                -> an *envelope* carrying manifest + signature + certificates

Nothing signs the frame directly.  The manifest is the single signed object,
which is why one detector signature can cover an arbitrary number of payloads,
why a Merkle root can stand in for ten thousand frames, and why a processing
step can countersign by referencing its parent manifest's digest.

Two rules that are easy to get wrong and expensive to get wrong:

1. **The envelope stores the manifest as opaque bytes**, base64 of the exact
   canonical serialisation that was signed.  A verifier checks the signature
   over the bytes it received and only then parses them.  Re-canonicalising a
   parsed manifest before verifying would make any canonicalisation
   disagreement -- a different JSON library, a future spec revision -- look
   like a forged signature, or worse, let a crafted manifest verify under a
   different reading.
2. **The manifest records ``signed_length``.**  The signed region is a prefix
   of the file, and its length is inside the signed object, so an attacker
   cannot move the boundary.
"""

from __future__ import annotations

import base64
import datetime as _dt
import functools
import pathlib
import subprocess
from typing import Dict, Iterable, List, Optional, Sequence

from ._canon import canonicalize
from .digest import DOMAIN_MANIFEST, hash_stream

__all__ = [
    "SPEC",
    "ENVELOPE_SPEC",
    "utc_now",
    "build_manifest",
    "signing_input",
    "encode_envelope",
    "decode_envelope",
    "manifest_digest",
]

SPEC = "framesig/1"
ENVELOPE_SPEC = "framesig-envelope/1"

#: Placeholder substituted for each payload when hashing the skeleton.  It is
#: length-independent on purpose: the payload's real length is recorded in the
#: manifest, so the skeleton digest is about metadata only.
SKELETON_MARKER = b"\x00FRAMESIG-PAYLOAD\x00"


def utc_now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


@functools.lru_cache(maxsize=None)
def software() -> dict:
    """Which framesig wrote the manifest: version, plus the git commit when
    run from a checkout, suffixed ``-dirty`` if tracked files differ from it.

    Self-reported by the signer: it traces a frame to the code that signed
    it (find every run a signer bug touched), it does not prove that code ran.
    """
    from . import __version__

    info = {"name": "framesig", "version": __version__}
    root = pathlib.Path(__file__).resolve().parents[2]
    if (root / ".git").exists():

        def git(*args):
            return subprocess.run(["git", *args], cwd=root, capture_output=True, text=True,
                                  timeout=10, check=True).stdout.strip()

        try:
            commit = git("rev-parse", "HEAD")
            if git("status", "--porcelain", "--untracked-files=no"):
                commit += "-dirty"
            info["commit"] = commit
        except (OSError, subprocess.SubprocessError):
            pass  # no git on PATH: the version alone still goes in
    return info


def _h(hexdigest: str) -> str:
    return "sha256:" + hexdigest


def build_manifest(
    *,
    profile: str,
    signed_length: int,
    body_digest: str,
    skeleton_digest: str,
    payloads: List[dict],
    signer: dict,
    created: Optional[str] = None,
    claims: Optional[dict] = None,
    series: Optional[dict] = None,
    parent: Optional[str] = None,
    attestation: Optional[dict] = None,
) -> dict:
    manifest = {
        "spec": SPEC,
        "profile": profile,
        "created": created or utc_now(),
        "signed_length": signed_length,
        "digests": {"body": body_digest, "skeleton": skeleton_digest},
        "payloads": payloads,
        "signer": signer,
        "software": software(),
    }
    if attestation:
        # Separate from `claims` on purpose. Claims are free-form context the
        # operator supplies; the attestation is what the *instrument* asserts
        # about how the frame came to exist, and assurance is computed from it.
        manifest["attestation"] = attestation
    if claims:
        manifest["claims"] = claims
    if series:
        manifest["series"] = series
    if parent:
        manifest["parent"] = parent
    return manifest


def signing_input(manifest_bytes: bytes) -> bytes:
    """Domain-separated pre-image.  Never sign a bare manifest."""
    return DOMAIN_MANIFEST + manifest_bytes


def manifest_digest(manifest_bytes: bytes) -> str:
    return _h(hash_stream([manifest_bytes]))


# --------------------------------------------------------------------------
# envelope
# --------------------------------------------------------------------------

def timestamped_value(signature: bytes) -> bytes:
    """What a timestamp token must cover: the **signature**, not the manifest.

    Timestamping the manifest would prove only that the *manifest* existed at
    time T. A key compromised afterwards could then sign that same old manifest
    and point at the old token -- the signature would postdate the compromise
    while appearing to predate it, which is precisely the fraud the timestamp
    exists to prevent. Covering the signature value binds the act of signing to
    the time, which is what CAdES calls a signature-time-stamp.
    """
    from .digest import sha256

    return sha256(signature)


def encode_envelope(
    manifest_bytes: bytes,
    signature: bytes,
    algorithm: str,
    certificates: Sequence[bytes] = (),
    timestamps: Sequence[bytes] = (),
    public_key_der: Optional[bytes] = None,
) -> dict:
    env = {
        "spec": ENVELOPE_SPEC,
        "manifest": base64.b64encode(manifest_bytes).decode("ascii"),
        "signature": {
            "alg": algorithm,
            "value": base64.b64encode(signature).decode("ascii"),
        },
    }
    if certificates:
        env["certificates"] = [base64.b64encode(c).decode("ascii") for c in certificates]
    elif public_key_der:
        # No certificate: carry the bare public key so the file is
        # self-contained.  This proves internal consistency and nothing about
        # *whose* key it is -- exactly the trust level of an unknown SSH host
        # key.  Verification reports it as "bare-key", never as "trusted".
        env["public_key"] = base64.b64encode(public_key_der).decode("ascii")
    if timestamps:
        # A list, not a single token, from the outset. Independence is part of
        # what a timestamp is worth: one from the certificate issuer's own
        # authority and one from an unrelated organisation say different things,
        # and a transparency-log entry will slot in here later without a format
        # break.
        env["timestamps"] = [base64.b64encode(t).decode("ascii") for t in timestamps]
    return env


class EnvelopeError(ValueError):
    """The envelope is missing required fields or is malformed."""


def decode_envelope(env: dict):
    """Return ``(manifest_bytes, signature, algorithm, certificates_der)``.

    Does *not* parse the manifest -- the caller verifies the signature over
    ``manifest_bytes`` first.
    """
    if not isinstance(env, dict):
        raise EnvelopeError("envelope is not an object")
    if env.get("spec") != ENVELOPE_SPEC:
        raise EnvelopeError(f"unsupported envelope spec {env.get('spec')!r}")
    try:
        manifest_bytes = base64.b64decode(env["manifest"], validate=True)
        sig = env["signature"]
        signature = base64.b64decode(sig["value"], validate=True)
        algorithm = sig["alg"]
    except (KeyError, TypeError, ValueError) as exc:
        raise EnvelopeError(f"malformed envelope: {exc}") from exc
    certs = [
        base64.b64decode(c, validate=True) for c in env.get("certificates", [])
    ]
    return manifest_bytes, signature, algorithm, certs


def envelope_bytes(env: dict) -> bytes:
    """Canonical JSON for the envelope itself (for sidecars and embedding)."""
    return canonicalize(env)


def hash_body(data: bytes) -> str:
    return _h(hash_stream([data]))


def hash_chunks(chunks: Iterable[bytes]) -> str:
    return _h(hash_stream(chunks))


def payload_record(
    payload,
    stored_digest: str,
    canonical_form: str,
    canonical_digest: str,
) -> Dict:
    rec = {
        "id": payload.id,
        "offset": payload.start,
        "length": payload.length,
        "encoding": payload.encoding,
        "element_type": payload.element_type,
        "stored": stored_digest,
        "canonical_form": canonical_form,
        "canonical": canonical_digest,
    }
    if payload.dimensions:
        rec["dimensions"] = list(payload.dimensions)
    if payload.n_elements is not None:
        rec["n_elements"] = payload.n_elements
    return rec
