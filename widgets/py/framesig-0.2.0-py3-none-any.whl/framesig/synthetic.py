"""Synthetic CBF frames, so the test suite needs no proprietary data.

Two reasons this is shipped rather than kept in ``tests/``:

* the published test vectors have to be reproducible by anyone writing an
  independent verifier, and that means the generator is part of the spec's
  supporting material, not a test fixture;
* a demo that works on a clean checkout with no beamline data is the
  difference between a tool people try and a tool people read about.

The pattern is diffraction-*like*, not physically meaningful: a smooth
background, a beamstop shadow, and a lattice of Bragg-ish spots.  It exists to
exercise the codec and the viewer, not to be indexed.
"""

from __future__ import annotations

import base64
import hashlib
import math
from typing import Iterable, List, Optional, Sequence

__all__ = ["encode_byte_offset", "synthetic_image", "write_cbf", "make_cbf_bytes"]


def encode_byte_offset(values: Iterable[int]) -> bytes:
    """Encode integers with the CBF ``X-CBF_BYTE_OFFSET`` scheme."""
    out = bytearray()
    prev = 0
    for v in values:
        d = v - prev
        prev = v
        if -127 <= d <= 127:
            out.append(d & 0xFF)
            continue
        out.append(0x80)
        if -32767 <= d <= 32767:
            out += d.to_bytes(2, "little", signed=True)
            continue
        out += (-32768).to_bytes(2, "little", signed=True)
        if -2147483647 <= d <= 2147483647:
            out += d.to_bytes(4, "little", signed=True)
            continue
        out += (-2147483648).to_bytes(4, "little", signed=True)
        out += d.to_bytes(8, "little", signed=True)
    return bytes(out)


def _lcg(seed: int):
    """Deterministic PRNG -- reproducible test vectors matter more than quality."""
    state = seed & 0xFFFFFFFF
    while True:
        state = (1103515245 * state + 12345) & 0x7FFFFFFF
        yield state


def synthetic_image(
    width: int = 128,
    height: int = 96,
    seed: int = 1,
    spots: int = 24,
    dead_value: int = -1,
) -> List[int]:
    """A deterministic diffraction-like frame in row-major order."""
    rng = _lcg(seed)
    cx, cy = width / 2.0, height / 2.0
    centres = []
    for _ in range(spots):
        a = (next(rng) % 3600) / 3600.0 * 2 * math.pi
        r = 6.0 + (next(rng) % 1000) / 1000.0 * (min(width, height) * 0.45)
        centres.append((cx + r * math.cos(a), cy + r * math.sin(a),
                        200 + next(rng) % 9000))

    pixels: List[int] = []
    for y in range(height):
        for x in range(width):
            dx, dy = x - cx, y - cy
            r2 = dx * dx + dy * dy
            # Beamstop shadow: dead pixels are negative by CBF convention.
            if r2 < 25:
                pixels.append(dead_value)
                continue
            value = int(40.0 * math.exp(-r2 / (0.5 * width * height)) + 3)
            for sx, sy, amp in centres:
                d2 = (x - sx) ** 2 + (y - sy) ** 2
                if d2 < 20:
                    value += int(amp * math.exp(-d2 / 2.2))
            value += next(rng) % 5
            pixels.append(value)
    return pixels


_TEMPLATE_HEADER = """###CBF: VERSION 1.5, framesig synthetic frame
# This is a synthetic frame produced by framesig for testing and demonstration.

data_{block}

_array_data.header_convention "SLS_1.0"
_array_data.header_contents
;
# Detector: SYNTHETIC 1M, S/N {serial}
# {timestamp}
# Pixel_size 172e-6 m x 172e-6 m
# Exposure_time {exposure:.7f} s
# Wavelength {wavelength:.5f} A
# Detector_distance {distance:.5f} m
# Beam_xy ({bx:.2f}, {by:.2f}) pixels
# Angle_increment {osc:.4f} deg.
# Start_angle {start:.4f} deg.
;

_array_data.data
;
--CIF-BINARY-FORMAT-SECTION--
Content-Type: application/octet-stream;
     conversions="x-CBF_BYTE_OFFSET"
Content-Transfer-Encoding: BINARY
X-Binary-Size: {size}
X-Binary-ID: 1
X-Binary-Element-Type: "signed 32-bit integer"
X-Binary-Element-Byte-Order: LITTLE_ENDIAN
Content-MD5: {md5}
X-Binary-Number-of-Elements: {n}
X-Binary-Size-Fastest-Dimension: {width}
X-Binary-Size-Second-Dimension: {height}
X-Binary-Size-Padding: {padding}

"""


def make_cbf_bytes(
    pixels: Optional[Sequence[int]] = None,
    width: int = 128,
    height: int = 96,
    *,
    block: str = "synthetic_0001",
    serial: str = "SYN-0001",
    timestamp: str = "2026-08-16T09:00:00.000",
    wavelength: float = 0.99987,
    distance: float = 0.15,
    exposure: float = 0.1,
    beam: Sequence[float] = (64.5, 48.2),
    osc: float = 0.1,
    start: float = 0.0,
    padding: int = 4095,
    seed: int = 1,
) -> bytes:
    """Build a complete, spec-conformant CBF file in memory."""
    if pixels is None:
        pixels = synthetic_image(width, height, seed=seed)
    if len(pixels) != width * height:
        raise ValueError(f"expected {width * height} pixels, got {len(pixels)}")

    payload = encode_byte_offset(pixels)
    header = _TEMPLATE_HEADER.format(
        block=block,
        serial=serial,
        timestamp=timestamp,
        exposure=exposure,
        wavelength=wavelength,
        distance=distance,
        bx=beam[0],
        by=beam[1],
        osc=osc,
        start=start,
        size=len(payload),
        md5=base64.b64encode(hashlib.md5(payload).digest()).decode("ascii"),
        n=len(pixels),
        width=width,
        height=height,
        padding=padding,
    )
    return (
        header.encode("ascii")
        + b"\x0c\x1a\x04\xd5"
        + payload
        + b"\x00" * padding
        + b"\n--CIF-BINARY-FORMAT-SECTION----\n;\n\n"
    )


def write_cbf(path, **kwargs) -> bytes:
    import pathlib

    data = make_cbf_bytes(**kwargs)
    pathlib.Path(path).write_bytes(data)
    return data
