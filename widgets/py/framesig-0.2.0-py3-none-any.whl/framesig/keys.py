"""Key handling and the signer/verifier abstraction.

Two algorithms are supported and both are here on purpose:

``Ed25519``
    The default.  Deterministic (no RNG needed at signing time, so a weak
    embedded RNG cannot leak the key the way it did for ECDSA in the
    PlayStation 3), small signatures, fast verification, no parameter choices
    to get wrong.

``ECDSA-P256``
    The pragmatic hardware path.  The secure elements that would actually hold
    a detector's private key -- Microchip ATECC608, NXP SE050, TPM 2.0 --
    speak ECDSA over P-256 and mostly do not speak Ed25519.  A scheme that
    cannot be implemented on the chip is a scheme that never leaves the
    proof of concept.

The :class:`Signer` protocol is deliberately narrow (``key_id``, ``algorithm``,
``sign``) so that a future ``PKCS11Signer`` or ``TPMSigner`` drops in without
touching the manifest code.
"""

from __future__ import annotations

import base64
from typing import Optional

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, ed25519
from cryptography.exceptions import InvalidSignature

from .digest import sha256

__all__ = [
    "ALG_ED25519",
    "ALG_ECDSA_P256",
    "ALGORITHMS",
    "Signer",
    "SoftwareSigner",
    "generate_private_key",
    "load_private_key",
    "load_public_key",
    "public_key_bytes",
    "key_id",
    "algorithm_of",
    "verify_signature",
    "sign_and_verify",
    "SigningSelfCheckFailed",
    "UnsupportedKey",
]

ALG_ED25519 = "Ed25519"
ALG_ECDSA_P256 = "ECDSA-P256-SHA256"
ALGORITHMS = (ALG_ED25519, ALG_ECDSA_P256)


class UnsupportedKey(ValueError):
    """The key type or curve is not one framesig accepts."""


# --------------------------------------------------------------------------
# key identity
# --------------------------------------------------------------------------

def public_key_bytes(public_key) -> bytes:
    """DER SubjectPublicKeyInfo -- the canonical encoding we identify keys by."""
    return public_key.public_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )


def key_id(public_key) -> str:
    """Stable identifier for a public key: ``sha256:<hex>`` over its SPKI."""
    return "sha256:" + sha256(public_key_bytes(public_key)).hex()


def algorithm_of(public_key) -> str:
    if isinstance(public_key, ed25519.Ed25519PublicKey):
        return ALG_ED25519
    if isinstance(public_key, ec.EllipticCurvePublicKey):
        if isinstance(public_key.curve, ec.SECP256R1):
            return ALG_ECDSA_P256
        raise UnsupportedKey(f"unsupported EC curve {public_key.curve.name!r}; use P-256")
    raise UnsupportedKey(f"unsupported key type {type(public_key).__name__}")


# --------------------------------------------------------------------------
# generation / loading
# --------------------------------------------------------------------------

def generate_private_key(algorithm: str = ALG_ED25519):
    if algorithm == ALG_ED25519:
        return ed25519.Ed25519PrivateKey.generate()
    if algorithm == ALG_ECDSA_P256:
        return ec.generate_private_key(ec.SECP256R1())
    raise UnsupportedKey(f"unknown algorithm {algorithm!r}; expected one of {ALGORITHMS}")


def load_private_key(data: bytes, password: Optional[bytes] = None):
    key = serialization.load_pem_private_key(data, password=password)
    algorithm_of(key.public_key())  # reject unsupported types early
    return key


def load_public_key(data: bytes):
    key = serialization.load_pem_public_key(data)
    algorithm_of(key)
    return key


def private_key_pem(private_key, password: Optional[bytes] = None) -> bytes:
    enc = (
        serialization.BestAvailableEncryption(password)
        if password
        else serialization.NoEncryption()
    )
    return private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=enc,
    )


def public_key_pem(public_key) -> bytes:
    return public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )


# --------------------------------------------------------------------------
# signing
# --------------------------------------------------------------------------

class Signer:
    """Minimal interface a signing back end must provide."""

    algorithm: str
    key_id: str

    def sign(self, message: bytes) -> bytes:  # pragma: no cover - interface
        raise NotImplementedError

    @property
    def public_key(self):  # pragma: no cover - interface
        raise NotImplementedError


class SoftwareSigner(Signer):
    """Signs with an in-process private key.

    This is the proof-of-concept back end.  It is honest about what it is: the
    trust anchor is whoever can read the key file, not the detector.
    """

    def __init__(self, private_key):
        self._private_key = private_key
        self._public_key = private_key.public_key()
        self.algorithm = algorithm_of(self._public_key)
        self.key_id = key_id(self._public_key)

    @property
    def public_key(self):
        return self._public_key

    def sign(self, message: bytes) -> bytes:
        if self.algorithm == ALG_ED25519:
            return self._private_key.sign(message)
        # ECDSA over P-256 with SHA-256; DER-encoded (r, s) as per RFC 3279.
        return self._private_key.sign(message, ec.ECDSA(hashes.SHA256()))


class SigningSelfCheckFailed(RuntimeError):
    """A signer produced a signature that does not verify under its own key."""


def sign_and_verify(signer: Signer, message: bytes) -> bytes:
    """Sign, then immediately check the result against the signer's public key.

    Every signature in this project goes through here. The check costs
    microseconds and catches the whole class of failures where a signer
    *appears* to work but emits something unusable:

    * a hardware token that returns a signature from the wrong key handle,
      or truncates it, or fails silently under load;
    * a key file that loaded but is subtly corrupt;
    * an encoding mismatch in a back end -- the TPM path converts raw r||s to
      DER by hand, and a bug there would otherwise only surface at a referee's
      desk months later;
    * a bit flip between signing and writing.

    Emitting a signature nobody can verify is worse than failing to sign: the
    frame looks protected, is distributed, and only turns out to be worthless
    when somebody finally checks it.
    """
    signature = signer.sign(message)
    if not verify_signature(signer.public_key, message, signature, signer.algorithm):
        raise SigningSelfCheckFailed(
            f"the {type(signer).__name__} produced a signature that does not verify "
            f"under its own public key ({signer.key_id}). Nothing has been written. "
            "The signing key or back end is faulty."
        )
    return signature


def verify_signature(public_key, message: bytes, signature: bytes, algorithm: str) -> bool:
    """Constant-outcome signature check.  Returns False rather than raising."""
    try:
        actual = algorithm_of(public_key)
    except UnsupportedKey:
        return False
    if actual != algorithm:
        # A manifest that names one algorithm while the key implements another
        # is an algorithm-confusion attempt, not a mismatch to paper over.
        return False
    try:
        if algorithm == ALG_ED25519:
            public_key.verify(signature, message)
        else:
            public_key.verify(signature, message, ec.ECDSA(hashes.SHA256()))
        return True
    except (InvalidSignature, ValueError):
        return False


def b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def unb64(text: str) -> bytes:
    return base64.b64decode(text, validate=True)
