"""A corpus of broken CBF files, and what a reader is expected to do with them.

Every entry is a named mutation of a known-good synthetic frame. The point is
not to enumerate every way a file can rot, but to pin down the *behaviour*: a
malformed file must produce a clear, typed error or a clear verification
verdict, and must never produce a traceback, a silent pass, or a hang.

Two failure modes are specifically being guarded against, because both have
bitten this code already:

* a corrupt file that parses as *intact* -- the dangerous direction, since it
  turns a verifier into a rubber stamp (a truncated payload used to do this);
* a corrupt file that crashes the reader -- merely annoying for one file, fatal
  for a viewer walking a folder of three thousand.

``EXPECTATIONS`` records which of the two acceptable outcomes each case should
produce, so the tests assert on intent rather than on whatever the code
currently happens to do.
"""

from __future__ import annotations

from typing import Callable, Dict, Tuple

from ._fs import atomic_write
from .synthetic import make_cbf_bytes

__all__ = ["CORRUPTIONS", "EXPECTATIONS", "make_corpus", "build"]

#: Outcome a reader must produce.
REJECT = "reject"      # FormatError from parse(), with a comprehensible message
TOLERATE = "tolerate"  # parses; any signature over it must then fail to verify


def _good(**kw) -> bytes:
    return make_cbf_bytes(width=32, height=24, seed=3, **kw)


def _replace(data: bytes, old: bytes, new: bytes, count: int = 1) -> bytes:
    if old not in data:
        raise AssertionError(f"fixture no longer contains {old!r}")
    return data.replace(old, new, count)


# Each entry: name -> callable(good_bytes) -> mutated bytes
CORRUPTIONS: Dict[str, Callable[[bytes], bytes]] = {
    # --- structural truncation -------------------------------------------
    "empty": lambda d: b"",
    "header_only": lambda d: d[: d.index(b"--CIF-BINARY-FORMAT-SECTION--")],
    "truncated_in_mime_headers": lambda d: d[: d.index(b"X-Binary-Size") + 8],
    "truncated_at_start_of_bin": lambda d: d[: d.index(b"\x0c\x1a\x04\xd5") + 2],
    "truncated_mid_payload": lambda d: d[: d.index(b"\x0c\x1a\x04\xd5") + 40],
    "truncated_before_close": lambda d: d[: d.rindex(b"--CIF-BINARY-FORMAT-SECTION----")],
    "single_byte": lambda d: b"#",

    # --- broken framing ---------------------------------------------------
    "no_start_of_bin": lambda d: _replace(d, b"\x0c\x1a\x04\xd5", b"XXXX"),
    "no_close_boundary": lambda d: _replace(d, b"\n--CIF-BINARY-FORMAT-SECTION----", b"\n#"),
    "no_open_boundary": lambda d: _replace(d, b"--CIF-BINARY-FORMAT-SECTION--\n", b"--NOT-A-BOUNDARY--\n"),
    "boundary_not_newline_terminated": lambda d: _replace(
        d, b"--CIF-BINARY-FORMAT-SECTION--\nContent-Type", b"--CIF-BINARY-FORMAT-SECTION--Content-Type"
    ),

    # --- broken MIME headers ---------------------------------------------
    "mime_line_without_colon": lambda d: _replace(d, b"X-Binary-ID: 1", b"X-Binary-ID 1"),
    "mime_continuation_first": lambda d: _replace(
        d, b"--CIF-BINARY-FORMAT-SECTION--\nContent-Type", b"--CIF-BINARY-FORMAT-SECTION--\n  orphan"
    ),
    "no_blank_line_after_headers": lambda d: _replace(
        d, b"\n\n\x0c\x1a\x04\xd5", b"\n\x0c\x1a\x04\xd5"
    ),

    # --- inconsistent sizes ----------------------------------------------
    "binary_size_negative": lambda d: _replace(d, b"X-Binary-Size: ", b"X-Binary-Size: -"),
    "binary_size_enormous": lambda d: _replace(d, b"X-Binary-Size: ", b"X-Binary-Size: 99999999"),
    "binary_size_zero": lambda d: _replace(
        d, b"X-Binary-Size: %d" % _payload_len(), b"X-Binary-Size: 0"
    ),
    "binary_size_off_by_one": lambda d: _replace(
        d, b"X-Binary-Size: %d" % _payload_len(), b"X-Binary-Size: %d" % (_payload_len() + 1)
    ),
    "padding_negative": lambda d: _replace(d, b"X-Binary-Size-Padding: 4095", b"X-Binary-Size-Padding: -8"),
    "padding_past_eof": lambda d: _replace(
        d, b"X-Binary-Size-Padding: 4095", b"X-Binary-Size-Padding: 999999"
    ),
    "n_elements_too_many": lambda d: _replace(
        d, b"X-Binary-Number-of-Elements: 768", b"X-Binary-Number-of-Elements: 9999"
    ),
    "n_elements_too_few": lambda d: _replace(
        d, b"X-Binary-Number-of-Elements: 768", b"X-Binary-Number-of-Elements: 12"
    ),
    "dimensions_disagree": lambda d: _replace(
        d, b"X-Binary-Size-Fastest-Dimension: 32", b"X-Binary-Size-Fastest-Dimension: 7"
    ),

    # --- corrupt payload contents ----------------------------------------
    "payload_byte_flipped": lambda d: _flip_payload_byte(d),
    "payload_truncated_escape": lambda d: _truncate_escape(d),
    "unknown_compression": lambda d: _replace(
        d, b'conversions="x-CBF_BYTE_OFFSET"', b'conversions="x-CBF_PACKED_V2"'
    ),
    "unknown_element_type": lambda d: _replace(
        d, b'"signed 32-bit integer"', b'"signed 24-bit unobtainium"'
    ),

    # --- not a CBF at all -------------------------------------------------
    "plain_text": lambda d: b"This is a README, not a diffraction image.\n" * 20,
    "all_zero_bytes": lambda d: bytes(4096),
    "random_looking_binary": lambda d: bytes((i * 37 + 11) % 256 for i in range(4096)),
    "cbf_header_only_no_data": lambda d: b"###CBF: VERSION 1.5\n\ndata_empty\n",
}


def _payload_len() -> int:
    """Compressed payload length of the fixture, needed for exact substitutions."""
    data = _good()
    start = data.index(b"\x0c\x1a\x04\xd5") + 4
    end = data.index(b"\n--CIF-BINARY-FORMAT-SECTION----")
    # trailing padding is 4095 zero bytes by default
    return end - start - 4095


def _flip_payload_byte(data: bytes) -> bytes:
    start = data.index(b"\x0c\x1a\x04\xd5") + 4
    out = bytearray(data)
    out[start + 20] ^= 0xFF
    return bytes(out)


def _truncate_escape(data: bytes) -> bytes:
    """Leave a 16-bit escape marker as the final byte of the payload."""
    start = data.index(b"\x0c\x1a\x04\xd5") + 4
    length = _payload_len()
    out = bytearray(data)
    out[start + length - 1] = 0x80  # escape byte with nothing following it
    return bytes(out)


#: What each case must do. Anything not listed defaults to "either is fine, but
#: it must not crash and must not silently verify".
EXPECTATIONS: Dict[str, str] = {
    "header_only": TOLERATE,          # a CBF with no binary section is legal
    "truncated_in_mime_headers": REJECT,
    "truncated_at_start_of_bin": REJECT,
    "truncated_mid_payload": REJECT,
    "truncated_before_close": REJECT,
    "no_start_of_bin": REJECT,
    "no_close_boundary": REJECT,
    "boundary_not_newline_terminated": REJECT,
    "mime_line_without_colon": REJECT,
    "mime_continuation_first": REJECT,
    "binary_size_negative": REJECT,
    "binary_size_enormous": REJECT,
    "padding_negative": REJECT,
    # binary_size_off_by_one is deliberately NOT rejected. It is self-consistent
    # for an unsigned file, and requiring the closing boundary to sit at exactly
    # end+padding would reject legitimate files from writers whose padding
    # accounting is sloppy. On a signed file the skeleton digest catches it, so
    # the signature is left to decide rather than the parser.
    # Everything else parses; the signature check is what must then object.
}


def build(name: str) -> bytes:
    """Return the bytes of one named corruption."""
    if name not in CORRUPTIONS:
        raise KeyError(f"unknown corruption {name!r}; have {sorted(CORRUPTIONS)}")
    return CORRUPTIONS[name](_good())


def make_corpus(directory) -> Dict[str, Tuple[str, bytes]]:
    """Write every corruption to *directory*. Returns {name: (path, bytes)}."""
    import pathlib

    directory = pathlib.Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    out = {}
    for name in sorted(CORRUPTIONS):
        data = build(name)
        path = directory / f"{name}.cbf"
        atomic_write(path, data)
        out[name] = (str(path), data)
    return out
