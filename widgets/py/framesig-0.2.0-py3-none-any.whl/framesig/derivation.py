"""Derivation chains (SPEC section 8): a processed frame names its signed inputs.

    raw frame (instrument key) -> dark-corrected (beamline key) -> binned (user key)

Each processing step signs an ordinary frame manifest with its own key and adds
``parents``: one reference per input, naming the input's signed manifest *and*
the signature that authenticated it.  Without this, legitimate processing breaks
provenance -- the output carries a new signature and nothing connects it to the
instrument-signed data it came from.

Verification walks that graph over the files it is handed and reports every link
on its own: integrity, signer, assurance.  Nothing is inherited down the chain.
A processed frame reads "made by key X from instrument-attested data", never
"instrument-attested", and an input that was not supplied is reported missing --
an unchecked link is not a clean one.
"""

from __future__ import annotations

import base64
import collections
import json
import pathlib
import re
from typing import List, Optional, Sequence, Tuple

from . import manifest as _m
from .digest import sha256

__all__ = [
    "MAX_PARENTS",
    "MAX_DEPTH",
    "MAX_LINKS",
    "signature_digest",
    "reference",
    "parse_parents",
    "references_for",
    "verify_derivation",
]

#: Inputs one manifest may name.  ponytail: a reduction over a whole run
#: (thousands of frames) wants a by-series reference instead; add one then.
MAX_PARENTS = 256
#: Links below the frame being verified that are followed at all.
MAX_DEPTH = 16
#: Links checked in one walk, so a wide, deep graph cannot run unbounded.
MAX_LINKS = 1024

_DIGEST = re.compile(r"sha256:[0-9a-f]{64}\Z")
_MAX_NAME = 1024
_INTACT = ("valid", "repackaged")


def signature_digest(envelope) -> Optional[str]:
    """``"sha256:" + hex`` over the signature that authenticates a frame.

    That is the frame's own signature, or for a series member (SS7) the series
    signature its Merkle proof leads to.  It is the same value an RFC 3161
    token covers (:func:`framesig.manifest.timestamped_value`), for the same
    reason: it names the act of signing, not just the content signed.
    """
    if not isinstance(envelope, dict):
        return None
    series = envelope.get("series")
    if isinstance(series, dict) and "signature" not in envelope:
        envelope = series.get("envelope")
    sig = envelope.get("signature") if isinstance(envelope, dict) else None
    value = sig.get("value") if isinstance(sig, dict) else None
    if not isinstance(value, str):
        return None
    try:
        return "sha256:" + sha256(base64.b64decode(value, validate=True)).hex()
    except ValueError:
        return None


def reference(envelope, name: Optional[str] = None) -> Optional[dict]:
    """The ``parents`` entry naming the frame that carries *envelope*."""
    try:
        manifest_bytes = base64.b64decode(envelope["manifest"], validate=True)
    except (KeyError, TypeError, ValueError):
        return None
    signature = signature_digest(envelope)
    if signature is None:
        return None
    ref = {"manifest": _m.manifest_digest(manifest_bytes), "signature": signature}
    if name:
        ref["name"] = name
    return ref


def parse_parents(manifest) -> Tuple[List[dict], List[str]]:
    """``(references, problems)`` for a manifest's ``parents``.

    A manifest without the member is not derived: ``([], [])``.  Anything
    malformed is a problem, never an exception -- the manifest is untrusted
    input until the walk has shown otherwise, and even then it was written by
    whoever held the processing key.
    """
    if not isinstance(manifest, dict) or "parents" not in manifest:
        return [], []
    raw = manifest["parents"]
    if not isinstance(raw, list) or not raw:
        return [], ["'parents' is not a non-empty list"]
    if len(raw) > MAX_PARENTS:
        return [], [f"'parents' names {len(raw)} inputs, more than the {MAX_PARENTS} allowed"]
    refs, seen, problems = [], set(), []
    for i, ref in enumerate(raw):
        if not (isinstance(ref, dict)
                and all(isinstance(ref.get(k), str) and _DIGEST.match(ref[k])
                        for k in ("manifest", "signature"))):
            problems.append(f"parents[{i}] is malformed")
            continue
        name = ref.get("name")
        if name is not None and not (isinstance(name, str) and len(name) <= _MAX_NAME):
            problems.append(f"parents[{i}] has a malformed name")
            continue
        if ref["manifest"] in seen:
            problems.append(f"parents[{i}] names the same input twice")
            continue
        seen.add(ref["manifest"])
        refs.append({k: ref[k] for k in ("manifest", "signature", "name") if k in ref})
    return refs, problems


def _read(path: pathlib.Path):
    """``(data, sidecar)`` -- one read of each, so what is checked is what is named."""
    from .api import SIDECAR_SUFFIX

    data = path.read_bytes()
    sidecar = None
    side = path.with_name(path.name + SIDECAR_SUFFIX)
    if side.exists():
        sidecar = json.loads(side.read_text(encoding="utf-8"))
    return data, sidecar


def references_for(paths: Sequence) -> List[dict]:
    """``parents`` entries for the input files of a processing step.

    Refuses, at signing time, any input no verifier could ever accept as a
    link: unsigned, a signature that does not verify, or bytes changed since
    signing.  Naming one would produce a derived frame whose chain is broken
    from the moment it is written, which nobody finds out until a referee does.
    Origin is not checked here; it is reported per link at verification.
    """
    from .api import envelope_of, verify_data

    refs, seen = [], set()
    for path in paths:
        path = pathlib.Path(path)
        data, sidecar = _read(path)
        envelope = envelope_of(data, sidecar)
        ref = reference(envelope, path.name) if envelope else None
        if ref is None:
            raise ValueError(f"{path}: no readable signature; an input is named by its "
                             "signed manifest, so it must be signed first")
        result = verify_data(data, sidecar=sidecar)
        if result.status not in _INTACT:
            raise ValueError(f"{path}: {result.status} -- refusing to name an input that "
                             "does not verify")
        if ref["manifest"] in seen:
            raise ValueError(f"{path}: the same input is named twice")
        seen.add(ref["manifest"])
        refs.append(ref)
    if not refs:
        raise ValueError("a derived frame needs at least one input")
    if len(refs) > MAX_PARENTS:
        raise ValueError(f"{len(refs)} inputs; at most {MAX_PARENTS} can be named")
    return refs


def _link(path, depth: int, result, ref=None) -> dict:
    manifest = result.manifest if isinstance(result.manifest, dict) else {}
    signer = manifest.get("signer") if isinstance(manifest.get("signer"), dict) else {}
    return {
        "file": str(path),
        "depth": depth,
        "manifest": (ref or {}).get("manifest"),
        "status": result.status,
        "assurance": result.assurance.level,
        "assurance_limits": list(result.assurance.limits),
        "trust_status": result.trust_status,
        "time": result.time.level,
        "signer": signer.get("subject") or signer.get("key_id"),
        "derived": "parents" in manifest,
        "inputs": [],
        "problems": list(result.problems),
    }


def verify_derivation(
    path,
    inputs: Sequence = (),
    *,
    roots=(),
    public_keys=(),
    timestamp_roots=(),
    at_time=None,
) -> dict:
    """Walk the derivation graph of *path* over the candidate *inputs*.

    Returns a report: ``chain`` is ``complete`` (every link found and intact),
    ``incomplete`` (some input missing or beyond the walk's bounds, nothing
    contradicting) or ``broken`` (a link failed, was re-signed, or named its
    inputs malformedly).  Each entry of ``links`` stands on its own: its own
    integrity, signer, assurance and time evidence.  ``public_keys`` pins every
    link to that set, with no fallback to keys the files carry.
    """
    from .api import VerificationResult, envelope_of, verify_data

    report = {"chain": "complete", "links": [], "missing": [], "unused": [], "problems": []}
    broken = incomplete = False

    def verify(p, data, sidecar):
        try:
            return verify_data(data, roots=roots, public_keys=public_keys, sidecar=sidecar,
                               at_time=at_time, timestamp_roots=timestamp_roots)
        except Exception as exc:  # noqa: BLE001 - hostile input is reported, never raised
            r = VerificationResult(status="invalid")
            r.problems.append(f"could not be verified: {exc}")
            return r

    start = pathlib.Path(path)
    # Candidate inputs, indexed by the digest of the manifest they carry.
    pool = collections.defaultdict(list)
    unused = {}
    for p in inputs:
        p = pathlib.Path(p)
        if p.resolve() == start.resolve():
            continue
        try:
            data, sidecar = _read(p)
            envelope = envelope_of(data, sidecar)
        except (OSError, ValueError) as exc:
            report["problems"].append(f"{p}: unreadable: {exc}")
            continue
        ref = reference(envelope) if envelope else None
        if ref is None:
            report["problems"].append(f"{p}: carries no readable signature, so names nothing")
            continue
        # Path only: --input is often a whole run directory, too big to hold.
        pool[ref["manifest"]].append((p, ref["signature"]))
        unused[str(p)] = p

    try:
        data, sidecar = _read(start)
    except (OSError, ValueError) as exc:
        report["chain"] = "broken"
        report["problems"].append(f"{start}: unreadable: {exc}")
        return report
    envelope = envelope_of(data, sidecar)
    queue = collections.deque([(start, data, sidecar, 0, reference(envelope) if envelope else None)])
    # Keyed by manifest *and* signature: a reference to a re-signature of a
    # visited manifest names a different signed object and must be matched itself.
    visited = {(queue[0][4]["manifest"], queue[0][4]["signature"])} if queue[0][4] else set()

    while queue:
        p, data, sidecar, depth, ref = queue.popleft()
        if data is None:
            # Re-read the matched candidate; check what is verified is what was named.
            try:
                data, sidecar = _read(p)
                got = reference(envelope_of(data, sidecar) or {})
            except (OSError, ValueError):
                got = None
            if got != {"manifest": ref["manifest"], "signature": ref["signature"]}:
                broken = True
                report["problems"].append(f"{p}: changed after it was matched; not checked")
                continue
        result = verify(p, data, sidecar)
        link = _link(p, depth, result, ref)
        report["links"].append(link)
        if result.status not in _INTACT:
            broken = True
        if not result.signature_valid:
            if isinstance(result.manifest, dict) and "parents" in result.manifest:
                link["problems"].append("inputs not followed: this link's own signature "
                                        "does not verify, so what it names is unauthenticated")
            continue

        refs, problems = parse_parents(result.manifest)
        if problems:
            broken = True
            link["problems"].extend(problems)
        for want in refs:
            entry = {"name": want.get("name"), "manifest": want["manifest"], "file": None}
            link["inputs"].append(entry)
            candidates = pool.get(want["manifest"], [])
            match = next((c for c in candidates if c[1] == want["signature"]), None)
            for c in candidates:
                unused.pop(str(c[0]), None)
            if (want["manifest"], want["signature"]) in visited:
                entry["state"] = "checked above"  # a shared ancestor; a cycle would need a SHA-256 collision
            elif match is not None and depth + 1 > MAX_DEPTH:
                entry["state"], entry["file"] = "not followed (depth limit)", str(match[0])
                incomplete = True
            elif match is not None and len(report["links"]) + len(queue) >= MAX_LINKS:
                entry["state"], entry["file"] = "not followed (link limit)", str(match[0])
                incomplete = True
            elif match is not None:
                entry["state"], entry["file"] = "found", str(match[0])
                visited.add((want["manifest"], want["signature"]))
                queue.append((match[0], None, None, depth + 1, want))
            elif candidates:
                # Same manifest, different signature: not the signed object the
                # step consumed -- e.g. a re-signature made after a key compromise.
                entry["state"], entry["file"] = "re-signed", str(candidates[0][0])
                broken = True
            else:
                entry["state"] = "missing"
                report["missing"].append(entry)
                incomplete = True

    report["unused"] = sorted(unused)
    report["chain"] = "broken" if broken else ("incomplete" if incomplete else "complete")
    return report
