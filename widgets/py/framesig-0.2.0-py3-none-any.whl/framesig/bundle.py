"""Bundles: one signed statement about a set of already-signed frames.

What this is for
----------------

A per-frame signature says "this frame is genuine". It says nothing about the
*dataset*: which frames belong to it, how many there should be, which runs they
came from, who collected them, on what beamline, under what proposal, and which
DOI the deposition carries. Those are precisely the claims a paper makes, a
repository indexes, and a referee wants to check.

A bundle is that statement, signed once:

    3600 frames, in 2 runs, collected by <operator> on <beamline> under
    proposal <id>, deposited as <DOI> -- and here is the exact set, so that
    adding, removing or substituting a frame is detectable.

Members are identified by the digest of their **signed manifest**, not by
filename. A manifest digest binds the frame's contents, its payload digests, its
attestation and its signer, so membership survives renaming and file moves while
remaining impossible to satisfy with different data. Filenames are carried too,
but only as advisory labels: a renamed file is reported, not rejected.

The property that stops this becoming a laundering tool
-------------------------------------------------------

**A bundle can never raise the assurance of its members.** Wrapping fabricated,
self-attested frames in a beautifully signed bundle from a reputable operator
must not make them read as instrument-attested -- otherwise the bundle becomes
exactly the forgery vehicle the rest of this design exists to prevent.

So a bundle carries two independent assurance statements: what the *bundle's*
signature is worth, and the weakest assurance found among its *members*. The
second is the one that bounds any claim about the data. The verifier reports
both and never merges them.
"""

from __future__ import annotations

import base64
import datetime as _dt
from typing import Dict, Iterable, List, Optional, Sequence

from ._canon import canonicalize
from .attestation import ASSURANCE_ORDER, ASSURANCE_NONE
from .digest import merkle_root, sha256
from . import manifest as _m
from .keys import Signer, sign_and_verify, verify_signature

__all__ = [
    "BUNDLE_SPEC",
    "BUNDLE_ENVELOPE_SPEC",
    "DOMAIN_BUNDLE",
    "PROVENANCE_FIELDS",
    "build_bundle",
    "bundle_signing_input",
    "verify_bundle",
    "member_of",
    "BundleError",
]

BUNDLE_SPEC = "framesig-bundle/1"
BUNDLE_ENVELOPE_SPEC = "framesig-bundle-envelope/1"

#: Distinct from the frame and series prefixes, so a bundle signature can never
#: be replayed as either.
DOMAIN_BUNDLE = b"framesig/1\x00bundle\x00"

#: Recognised provenance fields. Free-form keys are allowed alongside these, but
#: the known ones get validated and rendered properly rather than dumped as a
#: blob -- a DOI that is silently a typo helps nobody.
PROVENANCE_FIELDS = {
    "operator": "person who collected the data",
    "orcid": "ORCID iD of the operator, as a bare identifier or URL",
    "principal_investigator": "responsible PI",
    "facility": "synchrotron, XFEL, or home laboratory",
    "beamline": "beamline or instrument name",
    "proposal": "beamtime proposal or project identifier",
    "session": "beamtime session or visit identifier",
    "doi": "DOI of the deposited dataset",
    "publication_doi": "DOI of the publication these data support",
    "sample": "sample or crystal identifier",
    "temperature_K": "collection temperature in kelvin, as a string",
    "licence": "licence the data are released under",
    "contact": "email or URL for questions",
}


class BundleError(ValueError):
    """The bundle is malformed or its members do not agree with it."""


def bundle_signing_input(bundle_bytes: bytes) -> bytes:
    return DOMAIN_BUNDLE + bundle_bytes


def member_of(manifest_bytes: bytes) -> str:
    """A frame's identity within a bundle: the digest of its signed manifest."""
    return "sha256:" + sha256(manifest_bytes).hex()


def _members_root(digests: Sequence[str]) -> str:
    """Merkle root over the sorted member digests.

    Sorted, so the root depends on the *set* and not on the order files
    happened to be listed in. Included alongside the explicit member list so a
    future compact-proof mode can exist without a format change.
    """
    leaves = [bytes.fromhex(d.split(":", 1)[1]) for d in sorted(digests)]
    return "sha256:" + merkle_root(leaves).hex()


def _weakest(levels: Iterable[str]) -> str:
    levels = list(levels)
    if not levels:
        return ASSURANCE_NONE
    return min(levels, key=lambda level: ASSURANCE_ORDER.index(level))


def build_bundle(
    members: Sequence[dict],
    signer: Signer,
    *,
    bundle_id: str,
    provenance: Optional[dict] = None,
    runs: Optional[Sequence[dict]] = None,
    certificates_der: Sequence[bytes] = (),
    created: Optional[str] = None,
    public_key_der: Optional[bytes] = None,
) -> dict:
    """Sign a set of frames as one dataset.

    ``members`` is a list of ``{"manifest_digest", "name", "assurance",
    "series_id", "series_index"}`` dicts, as produced by :func:`collect_members`.
    """
    if not members:
        raise BundleError("a bundle needs at least one member frame")

    digests = [m["manifest_digest"] for m in members]
    if len(set(digests)) != len(digests):
        # Two files with identical manifests are the same frame twice. Silently
        # collapsing them would let a bundle claim a frame count it does not
        # have.
        raise BundleError(
            "duplicate frames in the bundle: two or more members have identical "
            "signed manifests"
        )

    entries = sorted(
        (
            {"m": m["manifest_digest"], "n": m["name"], "a": m["assurance"]}
            for m in members
        ),
        key=lambda e: e["m"],
    )

    by_run: Dict[Optional[str], int] = {}
    for m in members:
        by_run[m.get("series_id")] = by_run.get(m.get("series_id"), 0) + 1

    run_records = list(runs) if runs is not None else [
        {"series_id": key, "frames": count}
        for key, count in sorted(by_run.items(), key=lambda kv: (kv[0] is None, kv[0]))
    ]

    counts = {"frames": len(members), "runs": len(run_records)}
    for level in ASSURANCE_ORDER:
        n = sum(1 for m in members if m["assurance"] == level)
        if n:
            counts[level] = n

    bundle = {
        "spec": BUNDLE_SPEC,
        "bundle_id": bundle_id,
        "created": created or _m.utc_now(),
        "counts": counts,
        "runs": run_records,
        "members_root": _members_root(digests),
        "members": entries,
        # The single most important field for anyone reading a bundle: a bundle
        # cannot be stronger than the frames in it, whoever signed the bundle.
        "member_assurance_floor": _weakest(m["assurance"] for m in members),
        "signer": {"key_id": signer.key_id, "alg": signer.algorithm},
    }
    if provenance:
        bundle["provenance"] = provenance

    bundle_bytes = canonicalize(bundle)
    signature = sign_and_verify(signer, bundle_signing_input(bundle_bytes))

    envelope = {
        "spec": BUNDLE_ENVELOPE_SPEC,
        "manifest": base64.b64encode(bundle_bytes).decode("ascii"),
        "signature": {
            "alg": signer.algorithm,
            "value": base64.b64encode(signature).decode("ascii"),
        },
    }
    if certificates_der:
        envelope["certificates"] = [
            base64.b64encode(c).decode("ascii") for c in certificates_der
        ]
    else:
        # Self-contained, exactly as a frame envelope is: carry the bare public
        # key so the bundle can be checked without a side channel.  As with
        # frames this establishes integrity and nothing about identity -- the
        # `bare-key` trust level -- and a verifier that was given a key out of
        # band pins to that instead.
        from .keys import public_key_bytes

        envelope["public_key"] = base64.b64encode(
            public_key_der or public_key_bytes(signer.public_key)
        ).decode("ascii")
    return envelope


def validate_provenance(provenance: dict) -> List[str]:
    """Cheap sanity checks on the well-known fields.

    A typo in a DOI is worse than an absent DOI: it looks like a citation and
    resolves to nothing.
    """
    problems: List[str] = []
    for key in ("doi", "publication_doi"):
        value = provenance.get(key)
        if value and not str(value).lstrip("https://doi.org/").startswith("10."):
            problems.append(
                f"{key}={value!r} does not look like a DOI (expected to start with '10.')"
            )
    orcid = provenance.get("orcid")
    if orcid:
        digits = "".join(ch for ch in str(orcid) if ch.isdigit() or ch in "Xx")
        if len(digits) != 16:
            problems.append(f"orcid={orcid!r} does not look like a 16-character ORCID iD")
    return problems


def verify_bundle(
    envelope: dict,
    *,
    found: Optional[Dict[str, dict]] = None,
    public_keys: Sequence[object] = (),
) -> dict:
    """Check a bundle's signature and, if frames were supplied, its membership.

    ``found`` maps ``manifest_digest -> {"name", "assurance", "status"}`` for
    the frames the caller actually has. Missing and unexpected frames are
    reported separately, because they mean different things: a missing frame is
    an incomplete deposition, an unexpected one is a frame somebody added.
    """
    report = {
        "signature_valid": False,
        "bundle": None,
        "problems": [],
        "notes": [],
        "present": [],
        "missing": [],
        "unexpected": [],
        "renamed": [],
        "downgraded": [],
        "member_assurance_floor": ASSURANCE_NONE,
        "complete": False,
    }

    if not isinstance(envelope, dict) or envelope.get("spec") != BUNDLE_ENVELOPE_SPEC:
        report["problems"].append(
            f"not a bundle envelope (spec={envelope.get('spec') if isinstance(envelope, dict) else None!r})"
        )
        return report

    try:
        bundle_bytes = base64.b64decode(envelope["manifest"], validate=True)
        signature = base64.b64decode(envelope["signature"]["value"], validate=True)
        algorithm = envelope["signature"]["alg"]
    except (KeyError, TypeError, ValueError) as exc:
        report["problems"].append(f"malformed bundle envelope: {exc}")
        return report

    keys = list(public_keys)
    if envelope.get("certificates"):
        from cryptography import x509

        try:
            leaf = x509.load_der_x509_certificate(
                base64.b64decode(envelope["certificates"][0], validate=True)
            )
            keys.insert(0, leaf.public_key())
        except Exception as exc:  # noqa: BLE001
            report["problems"].append(f"unreadable certificate in bundle: {exc}")
    elif envelope.get("public_key") and not public_keys:
        from cryptography.hazmat.primitives.serialization import load_der_public_key

        try:
            keys.append(load_der_public_key(base64.b64decode(envelope["public_key"], validate=True)))
        except Exception as exc:  # noqa: BLE001
            report["problems"].append(f"unreadable public key in bundle: {exc}")

    message = bundle_signing_input(bundle_bytes)
    for key in keys:
        if verify_signature(key, message, signature, algorithm):
            report["signature_valid"] = True
            break
    if not report["signature_valid"]:
        report["problems"].append("bundle signature does not verify")

    import json

    try:
        bundle = json.loads(bundle_bytes.decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        report["problems"].append(f"bundle manifest is not valid JSON: {exc}")
        return report
    report["bundle"] = bundle

    if bundle.get("spec") != BUNDLE_SPEC:
        report["problems"].append(f"unsupported bundle spec {bundle.get('spec')!r}")

    entries = bundle.get("members") or []
    declared = [e.get("m") for e in entries]
    if bundle.get("members_root") != _members_root([d for d in declared if d]):
        report["problems"].append(
            "members_root does not match the member list; the bundle is internally inconsistent"
        )
    counts = bundle.get("counts") or {}
    if counts.get("frames") != len(entries):
        report["problems"].append(
            f"counts.frames says {counts.get('frames')} but the member list holds {len(entries)}"
        )

    report["member_assurance_floor"] = bundle.get("member_assurance_floor", ASSURANCE_NONE)

    if found is None:
        report["notes"].append("no frames supplied; membership was not checked")
        return report

    by_digest = {e["m"]: e for e in entries if e.get("m")}
    for digest, entry in by_digest.items():
        actual = found.get(digest)
        if actual is None:
            report["missing"].append({"name": entry.get("n"), "manifest_digest": digest})
            continue
        report["present"].append({"name": actual.get("name"), "manifest_digest": digest})
        if entry.get("n") and actual.get("name") and entry["n"] != actual["name"]:
            # Advisory: membership is by content, so this is information, not a
            # failure. It is still worth saying -- silently accepting renames
            # makes reconstructing what happened impossible.
            report["renamed"].append({"signed_as": entry["n"], "found_as": actual["name"]})
        if entry.get("a") and actual.get("assurance") and entry["a"] != actual["assurance"]:
            report["downgraded"].append({
                "name": actual.get("name"),
                "bundled_as": entry["a"],
                "verifies_as": actual["assurance"],
            })

    for digest, actual in (found or {}).items():
        if digest not in by_digest:
            report["unexpected"].append({
                "name": actual.get("name"), "manifest_digest": digest
            })

    report["complete"] = (
        report["signature_valid"]
        and not report["missing"]
        and not report["unexpected"]
        and not report["problems"]
    )
    # The floor is recomputed from what was actually verified, not taken on
    # trust from the bundle: the bundle's own claim about its members' assurance
    # is a claim by whoever signed the bundle.
    if found:
        report["observed_assurance_floor"] = _weakest(
            a.get("assurance", ASSURANCE_NONE) for a in found.values()
        )
    return report
