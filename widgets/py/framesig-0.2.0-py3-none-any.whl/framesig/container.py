"""The single-file bundle: a signed dataset you can hand to someone.

Why ZIP
-------

A dataset that arrives as "a JSON file plus three thousand frames you must keep
in the right folder" is a dataset that will be separated from its bundle within
one email. So a bundle can be *one file* that carries the frames inside it.

That file is a ZIP, deliberately:

* the standard library reads and writes it, so there is no new dependency and
  no new parser to get wrong;
* the central directory gives **random access**, so the viewer can jump to
  frame 1700 of a 3600-frame run without touching the other 3599 -- which a tar
  cannot do;
* anyone with ``unzip`` can get their frames out without this tool, which is the
  same principle as the format being open. A container only we can open would be
  a lock-in dressed as provenance;
* CBF payloads are already byte-offset compressed, so entries are **stored**
  rather than deflated. Re-compressing compressed data costs time and saves
  almost nothing.

The security does not come from the ZIP
---------------------------------------

Nothing here trusts ZIP metadata. Names, ordering, entry count and the central
directory are all conveniences, and all of them are attacker-controlled in a
file someone sends you. Membership is decided exactly as it is for a loose
folder: by the digest of each frame's signed manifest, checked against the
signed bundle. A container whose central directory lies about what is inside
fails the same membership check a folder with the wrong frames in it would.

The one place ZIP structure does matter is **extraction**, where a crafted name
(``../../etc/passwd``, ``C:\\Windows\\...``) would write outside the target
directory. :func:`safe_member_path` is the guard, and extraction refuses rather
than sanitising silently -- a name that needed rewriting is a name worth
telling the user about.
"""

from __future__ import annotations

import io
import json
import pathlib
import posixpath
import zipfile
from typing import Dict, Iterator, List, Optional, Sequence, Tuple

__all__ = [
    "CONTAINER_SUFFIXES",
    "BUNDLE_ENTRY",
    "FRAME_PREFIX",
    "ContainerError",
    "is_container",
    "write_container",
    "BundleContainer",
    "open_container",
    "safe_member_path",
]

#: ``.framebundle`` is self-describing; ``.zip`` is accepted because someone
#: will inevitably rename it.
CONTAINER_SUFFIXES = (".framebundle", ".zip")

BUNDLE_ENTRY = "bundle.json"
FRAME_PREFIX = "frames/"
README_ENTRY = "README.txt"

_README = """\
This is a framesig bundle: a set of detector frames together with one signed
statement about them -- how many there are, which runs they came from, who
collected them, and under which proposal or DOI.

It is an ordinary ZIP file. You can extract it with any unzip tool:

    unzip this-file.framebundle

  bundle.json   the signed bundle manifest (see below)
  frames/...    the frames themselves, exactly as they were signed

To check that these are the frames that were signed, and that none have been
added, removed or altered:

    framesig bundle verify this-file.framebundle

Verification needs only a public key. It does not need this tool: the format is
specified in docs/SPEC.md of the framesig project, and any independent
implementation can check it.

What a valid signature does and does not prove is set out in docs/DESIGN.md.
In short: it can establish that frames came from a specific instrument, and it
cannot establish that the experiment behind them was honest.
"""


class ContainerError(ValueError):
    """The container is malformed, or would write outside its target."""


def is_container(path) -> bool:
    """Is this a bundle container? Decided by content, not by extension."""
    path = pathlib.Path(path)
    if not path.is_file():
        return False
    try:
        with zipfile.ZipFile(path) as zf:
            return BUNDLE_ENTRY in zf.namelist()
    except (zipfile.BadZipFile, OSError):
        return False


def safe_member_path(name: str, destination: pathlib.Path) -> pathlib.Path:
    """Resolve an archive member under *destination*, or refuse.

    Refuses rather than sanitising: a member whose name had to be rewritten is
    something the user should hear about, not something to quietly fix.
    """
    if not name or name.endswith("/"):
        raise ContainerError(f"refusing to extract a directory entry: {name!r}")
    normalised = posixpath.normpath(name.replace("\\", "/"))
    if normalised.startswith("/") or normalised.startswith("../") or normalised == "..":
        raise ContainerError(f"refusing to extract {name!r}: it escapes the target directory")
    if ":" in normalised.split("/")[0] and len(normalised.split("/")[0]) <= 2:
        raise ContainerError(f"refusing to extract {name!r}: it names a drive")
    target = (destination / normalised).resolve()
    root = destination.resolve()
    if root != target and root not in target.parents:
        raise ContainerError(f"refusing to extract {name!r}: it escapes the target directory")
    return target


# --------------------------------------------------------------------------
# writing
# --------------------------------------------------------------------------

def write_container(
    path,
    envelope: dict,
    frames: Sequence[Tuple[str, bytes]],
    *,
    extra: Optional[Dict[str, bytes]] = None,
) -> pathlib.Path:
    """Write a single-file bundle.

    ``frames`` is a sequence of ``(relative_name, bytes)``. Names are advisory
    -- membership is by manifest digest -- but they are preserved so an
    extracted dataset looks like the one that went in.
    """
    path = pathlib.Path(path)
    seen = set()
    for name, _ in frames:
        clean = posixpath.normpath(name.replace("\\", "/")).lstrip("./")
        if clean in seen:
            raise ContainerError(f"two frames would be stored under the same name: {name!r}")
        seen.add(clean)

    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".partial")
    # ZIP_STORED: CBF payloads are already byte-offset compressed, so deflate
    # costs CPU on every frame and saves almost nothing. Stored entries also
    # keep the archive readable by a memory-mapping viewer.
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as zf:
        # The manifest goes in first so a streaming reader meets it before the
        # data it describes.
        zf.writestr(BUNDLE_ENTRY, json.dumps(envelope, indent=2) + "\n")
        zf.writestr(README_ENTRY, _README)
        for name, data in frames:
            clean = posixpath.normpath(name.replace("\\", "/")).lstrip("./")
            zf.writestr(FRAME_PREFIX + clean, data)
    tmp.replace(path)
    return path


# --------------------------------------------------------------------------
# reading
# --------------------------------------------------------------------------

class BundleContainer:
    """Random-access reader for a single-file bundle."""

    def __init__(self, path):
        self.path = pathlib.Path(path)
        try:
            self._zip = zipfile.ZipFile(self.path)
        except (zipfile.BadZipFile, OSError) as exc:
            raise ContainerError(f"{self.path} is not a readable container: {exc}") from exc
        try:
            raw = self._zip.read(BUNDLE_ENTRY)
        except KeyError:
            raise ContainerError(
                f"{self.path} is a ZIP but carries no {BUNDLE_ENTRY}; it is not a framesig bundle"
            ) from None
        try:
            self.envelope = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ContainerError(f"{BUNDLE_ENTRY} is not valid JSON: {exc}") from exc

    # -- context manager ---------------------------------------------------
    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def close(self):
        self._zip.close()

    # -- contents ----------------------------------------------------------
    @property
    def frame_names(self) -> List[str]:
        """Stored frame names, in archive order, without the ``frames/`` prefix."""
        return [
            info.filename[len(FRAME_PREFIX):]
            for info in self._zip.infolist()
            if info.filename.startswith(FRAME_PREFIX) and not info.is_dir()
        ]

    #: Entries are written stored, so a legitimate bundle never expands at all.
    #: A hostile one can: 1 GB of zeros deflates to about a megabyte, and a
    #: verifier that trusts the declared size allocates whatever it is told.
    MAX_FRAME_BYTES = 4 << 30
    MAX_EXPANSION_RATIO = 200

    def read_frame(self, name: str) -> bytes:
        entry = FRAME_PREFIX + name
        try:
            info = self._zip.getinfo(entry)
        except KeyError:
            raise ContainerError(f"no frame named {name!r} in this container") from None
        if info.file_size > self.MAX_FRAME_BYTES:
            raise ContainerError(
                f"{name!r} declares {info.file_size} bytes, beyond the "
                f"{self.MAX_FRAME_BYTES}-byte limit for a single frame"
            )
        if info.compress_size and info.file_size / info.compress_size > self.MAX_EXPANSION_RATIO:
            raise ContainerError(
                f"{name!r} expands {info.file_size // max(1, info.compress_size)}x, "
                "far beyond anything a detector frame does; refusing to decompress it"
            )
        return self._zip.read(entry)

    def iter_frames(self) -> Iterator[Tuple[str, bytes]]:
        for name in self.frame_names:
            yield name, self.read_frame(name)

    def frame_size(self, name: str) -> int:
        return self._zip.getinfo(FRAME_PREFIX + name).file_size

    # -- extraction --------------------------------------------------------
    def extract(self, destination, names: Optional[Sequence[str]] = None) -> List[pathlib.Path]:
        """Extract frames, refusing any name that escapes *destination*."""
        destination = pathlib.Path(destination)
        destination.mkdir(parents=True, exist_ok=True)
        written = []
        for name in (names if names is not None else self.frame_names):
            target = safe_member_path(name, destination)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(self.read_frame(name))
            written.append(target)
        return written


def open_container(path) -> BundleContainer:
    return BundleContainer(path)
