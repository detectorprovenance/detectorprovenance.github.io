"""framesig -- cryptographic authenticity for scientific detector frames.

Sign a measurement at the instrument, verify it anywhere with nothing but a
public key.  The container adapters know about CBF/imgCIF; the core knows only
about payloads, metadata and signatures, so the same machinery applies to any
scientific data format.

See ``docs/SPEC.md`` for the wire format and ``docs/DESIGN.md`` for the threat
model, including an explicit account of what this cannot do.
"""

from __future__ import annotations

__version__ = "0.2.0"

from .api import (
    SIDECAR_SUFFIX,
    VerificationResult,
    inspect_file,
    sign_bytes,
    sign_file,
    verify_bytes,
    verify_file,
)
from .keys import (
    ALG_ECDSA_P256,
    ALG_ED25519,
    SoftwareSigner,
    generate_private_key,
    key_id,
    load_private_key,
    load_public_key,
)

__all__ = [
    "__version__",
    "VerificationResult",
    "sign_file",
    "sign_bytes",
    "verify_file",
    "verify_bytes",
    "inspect_file",
    "SIDECAR_SUFFIX",
    "SoftwareSigner",
    "generate_private_key",
    "load_private_key",
    "load_public_key",
    "key_id",
    "ALG_ED25519",
    "ALG_ECDSA_P256",
]
