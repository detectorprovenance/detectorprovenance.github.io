"""Run-HDF5: a whole run in one HDF5 file, signed once.

Why this exists
---------------

A hardware key signs at roughly ten operations a second; a detector produces
frames at hundreds to thousands a second. Series signing (``series.py``)
already answers that with one signature over a Merkle root. This puts the run
itself into the container the field reads -- a NeXus-style stack -- and keeps
everything a verifier needs next to it:

    /entry/data/data            (N, slow, fast) pixel stack, one chunk per frame
    /framesig/manifests         N  exact signed frame manifest bytes (Merkle leaves)
    /framesig/skeletons         N  each frame's original metadata, payload elided
    /framesig/series_envelope   the one signature over the Merkle root

Nothing here trusts HDF5 structure, and nothing signs HDF5 bytes: an HDF5 file
is not byte-reproducible (any library may reorder or repack it), so the
signature covers the *logical* content. Frame ``i`` is genuine when

* the file holds exactly the objects and attributes above, all hard links,
  no virtual or external storage, no filter beyond deflate/shuffle/fletcher32
  (anything else is unsigned content a reader would act on),
* the stack's shape and integer width are the ones the manifests sign,
* the series signature verifies, over a root recomputed from all N manifests,
* manifest ``i`` declares index ``i`` of this run,
* the canonical (int64-le) digest of stack[i] equals that manifest's
  ``payloads[].canonical`` -- the digest that survives CBF -> HDF5, and
* the stored skeleton hashes to the manifest's ``digests.skeleton``.

That gives the same ``repackaged`` / ``metadata-modified`` / ``tampered``
verdicts as SPEC §9 for a loose frame, but for a frame that now only exists as
a slice of a stack.

h5py and numpy are optional dependencies (``pip install framesig[hdf5]``).
"""

from __future__ import annotations

import base64
import json
import pathlib
from typing import List, Optional, Sequence

from ._canon import canonicalize
from . import manifest as _m
from ._parallel import ordered_map
from .digest import hash_stream, merkle_root
from .formats import adapter_for
from .formats.base import elide_ranges
from .keys import Signer, verify_signature
from .series import SERIES_ENVELOPE_SPEC, build_series, series_signing_input

__all__ = ["RUN_SPEC", "pack_run", "verify_run"]

RUN_SPEC = "framesig-run-h5/1"

_DTYPES = {
    ("int", 1, True): "<i1", ("int", 1, False): "<u1",
    ("int", 2, True): "<i2", ("int", 2, False): "<u2",
    ("int", 4, True): "<i4", ("int", 4, False): "<u4",
    ("int", 8, True): "<i8", ("int", 8, False): "<u8",
}


#: Every object a Run-HDF5 may hold, with the attributes each may carry.
#: Anything else -- a second dataset, a retargeted ``signal``, detector
#: geometry, a pixel mask -- is unsigned content a reader would act on, so it
#: fails verification rather than riding along next to signed pixels.
_LAYOUT = {
    "": set(),
    "entry": {"NX_class"},
    "entry/data": {"NX_class", "signal"},
    "entry/data/data": set(),
    "framesig": {"spec", "series_id"},
    "framesig/manifests": set(),
    "framesig/skeletons": set(),
    "framesig/series_envelope": set(),
}
STACK = "entry/data/data"
#: deflate, shuffle, fletcher32: built into libhdf5, no plugin DLL loaded.
_FILTERS = {1, 2, 3}


def _h5():
    import os

    # A dataset can name any filter id, and HDF5 then dlopens a plugin from a
    # search path that is user-writable on Windows. "::" disables plugins
    # if h5py is not loaded yet; the h5pl loop covers the case where it is.
    os.environ["HDF5_PLUGIN_PRELOAD"] = "::"
    try:
        import h5py
        import numpy as np
    except ImportError as exc:  # pragma: no cover - depends on the install
        raise SystemExit("Run-HDF5 needs h5py and numpy: pip install framesig[hdf5]") from exc
    while h5py.h5pl.size():
        h5py.h5pl.remove(0)
    return h5py, np


def _check_layout(h5py, h) -> List[str]:
    """Structural gate, run before anything is read. Empty list = clean."""
    bad: List[str] = []

    def visit(name, link):
        if not isinstance(link, h5py.HardLink):
            bad.append(f"/{name} is a {type(link).__name__}, only hard links are allowed")
        elif name not in _LAYOUT:
            bad.append(f"/{name} is not part of a Run-HDF5")

    h.visititems_links(visit)
    if bad:
        return bad  # never follow a soft or external link below
    missing = [n for n in _LAYOUT if n and n not in h]
    if missing:
        return [f"missing /{n}" for n in missing]
    for name, allowed in _LAYOUT.items():
        obj = h[name] if name else h
        extra = set(obj.attrs) - allowed
        if extra:
            bad.append(f"/{name} carries unsigned attributes {sorted(extra)}")
        if isinstance(obj, h5py.Dataset):
            if obj.is_virtual:
                bad.append(f"/{name} is a virtual dataset")
            plist = obj.id.get_create_plist()
            if plist.get_external_count():
                bad.append(f"/{name} keeps its data in external files")
            filters = {plist.get_filter(i)[0] for i in range(plist.get_nfilters())}
            if filters - _FILTERS:
                bad.append(f"/{name} uses filters {sorted(filters - _FILTERS)}")
    if h["entry/data"].attrs.get("signal") != "data":
        bad.append("/entry/data@signal must be 'data'")
    if not isinstance(h[STACK], h5py.Dataset):
        bad.append(f"/{STACK} is not a dataset")
    return bad


def _canonical_digest(np, frame) -> str:
    # SPEC §5.2: integers widen to signed 64-bit little-endian, storage order.
    # casting="safe": a float or uint64 stack must fail, not truncate or wrap
    # into the signed integers.
    return "sha256:" + hash_stream([np.ascontiguousarray(
        frame.astype("<i8", casting="safe")).tobytes()])


def _pack_frame(job) -> dict:
    """Decode, hash and compress one frame for ``pack_run``.

    Module-level so a process pool can run it. What comes back is small
    (manifest, skeleton) or already compressed (the chunk), so the parent only
    copies bytes and signs once.
    """
    import zlib

    import numpy as np
    from .formats.cbf import _ELEMENT_TYPES

    f, index, count, series_id, signer_info, claims, attestation = job
    data = f.read_bytes()
    adapter = adapter_for(data)
    base = adapter.normalise_base(adapter.strip(data))
    layout = adapter.parse(base)
    if len(layout.payloads) != 1:
        raise ValueError(f"{f}: Run-HDF5 takes single-image frames, found "
                         f"{len(layout.payloads)} payloads")
    p = layout.payloads[0]
    # What api._compute does, with the pixels decoded once instead of twice.
    form, chunks = adapter.canonical_payload_stream(base, p)
    if form != "int64-le":
        raise ValueError(f"{f}: only integer frames are supported, got {form}")
    canon = b"".join(chunks)
    skeleton = b"".join(elide_ranges(base, layout.payload_ranges(), _m.SKELETON_MARKER))
    record = _m.payload_record(p, "sha256:" + hash_stream([base[p.start : p.end]]),
                               form, "sha256:" + hash_stream([canon]))
    shape = tuple(reversed(p.dimensions))  # CBF lists fastest dimension first
    dtype = np.dtype(_DTYPES.get(_ELEMENT_TYPES.get(p.element_type), "<i8"))
    pixels = np.frombuffer(canon, dtype="<i8").reshape(shape)
    info = np.iinfo(dtype)
    if pixels.size and not (info.min <= pixels.min() and pixels.max() <= info.max):
        raise ValueError(f"{f}: pixel values exceed the declared {p.element_type}")
    # The chunk exactly as HDF5's shuffle + deflate pipeline stores it:
    # byte k of every element together, then a zlib stream.
    stored = np.ascontiguousarray(pixels.astype(dtype)).view(np.uint8)
    chunk = zlib.compress(stored.reshape(-1, dtype.itemsize).T.tobytes(), 1)
    manifest = canonicalize(_m.build_manifest(
        profile=adapter.profile,
        signed_length=len(base),
        body_digest=_m.hash_body(base),
        skeleton_digest=_m.hash_chunks([skeleton]),
        payloads=[record],
        signer=signer_info,
        claims=claims,
        attestation=attestation,
        series={"id": series_id, "index": index, "count": count},
    ))
    return {"shape": shape, "dtype": dtype.str, "chunk": chunk,
            "manifest": manifest, "skeleton": skeleton}


def pack_run(
    files: Sequence,
    out,
    signer: Signer,
    *,
    series_id: str,
    certificates_der: Sequence[bytes] = (),
    claims: Optional[dict] = None,
    attestation: Optional[dict] = None,
    jobs: Optional[int] = None,
) -> dict:
    """Pack single-image frame files into one Run-HDF5, signed once.

    Returns the series envelope. Frames must share one shape and pixel type.
    *jobs* processes decode, hash and compress frames (default: one per CPU,
    1: in-process); the one signature is made here, after all of them.
    """
    h5py, np = _h5()
    signer_info = {"key_id": signer.key_id, "alg": signer.algorithm}
    if certificates_der:
        from cryptography import x509
        from .pki import subject_string

        signer_info["subject"] = subject_string(
            x509.load_der_x509_certificate(certificates_der[0]))
    n = len(files)
    work = [(pathlib.Path(f), i, n, series_id, signer_info, claims, attestation)
            for i, f in enumerate(files)]
    manifests: List[bytes] = []
    skeletons: List[bytes] = []
    # Frames stream straight into the stack: a 6M detector frame is 50 MB as
    # int64, so holding a 3600-frame run would need 180 GB.
    with h5py.File(out, "w") as h:
        ds = None
        for i, r in enumerate(ordered_map(_pack_frame, work, jobs)):
            shape, dtype = tuple(r["shape"]), np.dtype(r["dtype"])
            if ds is None:
                entry = h.create_group("entry")
                entry.attrs["NX_class"] = "NXentry"
                nxdata = entry.create_group("data")
                nxdata.attrs["NX_class"] = "NXdata"
                nxdata.attrs["signal"] = "data"
                ds = nxdata.create_dataset("data", shape=(n,) + shape, dtype=dtype,
                                           chunks=(1,) + shape, compression="gzip",
                                           compression_opts=1, shuffle=True)
            elif (shape, dtype) != (ds.shape[1:], ds.dtype):
                raise ValueError(f"{work[i][0]}: {shape} {dtype} in a stack of "
                                 f"{ds.shape[1:]} {ds.dtype}; a stack needs one of each")
            ds.id.write_direct_chunk((i,) + (0,) * len(shape), r["chunk"])
            manifests.append(r["manifest"])
            skeletons.append(r["skeleton"])

        series_env, _ = build_series(manifests, signer, series_id=series_id,
                                     certificates_der=certificates_der, claims=claims)
        fs = h.create_group("framesig")
        fs.attrs["spec"] = RUN_SPEC
        fs.attrs["series_id"] = series_id
        vlen = h5py.vlen_dtype(np.uint8)
        for name, blobs in (("manifests", manifests), ("skeletons", skeletons)):
            arr = np.empty(len(blobs), dtype=object)  # a list of equal-length blobs would go 2-D
            arr[:] = [np.frombuffer(b, np.uint8) for b in blobs]
            fs.create_dataset(name, data=arr, dtype=vlen)
        fs.create_dataset("series_envelope", data=json.dumps(series_env))
    return series_env


def verify_run(path, public_keys: Sequence[object] = ()) -> dict:
    """Verify a Run-HDF5.

    Returns ``{"ok", "intact", "problems", "pinned", "series", "frames":
    [{"index", "status", "problems"}]}``. ``intact``: the run signature holds
    and every frame is at least ``repackaged``. ``ok`` also needs
    *public_keys*: the key inside the file proves integrity, not who signed,
    so an unpinned run is never a pass.

    A malformed or hostile file gives problems, never an exception.
    """
    from cryptography.exceptions import UnsupportedAlgorithm

    h5py, np = _h5()
    out = {"ok": False, "intact": False, "problems": [], "pinned": bool(public_keys),
           "series": None, "frames": []}
    try:
        with h5py.File(path, "r") as h:
            _verify_open(h5py, np, h, public_keys, out)
    except (KeyError, TypeError, ValueError, OSError, AttributeError, IndexError,
            UnsupportedAlgorithm) as exc:
        out["problems"].append(f"malformed Run-HDF5: {type(exc).__name__}: {exc}")
        out["frames"] = []
    out["intact"] = (not out["problems"] and bool(out["frames"])
                     and all(f["status"] == "repackaged" for f in out["frames"]))
    out["ok"] = out["intact"] and out["pinned"]
    return out


def _verify_open(h5py, np, h, public_keys, out) -> None:
    from .formats.cbf import _ELEMENT_TYPES

    problems = out["problems"]
    bad = _check_layout(h5py, h)
    if bad:
        problems.extend(bad)
        return
    fs = h["framesig"]
    if fs.attrs.get("spec") != RUN_SPEC:
        problems.append(f"/framesig@spec is not {RUN_SPEC!r}")
        return
    env = json.loads(fs["series_envelope"][()])
    manifests = [bytes(m) for m in fs["manifests"][...]]
    skeletons = [bytes(s) for s in fs["skeletons"][...]]

    if env.get("spec") != SERIES_ENVELOPE_SPEC:
        problems.append("series envelope has the wrong spec")
        return
    series_bytes = base64.b64decode(env["manifest"], validate=True)
    signature = base64.b64decode(env["signature"]["value"], validate=True)
    keys = list(public_keys)
    if not keys:
        # ponytail: unpinned = integrity only (ok stays False); chain validation (--trust) for runs is not wired yet
        from cryptography import x509
        from cryptography.hazmat.primitives.serialization import load_der_public_key

        if "public_key" in env:
            keys = [load_der_public_key(base64.b64decode(env["public_key"], validate=True))]
        elif env.get("certificates"):
            keys = [x509.load_der_x509_certificate(
                base64.b64decode(env["certificates"][0], validate=True)).public_key()]
    if not any(verify_signature(k, series_signing_input(series_bytes), signature,
                                env["signature"]["alg"]) for k in keys):
        problems.append("run signature does not verify")
        return
    series = json.loads(series_bytes)
    out["series"] = series

    # The whole tree is here, so recompute the root once: O(N), no proofs.
    n = len(manifests)
    if series.get("count") != n:
        problems.append(f"signed run has {series.get('count')} frames, file has {n} manifests")
    elif "sha256:" + merkle_root(manifests).hex() != series.get("merkle_root"):
        problems.append("manifests do not reproduce the signed Merkle root")
    elif len(skeletons) != n:
        problems.append(f"{len(skeletons)} skeletons for {n} manifests")
    if problems:
        return

    # From here the manifests are signed. Check the stack against what they
    # declare *before* reading a pixel: shape and width bound every read by
    # signed numbers, so a hostile header cannot make us allocate.
    recs = [json.loads(mb) for mb in manifests]
    expect = set()
    for m in recs:
        if len(m["payloads"]) != 1:
            problems.append("a Run-HDF5 frame has exactly one payload")
            return
        p = m["payloads"][0]
        dims = tuple(reversed(p["dimensions"]))  # CBF lists fastest dimension first
        if "n_elements" in p and p["n_elements"] != int(np.prod(dims)):
            problems.append(f"signed dimensions {p['dimensions']} disagree with "
                            f"n_elements {p['n_elements']}")
            return
        expect.add((dims, np.dtype(_DTYPES[_ELEMENT_TYPES[p["element_type"]]])))
    if len(expect) != 1:
        problems.append("signed frames differ in shape or pixel type")
        return
    (dims, dtype), = expect
    stack = h[STACK]
    if stack.shape != (n,) + dims:
        problems.append(f"stack is {stack.shape}, signed frames are {n} x {dims}")
    if (stack.dtype.kind, stack.dtype.itemsize) != (dtype.kind, dtype.itemsize):
        problems.append(f"stack holds {stack.dtype}, signed frames are {dtype}")
    if problems:
        return

    for i, m in enumerate(recs):
        fp: List[str] = []
        declared = m.get("series") or {}
        if declared.get("index") != i or declared.get("id") != series.get("series_id"):
            fp.append(f"manifest declares {declared.get('id')!r}#{declared.get('index')}")
        pixels_ok = _canonical_digest(np, stack[i]) == m["payloads"][0].get("canonical")
        meta_ok = "sha256:" + hash_stream([skeletons[i]]) == m["digests"]["skeleton"]
        if not pixels_ok:
            status = "tampered"
            fp.append("pixel values differ from the signed frame")
        elif not meta_ok:
            status = "metadata-modified"
            fp.append("frame metadata differs from the signed frame")
        else:
            status = "repackaged"
        if fp and status == "repackaged":
            status = "tampered"
        out["frames"].append({"index": i, "status": status, "problems": fp})
