"""Turning counts into pixels: colour maps, stretches, and automatic scaling.

Autoscaling a diffraction frame
-------------------------------

A diffraction frame is not a photograph. Almost every pixel is background --
a narrow, low-count population -- and the information is in a tiny tail of
Bragg peaks that can be four orders of magnitude brighter. Scaling to
``[min, max]`` produces a black frame with a few white dots; scaling to
mean +/- a few standard deviations of the *whole* image is dragged around by
that same tail.

So the window is set from a **robust** estimate of the background, computed
with the median and the median absolute deviation rather than the mean and the
standard deviation. MAD ignores the bright tail by construction: moving a
handful of pixels to infinity does not move it at all, whereas it moves the
standard deviation arbitrarily far.

    sigma ~= 1.4826 * MAD          (the constant makes MAD match sigma for
                                    a normal distribution)
    window = [median - sigma, median + k * sigma]

``k`` is the contrast knob, and it is what the draggable legend changes. Around
k = 12 suits typical X-ray and electron diffraction: background sits near the
bottom of the ramp and weak reflections are visible without the strong ones
blooming.

Counting detectors are Poissonian, so the background sigma is also roughly
sqrt(median). Where MAD collapses to zero -- which happens on frames with large
flat regions, and on integer data with a very low background -- that estimate
is used instead, because a zero-width window makes the whole image one colour.
"""

from __future__ import annotations

import math
from typing import Dict, List, Sequence, Tuple

__all__ = [
    "COLORMAPS",
    "DEFAULT_COLORMAP",
    "STRETCHES",
    "DEFAULT_STRETCH",
    "DEFAULT_SIGMA_FACTOR",
    "MASKED_COLOUR",
    "colormap_lut",
    "robust_window",
    "apply_stretch",
]

#: Colour maps as control points; the LUT is interpolated from these. Keeping
#: them as a handful of stops rather than 256 baked triples means the same
#: definitions can be shared with the browser verifier without a data dump.
COLORMAPS: Dict[str, List[Tuple[float, Tuple[int, int, int]]]] = {
    # Detector convention: dark background, bright spots.
    "grey": [(0.0, (0, 0, 0)), (1.0, (255, 255, 255))],
    # The classic look of a diffraction photograph: dark spots on a light
    # ground, as they appear on developed film.
    "film": [(0.0, (255, 255, 255)), (1.0, (0, 0, 0))],
    # Black-body ramp. Long-standing favourite for diffraction because
    # brightness increases monotonically while hue carries extra resolution.
    "hot": [
        (0.00, (0, 0, 0)),
        (0.35, (178, 24, 0)),
        (0.66, (255, 130, 0)),
        (0.88, (255, 225, 60)),
        (1.00, (255, 255, 255)),
    ],
    # Perceptually uniform, colour-blind safe. The right default for anything
    # that will end up in a figure.
    "viridis": [
        (0.00, (68, 1, 84)),
        (0.25, (59, 82, 139)),
        (0.50, (33, 145, 140)),
        (0.75, (94, 201, 98)),
        (1.00, (253, 231, 37)),
    ],
    # Cool equivalent of `hot`; some people read weak features better on it.
    "ice": [
        (0.00, (0, 0, 0)),
        (0.40, (0, 60, 130)),
        (0.72, (0, 160, 210)),
        (1.00, (255, 255, 255)),
    ],
}

DEFAULT_COLORMAP = "grey"

#: Applied to the normalised value before the colour lookup.
STRETCHES = ("log", "sqrt", "linear")
#: Linear, and deliberately so. A log stretch is the standard answer to a huge
#: dynamic range, but here the *window* has already solved that: it is set from
#: the background, so the visible range is only a few tens of sigma wide. Log on
#: top of that lands the background at 63% brightness -- a washed-out grey frame
#: with white blobs. Linear puts it at 8%: black background, crisp spots, which
#: is what a diffraction pattern should look like. Log stays available for when
#: someone wants to see the beamstop halo and the strongest peak at once.
DEFAULT_STRETCH = "linear"

#: Upper limit of the window, in robust sigmas above the background.
DEFAULT_SIGMA_FACTOR = 12.0

#: Dead, masked and gap pixels are negative by CBF convention. They get a colour
#: no ramp produces, so "no data" is never mistaken for "zero counts".
MASKED_COLOUR = (40, 70, 150)


def colormap_lut(name: str, size: int = 256) -> List[Tuple[int, int, int]]:
    """Interpolate a colour map's control points into a lookup table."""
    stops = COLORMAPS.get(name) or COLORMAPS[DEFAULT_COLORMAP]
    lut: List[Tuple[int, int, int]] = []
    for i in range(size):
        t = i / (size - 1)
        for j in range(len(stops) - 1):
            t0, c0 = stops[j]
            t1, c1 = stops[j + 1]
            if t0 <= t <= t1:
                span = (t1 - t0) or 1.0
                f = (t - t0) / span
                lut.append(tuple(int(round(a + (b - a) * f)) for a, b in zip(c0, c1)))
                break
        else:  # pragma: no cover - t is always inside a segment
            lut.append(stops[-1][1])
    return lut


def _median(sorted_values: Sequence[float]) -> float:
    n = len(sorted_values)
    if n == 0:
        return 0.0
    mid = n // 2
    if n % 2:
        return float(sorted_values[mid])
    return (float(sorted_values[mid - 1]) + float(sorted_values[mid])) / 2.0


def robust_window(values, sigma_factor: float = DEFAULT_SIGMA_FACTOR) -> Tuple[float, float]:
    """Return ``(low, high)`` display limits from a robust background estimate.

    Negative values are excluded: they are masked pixels, not measurements, and
    including them drags the background estimate below zero.
    """
    try:
        import numpy as np

        arr = np.asarray(values)
        arr = arr[arr >= 0]
        if arr.size == 0:
            return 0.0, 1.0
        median = float(np.median(arr))
        mad = float(np.median(np.abs(arr - median)))
    except ImportError:
        positive = sorted(v for v in _flatten(values) if v >= 0)
        if not positive:
            return 0.0, 1.0
        median = _median(positive)
        mad = _median(sorted(abs(v - median) for v in positive))

    sigma = 1.4826 * mad
    if sigma <= 0:
        # MAD collapses when more than half the pixels share a value, which is
        # common on frames with large flat regions. Counting statistics give a
        # usable fallback; a zero-width window would paint the frame one colour.
        sigma = math.sqrt(median) if median > 0 else 1.0

    low = median - sigma
    high = median + sigma_factor * sigma
    if high <= low:
        high = low + 1.0
    return low, high


def _flatten(values):
    for row in values:
        if isinstance(row, (list, tuple)):
            for v in row:
                yield v
        else:
            yield row


def apply_stretch(normalised: float, stretch: str) -> float:
    """Map a 0..1 window position through the chosen response curve."""
    x = 0.0 if normalised < 0.0 else (1.0 if normalised > 1.0 else normalised)
    if stretch == "linear":
        return x
    if stretch == "sqrt":
        return math.sqrt(x)
    # log: compresses the bright tail hard, which is what makes weak
    # reflections visible next to strong ones.
    return math.log1p(999.0 * x) / math.log(1000.0)
