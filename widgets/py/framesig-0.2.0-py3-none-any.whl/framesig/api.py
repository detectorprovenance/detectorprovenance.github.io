"""High-level sign / verify orchestration.

Verification does not return a boolean.  "Is this file authentic" has more
than two useful answers, and collapsing them throws away exactly the
information a person investigating a suspect dataset needs:

* the signature is cryptographically sound but the file's bytes differ ->
  something re-wrote the file; *which part* changed is then the question;
* the header changed but every pixel digest still matches -> a beamline tool
  added a beam centre, or somebody edited the wavelength;
* the pixels changed -> the measurement itself was altered;
* everything matches but the key chains to nothing we trust -> intact, but
  self-attested; the question becomes *whose* key.

So :class:`VerificationResult` reports each of those independently.
"""

from __future__ import annotations

import base64
import datetime as _dt
import json
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

from cryptography import x509

from ._canon import canonicalize
from .attestation import Assurance, assess_assurance
from . import manifest as _m
from .digest import hash_stream
from .formats import FormatError, adapter_by_name, adapter_for, elide_ranges
from .formats.base import FrameLayout
from .keys import (
    Signer,
    key_id,
    load_public_key,
    public_key_bytes,
    sign_and_verify,
    verify_signature,
)
from .pki import ChainResult, certificate_der, public_key_matches, subject_string, verify_chain
from .timestamp import TimeEvidence

__all__ = [
    "VerificationResult",
    "sign_bytes",
    "sign_file",
    "verify_file",
    "verify_bytes",
    "inspect_file",
    "envelope_of",
    "inventory_of",
    "SIDECAR_SUFFIX",
]

SIDECAR_SUFFIX = ".framesig"


class CorruptSignature(ValueError):
    """A signature block is present but cannot be read."""


# --------------------------------------------------------------------------
# digesting
# --------------------------------------------------------------------------

def _compute(adapter, base: bytes, layout: FrameLayout):
    """Return ``(body_digest, skeleton_digest, payload_records)``."""
    body = _m.hash_body(base)
    skeleton = _m.hash_chunks(
        elide_ranges(base, layout.payload_ranges(), _m.SKELETON_MARKER)
    )
    records = []
    for p in layout.payloads:
        stored = "sha256:" + hash_stream([base[p.start : p.end]])
        try:
            form, chunks = adapter.canonical_payload_stream(base, p)
            canonical = "sha256:" + hash_stream(chunks)
        except FormatError as exc:
            # An unsupported compression must not block signing: the stored
            # digest still gives byte-exact detection, we just lose
            # conversion-survivability for that payload.  Say so in the
            # manifest rather than pretending.
            form, canonical = "unavailable", "unavailable:" + str(exc)
        records.append(_m.payload_record(p, stored, form, canonical))
    return body, skeleton, records


def series_frame_manifest(job) -> bytes:
    """Canonical manifest bytes for one frame of a series.

    Module-level so a process pool can run it; only the manifest travels
    back, the caller signs the whole series once.
    """
    path, format_name, index, count, series_id, signer_info, claims, attestation = job
    with open(path, "rb") as fh:
        data = fh.read()
    adapter = adapter_by_name(format_name) if format_name else adapter_for(data)
    base = adapter.normalise_base(adapter.strip(data))
    body, skeleton, records = _compute(adapter, base, adapter.parse(base))
    return canonicalize(_m.build_manifest(
        profile=adapter.profile,
        signed_length=len(base),
        body_digest=body,
        skeleton_digest=skeleton,
        payloads=records,
        signer=signer_info,
        claims=claims,
        attestation=attestation,
        series={"id": series_id, "index": index, "count": count},
    ))


# --------------------------------------------------------------------------
# signing
# --------------------------------------------------------------------------

class UnusableSigningCertificate(ValueError):
    """The certificate chain offered for signing would never validate."""


def check_signing_certificates(certs: Sequence[x509.Certificate], public_key) -> None:
    """Refuse to sign with a chain that cannot work.

    Everything here is checkable at signing time, and every one of these
    mistakes produces frames that look fine to the person who made them and
    fail at a referee's desk months later, by which time the instrument may
    have been recalibrated and the sample consumed. Failing now is cheap;
    failing then is not recoverable.
    """
    leaf = certs[0]
    if not public_key_matches(leaf, public_key):
        raise UnusableSigningCertificate(
            "the leaf certificate's public key does not match the signing key"
        )

    if _is_ca(leaf):
        # A CA certificate is authority to issue, not to sign data. Using one as
        # an end-entity key is a classic way to blur that line.
        raise UnusableSigningCertificate(
            f"the leaf certificate {subject_string(leaf)!r} is a CA certificate; "
            "sign with an end-entity certificate issued by it, not with the CA itself"
        )

    usage = _key_usage(leaf)
    if usage is not None and not usage.digital_signature:
        raise UnusableSigningCertificate(
            f"the leaf certificate {subject_string(leaf)!r} does not permit "
            "digitalSignature, so verifiers are entitled to reject its signatures"
        )

    now = _dt.datetime.now(_dt.timezone.utc)
    for cert in certs:
        not_before, not_after = _validity(cert)
        if now < not_before:
            raise UnusableSigningCertificate(
                f"{subject_string(cert)!r} is not valid until {not_before.isoformat()}"
            )
        if now > not_after:
            raise UnusableSigningCertificate(
                f"{subject_string(cert)!r} expired on {not_after.isoformat()}; "
                "frames signed now could never be validated at their own signing time"
            )

    # The chain as supplied must actually link up. A leaf plus an unrelated
    # intermediate is a common copy-paste error and produces frames that no
    # trust anchor can ever reach.
    for child, parent in zip(certs, certs[1:]):
        if child.issuer != parent.subject:
            raise UnusableSigningCertificate(
                f"broken certificate chain: {subject_string(child)!r} is issued by "
                f"{child.issuer.rfc4514_string()!r}, but the next certificate is "
                f"{subject_string(parent)!r}"
            )


def _is_ca(cert: x509.Certificate) -> bool:
    try:
        return bool(cert.extensions.get_extension_for_class(x509.BasicConstraints).value.ca)
    except x509.ExtensionNotFound:
        return False


def _key_usage(cert: x509.Certificate):
    try:
        return cert.extensions.get_extension_for_class(x509.KeyUsage).value
    except x509.ExtensionNotFound:
        return None


def _validity(cert: x509.Certificate):
    try:
        return cert.not_valid_before_utc, cert.not_valid_after_utc
    except AttributeError:  # cryptography < 42
        return (
            cert.not_valid_before.replace(tzinfo=_dt.timezone.utc),
            cert.not_valid_after.replace(tzinfo=_dt.timezone.utc),
        )


def sign_bytes(
    data: bytes,
    signer: Signer,
    *,
    adapter=None,
    certificates: Sequence[x509.Certificate] = (),
    claims: Optional[dict] = None,
    series: Optional[dict] = None,
    parent: Optional[str] = None,
    attestation: Optional[dict] = None,
    timestamp_urls: Sequence[str] = (),
    timestampers: Sequence[object] = (),
) -> Tuple[bytes, dict, bytes]:
    """Sign *data*.  Returns ``(signed_base, envelope, manifest_bytes)``.

    ``signed_base`` is the exact byte range the signature covers.  For CBF
    that is the file with any previous signature block removed and a trailing
    newline guaranteed; embedding then appends to it without disturbing it.

    ``timestamp_urls`` names RFC 3161 authorities to ask for tokens over the
    signature. Pass more than one, from **different organisations**: a token
    from the same body that issued the signing certificate is worth strictly
    less, because a compromise of that body would let it both sign and backdate.
    ``timestampers`` takes objects with a ``stamp(digest)`` method for offline
    use and for tests.
    """
    adapter = adapter or adapter_for(data)
    base = adapter.normalise_base(adapter.strip(data))
    layout = adapter.parse(base)
    body, skeleton, records = _compute(adapter, base, layout)

    signer_info = {"key_id": signer.key_id, "alg": signer.algorithm}
    certs = list(certificates)
    if certs:
        check_signing_certificates(certs, signer.public_key)
        signer_info["subject"] = subject_string(certs[0])

    manifest = _m.build_manifest(
        profile=adapter.profile,
        signed_length=len(base),
        body_digest=body,
        skeleton_digest=skeleton,
        payloads=records,
        signer=signer_info,
        claims=claims,
        series=series,
        parent=parent,
        attestation=attestation,
    )
    manifest_bytes = canonicalize(manifest)
    signature = sign_and_verify(signer, _m.signing_input(manifest_bytes))
    tokens = _collect_timestamps(signature, timestamp_urls, timestampers)
    envelope = _m.encode_envelope(
        manifest_bytes,
        signature,
        signer.algorithm,
        certificates=[certificate_der(c) for c in certs],
        timestamps=tokens,
        public_key_der=public_key_bytes(signer.public_key),
    )
    return base, envelope, manifest_bytes


def _collect_timestamps(signature: bytes, urls: Sequence[str],
                        timestampers: Sequence[object]) -> List[bytes]:
    """Gather timestamp tokens over the signature, checking each before keeping it.

    Every token is verified against the digest it was requested for before it
    goes into the envelope. A token that does not check out is **not** silently
    dropped and not silently stored: storing it would put unverifiable evidence
    in the archive, and dropping it quietly would hide that the authority the
    operator asked for did not answer usefully.
    """
    import secrets

    from .timestamp import TimestampError, build_request, fetch_token, parse_response, verify_token

    digest = _m.timestamped_value(signature)
    tokens: List[bytes] = []

    for stamper in timestampers:
        token = stamper.stamp(digest)
        verify_token(token, digest)  # raises if it is not a token over this digest
        tokens.append(token)

    for url in urls:
        nonce = secrets.randbits(64)
        try:
            token = parse_response(fetch_token(url, build_request(digest, nonce=nonce)))
            verify_token(token, digest, nonce=nonce)
        except TimestampError as exc:
            raise TimestampError(f"timestamp authority {url}: {exc}") from exc
        tokens.append(token)
    return tokens


def sign_file(
    path,
    signer: Signer,
    *,
    embed: bool = True,
    output=None,
    certificates: Sequence[x509.Certificate] = (),
    claims: Optional[dict] = None,
    series: Optional[dict] = None,
    parent: Optional[str] = None,
    attestation: Optional[dict] = None,
    format_name: Optional[str] = None,
    timestamp_urls: Sequence[str] = (),
    timestampers: Sequence[object] = (),
) -> dict:
    """Sign the file at *path*.  Returns a small report dict."""
    import pathlib

    path = pathlib.Path(path)
    data = path.read_bytes()
    adapter = adapter_by_name(format_name) if format_name else adapter_for(data)
    if embed and not adapter.supports_embedding:
        raise ValueError(
            f"the {adapter.name!r} format cannot carry an embedded signature; "
            "use a sidecar (--sidecar)"
        )

    base, envelope, manifest_bytes = sign_bytes(
        data,
        signer,
        adapter=adapter,
        certificates=certificates,
        claims=claims,
        series=series,
        parent=parent,
        attestation=attestation,
        timestamp_urls=timestamp_urls,
        timestampers=timestampers,
    )
    env_json = canonicalize(envelope)

    if embed:
        from .formats.cbf import make_block

        out = pathlib.Path(output) if output else path
        out.write_bytes(base + make_block(env_json))
        written = str(out)
    else:
        out = pathlib.Path(output) if output else path.with_name(path.name + SIDECAR_SUFFIX)
        out.write_bytes(json.dumps(envelope, indent=2).encode("utf-8") + b"\n")
        if base != data:
            # Sidecar mode must not silently rewrite the subject file, but the
            # signature covers `base`, not `data`.  For raw files they are
            # identical; for CBF they differ only if the file lacked a trailing
            # newline or already carried a block.
            path.write_bytes(base)
        written = str(out)

    return {
        "signed": str(path),
        "signature": written,
        "embedded": embed,
        "manifest_digest": _m.manifest_digest(manifest_bytes),
        "signed_length": len(base),
        "payloads": len(json.loads(manifest_bytes)["payloads"]),
        "key_id": signer.key_id,
        "algorithm": signer.algorithm,
    }


# --------------------------------------------------------------------------
# verification
# --------------------------------------------------------------------------

@dataclass
class VerificationResult:
    status: str = "unsigned"
    signature_valid: bool = False
    body_intact: bool = False
    skeleton_intact: bool = False
    payload_reports: List[dict] = field(default_factory=list)
    trust: Optional[ChainResult] = None
    trust_status: str = "unknown"
    manifest: Optional[dict] = None
    problems: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    #: What the signature proves about *origin*, as opposed to integrity.
    assurance: Assurance = field(default_factory=Assurance)
    #: What is established about *when* the signature was made. A third
    #: independent axis: a frame can be intact, instrument-attested, and still
    #: have no defensible signing time -- which is what decides whether a later
    #: key withdrawal can spare it.
    time: TimeEvidence = field(default_factory=TimeEvidence)

    @property
    def ok(self) -> bool:
        """Intact *and* attested to have come from an instrument.

        Integrity alone is not a pass. A fabricated frame signed with a
        self-generated key is byte-perfect and proves nothing, so a verifier
        that answers "valid" to it is answering the wrong question.
        """
        return self.status in ("valid", "repackaged") and self.assurance.proves_instrument_origin

    @property
    def intact(self) -> bool:
        """Bytes unchanged since signing, whatever the signature is worth."""
        return self.status in ("valid", "repackaged")

    def to_dict(self) -> dict:
        return {
            "status": self.status,
            "assurance": self.assurance.to_dict(),
            "time": self.time.to_dict(),
            "proves_instrument_origin": self.assurance.proves_instrument_origin,
            "signature_valid": self.signature_valid,
            "body_intact": self.body_intact,
            "skeleton_intact": self.skeleton_intact,
            "trust_status": self.trust_status,
            "trust": None
            if self.trust is None
            else {"ok": self.trust.ok, "reason": self.trust.reason, "chain": self.trust.chain},
            "payloads": self.payload_reports,
            "problems": self.problems,
            "notes": self.notes,
            "manifest": self.manifest,
        }

    def summary(self) -> str:
        lines = [
            f"status:    {self.status}   (integrity)",
            f"assurance: {self.assurance.headline()}   (origin)",
            f"time:      {self.time.headline()}   (when)",
        ]
        if self.time.established_at:
            lines.append(
                f"           existed by {self.time.established_at.strftime('%Y-%m-%dT%H:%M:%SZ')}"
            )
        for limit in self.time.limits:
            lines.append(f"  ! {limit}")
        inst = self.assurance.instrument
        if inst:
            lines.append(
                "instrument: "
                + ", ".join(f"{k}={v}" for k, v in sorted(inst.items()))
            )
        if self.assurance.mode:
            lines.append(f"acquisition mode: {self.assurance.mode}")
        for limit in self.assurance.limits:
            lines.append(f"  ! {limit}")
        if self.manifest:
            s = self.manifest.get("signer", {})
            lines.append(
                f"signer: {s.get('subject') or s.get('key_id')} [{s.get('alg')}]"
            )
            lines.append(f"created: {self.manifest.get('created')}")
        lines.append(f"signature: {'valid' if self.signature_valid else 'INVALID'}")
        lines.append(f"bytes:     {'unmodified' if self.body_intact else 'MODIFIED'}")
        lines.append(f"metadata:  {'unmodified' if self.skeleton_intact else 'MODIFIED'}")
        for rep in self.payload_reports:
            state = "unmodified" if rep.get("stored_ok") else (
                "recompressed (values unchanged)" if rep.get("canonical_ok") else "MODIFIED"
            )
            lines.append(f"payload {rep['id']}: {state}")
        lines.append(f"trust:     {self.trust_status}")
        if self.trust and self.trust.chain:
            lines.append("chain:     " + " <- ".join(self.trust.chain))
        for p in self.problems:
            lines.append(f"  ! {p}")
        for n in self.notes:
            lines.append(f"  - {n}")
        return "\n".join(lines)


def _load_envelope_for(path, data: bytes, adapter, sidecar=None):
    """Find the envelope: embedded block first, then sidecar.

    Locating the signature must not depend on the file parsing.  Coupling the
    two meant a corrupt-but-unsigned frame was reported as an invalid
    signature, and a frame that was signed and *then* corrupted lost its
    signature verdict entirely -- the most informative fact about it, since a
    genuine signature over damaged bytes is exactly the case worth naming.
    The block marker is unambiguous on its own, so search for it directly and
    leave parsing to the integrity stage, where failure is already handled.
    """
    import pathlib

    from .formats.cbf import CbfAdapter as _Cbf

    off = _Cbf()._find_block(data)
    if off is not None:
        from .formats.cbf import read_block

        # A block that is present but unreadable is a failure, not an absence:
        # do not silently fall through to a sidecar and report on that instead.
        try:
            env_json = read_block(data[off:])
            return json.loads(env_json.decode("utf-8")), data[:off], "embedded"
        except (FormatError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise CorruptSignature(
                f"the embedded signature block is malformed: {exc}"
            ) from exc

    candidates = []
    if sidecar:
        candidates.append(pathlib.Path(sidecar))
    elif path is not None:
        p = pathlib.Path(path)
        candidates.append(p.with_name(p.name + SIDECAR_SUFFIX))
    for cand in candidates:
        if cand.exists():
            return json.loads(cand.read_text(encoding="utf-8")), data, "sidecar"
    return None, data, "none"


def verify_bytes(
    data: bytes,
    envelope: dict,
    base: bytes,
    *,
    roots: Sequence[x509.Certificate] = (),
    public_keys: Sequence[object] = (),
    at_time: Optional[_dt.datetime] = None,
    adapter=None,
    timestamp_roots: Sequence[x509.Certificate] = (),
) -> VerificationResult:
    result = VerificationResult()

    is_series = isinstance(envelope.get("series"), dict) and "signature" not in envelope
    try:
        if is_series:
            manifest_bytes, certs, signing_key = _authenticate_series(
                envelope, public_keys, result
            )
        else:
            manifest_bytes, certs, signing_key = _authenticate_single(
                envelope, public_keys, result
            )
    except _m.EnvelopeError as exc:
        result.status = "invalid"
        result.problems.append(str(exc))
        return result

    try:
        manifest = json.loads(manifest_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        result.status = "invalid"
        result.problems.append(f"manifest is not valid JSON: {exc}")
        return result
    result.manifest = manifest

    if manifest.get("spec") != _m.SPEC:
        result.problems.append(f"unsupported manifest spec {manifest.get('spec')!r}")

    # -- the signed region -------------------------------------------------
    declared = manifest.get("signed_length")
    if declared != len(base):
        # The boundary itself is in dispute, so "the file changed" is already
        # established.  Keep going anyway: localising *which* part changed is
        # the point of the report, and the payload comparison below re-scans
        # the file rather than trusting the manifest's offsets.
        result.problems.append(
            f"signed_length mismatch: manifest says {declared}, file offers {len(base)} bytes"
        )

    digests = manifest.get("digests", {})
    # Verify the file the way it was *signed*, not the way it now sniffs.  A
    # frame damaged badly enough to stop looking like a CBF would otherwise be
    # re-read under the generic adapter, which finds one whole-file payload and
    # reports a payload-count change instead of the real problem.
    from .formats import adapter_by_profile

    try:
        adapter = adapter_by_profile(manifest.get("profile", ""))
    except FormatError:
        result.problems.append(
            f"unknown profile {manifest.get('profile')!r}; falling back to format detection"
        )
        adapter = adapter or adapter_for(base)
    try:
        layout = adapter.parse(base)
    except FormatError as exc:
        result.problems.append(f"file no longer parses as {adapter.name}: {exc}")
        result.status = "tampered" if result.signature_valid else "invalid"
        trust_early = _assess_trust(certs, roots, signing_key, manifest, at_time, result)
        result.trust_status, result.trust = trust_early
        result.assurance = assess_assurance(
            signature_valid=result.signature_valid,
            trust_status=result.trust_status,
            certificates=certs,
            manifest=manifest,
        )
        result.time = _assess_timestamps(envelope, certs, timestamp_roots)
        return result

    result.body_intact = declared == len(base) and _m.hash_body(base) == digests.get("body")
    skeleton_now = _m.hash_chunks(
        elide_ranges(base, layout.payload_ranges(), _m.SKELETON_MARKER)
    )
    result.skeleton_intact = skeleton_now == digests.get("skeleton")
    result.payload_reports = _compare_payloads(adapter, base, layout, manifest)

    # -- trust -------------------------------------------------------------
    result.trust_status, result.trust = _assess_trust(
        certs, roots, signing_key, manifest, at_time, result
    )

    # -- overall -----------------------------------------------------------
    if not result.signature_valid:
        result.status = "invalid"
    elif result.body_intact:
        result.status = "valid"
    elif all(r.get("canonical_ok") for r in result.payload_reports) and result.payload_reports:
        result.status = "metadata-modified" if not result.skeleton_intact else "repackaged"
    else:
        result.status = "tampered"

    # Origin is assessed separately from integrity, and only reported once the
    # signature itself has been checked.  A perfectly intact frame can still be
    # worth nothing as evidence of where it came from.
    result.assurance = assess_assurance(
        signature_valid=result.signature_valid,
        trust_status=result.trust_status,
        certificates=certs,
        manifest=manifest,
    )
    result.time = _assess_timestamps(envelope, certs, timestamp_roots)
    return result


def _assess_timestamps(envelope: dict, certs, timestamp_roots) -> "TimeEvidence":
    """Check any timestamp tokens the envelope carries and rank what they prove.

    Tokens cover the **signature**, not the manifest -- see
    :func:`framesig.manifest.timestamped_value` for why the distinction decides
    whether the evidence is worth anything.

    A token that fails to parse is reported rather than raised: a broken
    timestamp must not stop a frame being verified, because integrity and time
    are separate questions and the answer to the first is still useful.
    """
    from .timestamp import TimestampError, TimeEvidence, assess_time_evidence, verify_token

    encoded = envelope.get("timestamps")
    if not isinstance(encoded, list) or not encoded:
        return assess_time_evidence([], certs)

    signature = envelope.get("signature", {}).get("value")
    try:
        digest = _m.timestamped_value(base64.b64decode(signature, validate=True))
    except (TypeError, ValueError):
        evidence = TimeEvidence()
        evidence.limits.append("the signature could not be read, so its timestamps mean nothing")
        return evidence

    tokens, broken = [], []
    for item in encoded[:8]:
        if not isinstance(item, str):
            continue
        try:
            tokens.append(
                verify_token(base64.b64decode(item, validate=True), digest,
                             roots=timestamp_roots)
            )
        except (TimestampError, ValueError) as exc:
            broken.append(str(exc))

    evidence = assess_time_evidence(tokens, certs)
    for problem in broken:
        evidence.limits.append(f"unusable timestamp token: {problem}")
    return evidence


def _candidate_keys(certs, public_keys, envelope, result):
    """Keys we may verify against, most authoritative first.

    Order matters only for reporting; a signature verifies under exactly one of
    them.  An externally supplied key outranks the envelope's own, because
    trusting a key the file brought with it is the thing the trust assessment
    then has to qualify.
    """
    if public_keys:
        # An explicitly supplied key is a *pinning* statement: verify under
        # these and nothing else.  Falling back to the key the file brought
        # with it would make --public-key decorative, since a forger who
        # re-signs with their own key also rewrites the embedded copy.
        return list(public_keys)

    keys: List = []
    if certs:
        keys.insert(0, certs[0].public_key())
    elif envelope.get("public_key"):
        from cryptography.hazmat.primitives.serialization import load_der_public_key

        try:
            keys.append(load_der_public_key(base64.b64decode(envelope["public_key"], validate=True)))
        except Exception as exc:  # noqa: BLE001 - malformed input, not a crash
            result.problems.append(f"envelope carries an unreadable public key: {exc}")
    if not keys:
        result.problems.append(
            "no public key available: the envelope carries neither a certificate "
            "nor a public key, and none was supplied"
        )
    return keys


def _authenticate_single(envelope: dict, public_keys, result: "VerificationResult"):
    """Verify a directly-signed frame envelope."""
    manifest_bytes, signature, algorithm, cert_ders = _m.decode_envelope(envelope)
    certs = [x509.load_der_x509_certificate(d) for d in cert_ders]
    keys = _candidate_keys(certs, public_keys, envelope, result)

    message = _m.signing_input(manifest_bytes)
    for key in keys:
        if verify_signature(key, message, signature, algorithm):
            result.signature_valid = True
            return manifest_bytes, certs, key
    if keys:
        result.problems.append("signature does not verify under any available public key")
    return manifest_bytes, certs, None


def _authenticate_series(envelope: dict, public_keys, result: "VerificationResult"):
    """Verify a frame that is covered by a signed series root, not directly."""
    import base64 as _b64

    from .series import verify_series_membership

    try:
        manifest_bytes = _b64.b64decode(envelope["manifest"], validate=True)
    except (KeyError, TypeError, ValueError) as exc:
        raise _m.EnvelopeError(f"malformed envelope: {exc}") from exc

    block = envelope["series"]
    series_env = block.get("envelope", {})
    cert_ders = [
        _b64.b64decode(c, validate=True) for c in series_env.get("certificates", [])
    ]
    certs = [x509.load_der_x509_certificate(d) for d in cert_ders]
    keys = _candidate_keys(certs, public_keys, series_env, result)

    ok, series_manifest, problems = verify_series_membership(manifest_bytes, block, keys)
    result.signature_valid = ok
    result.problems.extend(problems)
    if series_manifest:
        result.notes.append(
            f"covered by signed series {series_manifest.get('series_id')!r} "
            f"({series_manifest.get('count')} frames), frame index {block.get('index')}"
        )
    return manifest_bytes, certs, (keys[0] if ok and keys else None)


def _compare_payloads(adapter, base: bytes, layout, manifest: dict) -> List[dict]:
    recorded = manifest.get("payloads", [])
    reports = []
    if len(recorded) != len(layout.payloads):
        reports.append(
            {
                "id": "*",
                "stored_ok": False,
                "canonical_ok": False,
                "problem": f"payload count changed: signed {len(recorded)}, "
                f"file now has {len(layout.payloads)}",
            }
        )
        return reports
    for rec, p in zip(recorded, layout.payloads):
        stored = "sha256:" + hash_stream([base[p.start : p.end]])
        rep = {
            "id": rec.get("id"),
            "stored_ok": stored == rec.get("stored"),
            "canonical_ok": False,
        }
        if rep["stored_ok"]:
            rep["canonical_ok"] = True
        else:
            try:
                form, chunks = adapter.canonical_payload_stream(base, p)
                canonical = "sha256:" + hash_stream(chunks)
                rep["canonical_ok"] = (
                    form == rec.get("canonical_form") and canonical == rec.get("canonical")
                )
            except FormatError as exc:
                rep["problem"] = f"cannot decode payload to compare values: {exc}"
        if rec.get("id") != p.id:
            rep["problem"] = f"binary id changed: signed {rec.get('id')!r}, now {p.id!r}"
        reports.append(rep)
    return reports


def _assess_trust(certs, roots, signing_key, manifest, at_time, result):
    if not certs:
        if signing_key is not None:
            kid = key_id(signing_key)
            if kid == manifest.get("signer", {}).get("key_id"):
                return "bare-key", None
            result.problems.append("signer.key_id does not match the verifying key")
            return "key-mismatch", None
        return "unknown", None

    leaf = certs[0]
    if signing_key is not None and not public_key_matches(leaf, signing_key):
        result.problems.append("leaf certificate does not hold the signing key")
        return "key-mismatch", None

    if not roots:
        result.notes.append(
            "no trust anchor supplied; the certificate chain was not validated"
        )
        return "unvalidated", None

    when = at_time
    if when is None:
        created = manifest.get("created")
        if created:
            try:
                when = _dt.datetime.strptime(created, "%Y-%m-%dT%H:%M:%SZ").replace(
                    tzinfo=_dt.timezone.utc
                )
                result.notes.append(
                    "chain validated at the manifest's self-declared creation time; "
                    "without an RFC 3161 timestamp that time is an unverified claim"
                )
            except ValueError:
                when = None

    chain = verify_chain(leaf, certs[1:], roots, at_time=when)
    if chain.ok:
        return "trusted", chain
    result.problems.append(chain.reason or "certificate chain did not validate")
    return "untrusted", chain


def _is_signed_hdf5(path) -> bool:
    """An HDF5 file signed in place (SPEC §7.2). The magic bytes are checked
    first, so h5py is only imported for files that are HDF5 at all; an HDF5
    file without a /framesig group falls through to the sidecar check."""
    try:
        with open(path, "rb") as fh:
            if fh.read(8) != b"\x89HDF\r\n\x1a\n":
                return False
        from .hdf5_tree import is_signed_hdf5
    except (OSError, ImportError):
        return False
    return is_signed_hdf5(path)


def verify_file(
    path,
    *,
    roots: Sequence[x509.Certificate] = (),
    public_key_paths: Sequence[str] = (),
    sidecar=None,
    at_time: Optional[_dt.datetime] = None,
    timestamp_roots: Sequence[x509.Certificate] = (),
) -> VerificationResult:
    import pathlib

    path = pathlib.Path(path)
    if sidecar is None and _is_signed_hdf5(path):
        from .hdf5_tree import verify_hdf5

        return verify_hdf5(
            path, roots=roots,
            public_keys=[load_public_key(pathlib.Path(kp).read_bytes()) for kp in public_key_paths],
            at_time=at_time, timestamp_roots=timestamp_roots,
        )
    data = path.read_bytes()
    adapter = adapter_for(data)
    try:
        envelope, base, source = _load_envelope_for(path, data, adapter, sidecar)
    except (CorruptSignature, FormatError, json.JSONDecodeError, UnicodeDecodeError) as exc:
        r = VerificationResult(status="invalid")
        r.problems.append(str(exc))
        return r
    if envelope is None:
        r = VerificationResult(status="unsigned")
        r.problems.append(
            "no signature found: no embedded framesig block and no "
            f"{path.name}{SIDECAR_SUFFIX} sidecar"
        )
        return r

    keys = []
    for kp in public_key_paths:
        keys.append(load_public_key(pathlib.Path(kp).read_bytes()))

    result = verify_bytes(
        data, envelope, base, roots=roots, public_keys=keys, at_time=at_time,
        adapter=adapter, timestamp_roots=timestamp_roots,
    )
    result.notes.append(f"signature source: {source}")
    return result


def verify_data(
    data: bytes,
    *,
    roots: Sequence[x509.Certificate] = (),
    public_keys: Sequence[object] = (),
    sidecar: Optional[dict] = None,
    at_time: Optional[_dt.datetime] = None,
    timestamp_roots: Sequence[x509.Certificate] = (),
) -> VerificationResult:
    """Verify a frame that has no path -- one inside a container, say.

    Same logic as :func:`verify_file`; only the envelope discovery differs,
    since there is no directory to look for a sidecar in.
    """
    adapter = adapter_for(data)
    try:
        envelope, base, source = _load_envelope_for(None, data, adapter, None)
    except (CorruptSignature, FormatError, json.JSONDecodeError, UnicodeDecodeError) as exc:
        r = VerificationResult(status="invalid")
        r.problems.append(str(exc))
        return r
    if envelope is None:
        envelope, source = sidecar, "sidecar"
    if envelope is None:
        r = VerificationResult(status="unsigned")
        r.problems.append("no signature found: no embedded framesig block and no sidecar")
        return r

    result = verify_bytes(
        data, envelope, base, roots=roots, public_keys=public_keys,
        at_time=at_time, adapter=adapter, timestamp_roots=timestamp_roots,
    )
    result.notes.append(f"signature source: {source}")
    return result


def envelope_of(data: bytes, sidecar: Optional[dict] = None) -> Optional[dict]:
    """The signature envelope of a frame, or None if it carries no readable one.

    Separate from verification on purpose: an audit has to enumerate the signers
    of a file whose signature has *stopped* verifying, which is exactly the case
    a withdrawal creates.
    """
    from .formats.cbf import CbfAdapter, read_block

    envelope = sidecar
    offset = CbfAdapter()._find_block(data)
    if offset is not None:
        try:
            envelope = json.loads(read_block(data[offset:]).decode("utf-8"))
        except (FormatError, UnicodeDecodeError, json.JSONDecodeError):
            return None
    return envelope if isinstance(envelope, dict) else None


def inventory_of(data: bytes, sidecar: Optional[dict] = None,
                 via: Optional[str] = None) -> list:
    """Which signing identities this frame depends on.

    Returns :class:`framesig.inventory.SignerRef` rows covering the whole
    certificate chain the file carries -- not just the leaf, because a
    withdrawal of the authority behind a key is invisible from the key alone.
    """
    from .inventory import inventory_from_envelope

    envelope = envelope_of(data, sidecar)
    return inventory_from_envelope(envelope, via=via) if envelope else []


def manifest_bytes_of(data: bytes, sidecar: Optional[dict] = None) -> Optional[bytes]:
    """The exact signed manifest bytes of a frame, or None if it is unsigned.

    This is a frame's identity inside a bundle, so it has to come from the
    envelope as stored rather than from anything re-serialised.
    """
    from .formats.cbf import CbfAdapter, read_block

    envelope = sidecar
    offset = CbfAdapter()._find_block(data)
    if offset is not None:
        try:
            envelope = json.loads(read_block(data[offset:]).decode("utf-8"))
        except (FormatError, UnicodeDecodeError, json.JSONDecodeError):
            return None
    if not envelope or "manifest" not in envelope:
        return None
    try:
        return base64.b64decode(envelope["manifest"], validate=True)
    except (TypeError, ValueError):
        return None


def inspect_file(path) -> dict:
    """Structural report with no crypto: what the adapter sees in the file."""
    import pathlib

    data = pathlib.Path(path).read_bytes()
    adapter = adapter_for(data)
    layout = adapter.parse(data)
    return {
        "format": adapter.name,
        "profile": adapter.profile,
        "size": len(data),
        "signed_length": layout.signed_length,
        "has_signature_block": layout.block_offset is not None,
        "payloads": [
            {
                "id": p.id,
                "offset": p.start,
                "length": p.length,
                "encoding": p.encoding,
                "element_type": p.element_type,
                "byte_order": p.byte_order,
                "dimensions": p.dimensions,
                "n_elements": p.n_elements,
                "content_md5": p.extra.get("content_md5"),
            }
            for p in layout.payloads
        ],
    }
