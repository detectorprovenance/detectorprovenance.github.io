"""Per-frame work across processes; the one signature stays in the caller."""

from __future__ import annotations

import os
from concurrent.futures import ProcessPoolExecutor
from typing import Callable, Iterable, Iterator, Optional


def default_jobs() -> int:
    return getattr(os, "process_cpu_count", os.cpu_count)() or 1


def ordered_map(fn: Callable, items: Iterable, jobs: Optional[int] = None) -> Iterator:
    """``map(fn, items)`` in input order over *jobs* processes (1: in-process).

    *fn* must be a module-level function: Windows and macOS start workers by
    re-importing, not forking.
    """
    items = list(items)
    jobs = min(jobs or default_jobs(), len(items))
    if jobs <= 1:
        yield from map(fn, items)
        return
    # ponytail: Executor.map queues every item up front, so finished results
    # wait in memory if the caller is slower than the pool; fine while the
    # caller only copies bytes, bound the window if it ever does real work.
    ex = ProcessPoolExecutor(jobs)
    try:
        yield from ex.map(fn, items)
    finally:
        # A failed frame must not wait for the rest of a 3600-frame run.
        ex.shutdown(cancel_futures=True)
