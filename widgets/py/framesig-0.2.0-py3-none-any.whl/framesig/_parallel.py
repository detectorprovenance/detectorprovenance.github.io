"""Per-frame work across processes; the one signature stays in the caller."""

from __future__ import annotations

import multiprocessing
import os
import sys
from typing import Callable, Iterable, Iterator, Optional


def default_jobs() -> int:
    return getattr(os, "process_cpu_count", os.cpu_count)() or 1


def ordered_map(fn: Callable, items: Iterable, jobs: Optional[int] = None) -> Iterator:
    """``map(fn, items)`` in input order over *jobs* processes (1: in-process).

    *fn* must be a module-level function: Windows and macOS start workers by
    re-importing, not forking.
    """
    items = list(items)
    jobs = min(jobs or default_jobs(), len(items))
    if jobs <= 1 or not _workers_can_be_safe():
        yield from map(fn, items)
        return
    # Imported here: Pyodide has no _multiprocessing, and the website's
    # in-browser verifier imports run_h5 (which never starts a pool).
    from concurrent.futures import ProcessPoolExecutor
    # A spawned worker (Windows, macOS; Linux forkserver) starts as
    # `python -c "from multiprocessing.spawn import ..."`, and -c puts the
    # current directory first on sys.path: a multiprocessing/ or numpy.py in
    # the data directory would run in every worker, however the parent was
    # launched. PYTHONSAFEPATH stops that, and workers inherit the process
    # environment, so it is set for the pool's lifetime (workers may be started
    # lazily) and put back afterwards.
    # ponytail: process-wide while the pool lives; two pools in two threads
    # could restore it early, a lock if framesig ever runs pools concurrently.
    saved = os.environ.get("PYTHONSAFEPATH")
    os.environ["PYTHONSAFEPATH"] = "1"
    # ponytail: Executor.map queues every item up front, so finished results
    # wait in memory if the caller is slower than the pool; fine while the
    # caller only copies bytes, bound the window if it ever does real work.
    ex = ProcessPoolExecutor(jobs)
    try:
        yield from ex.map(fn, items)
    finally:
        # A failed frame must not wait for the rest of a 3600-frame run.
        ex.shutdown(cancel_futures=True)
        if saved is None:
            os.environ.pop("PYTHONSAFEPATH", None)
        else:
            os.environ["PYTHONSAFEPATH"] = saved


def _workers_can_be_safe() -> bool:
    """Can a worker be kept from importing out of the current directory?

    Forked workers never re-run the interpreter. Otherwise it takes
    PYTHONSAFEPATH, which Python before 3.11 ignores and which a parent run
    with -E passes on as -E (unless -P or -I come with it). No pool then:
    slower, never unsafe.
    """
    if multiprocessing.get_start_method() == "fork":
        return True
    return sys.version_info >= (3, 11) and (
        sys.flags.safe_path or not sys.flags.ignore_environment)
