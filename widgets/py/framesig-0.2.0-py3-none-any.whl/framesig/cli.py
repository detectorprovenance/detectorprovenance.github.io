"""Command line interface.

    framesig keygen        make a signing key
    framesig ca init       stand up a demo vendor root + issuing CA
    framesig ca issue      issue a detector unit certificate
    framesig sign          sign one frame
    framesig sign-derived  sign a processed frame, naming the signed inputs it came from
    framesig verify-chain  verify a derived frame and each link back to its sources
    framesig sign-series   sign a run with one signature over a Merkle root
    framesig pack-run      pack a run into one HDF5 stack, signed once
    framesig verify-run    verify a packed Run-HDF5 frame by frame
    framesig checkpoint    sign a checkpoint over the frames acquired so far
    framesig verify-checkpoints  check frames against signed checkpoints
    framesig verify        verify one or many frames
    framesig inspect       structural report, no cryptography
    framesig bundle create sign a set of frames as one dataset (counts, runs, DOI)
    framesig bundle verify check a bundle against the frames it names
    framesig bundle extract take the frames back out of a single-file bundle
    framesig bundle list   list what is inside a single-file bundle
    framesig oids          show the object identifiers this build uses
    framesig view          folder browser with per-frame validation badges
"""

from __future__ import annotations

import argparse
import base64
import glob
import json
import pathlib
import re
import sys
from typing import List

from cryptography import x509

from . import __version__
from ._fs import atomic_write
from .api import SIDECAR_SUFFIX, inspect_file, sign_file, verify_file
from .keys import (
    ALGORITHMS,
    ALG_ECDSA_P256,
    ALG_ED25519,
    SoftwareSigner,
    generate_private_key,
    key_id,
    load_private_key,
    private_key_pem,
    public_key_pem,
)
from .attestation import ASSURANCE_INSTRUMENT, ASSURANCE_ORDER
from .container import CONTAINER_SUFFIXES
from .revocation import REASONS
from .keystore import (
    PLAINTEXT_OPT_IN,
    KeyCustodyError,
    check_key_file_permissions,
    load_private_key_for,
    read_private_key,
    resolve_passphrase,
    write_private_key,
)
from .inventory import ref_from_certificate
from .pki import (
    certificate_der,
    load_certificates_pem,
    make_device_certificate,
    make_intermediate_ca,
    make_root_ca,
)

EXIT_OK = 0
EXIT_BAD = 1
EXIT_USAGE = 2

_STATUS_EXIT = {
    "valid": EXIT_OK,
    "repackaged": EXIT_OK,
    "metadata-modified": EXIT_BAD,
    "tampered": EXIT_BAD,
    "invalid": EXIT_BAD,
    "unsigned": EXIT_BAD,
}


def _write(path: pathlib.Path, data: bytes, secret: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write(path, data, 0o600 if secret else None)  # 0600 from creation, not after


def _load_roots(paths: List[str]) -> List[x509.Certificate]:
    roots: List[x509.Certificate] = []
    for p in paths:
        roots.extend(load_certificates_pem(pathlib.Path(p).read_bytes()))
    return roots


def _expand(patterns: List[str]) -> List[pathlib.Path]:
    out: List[pathlib.Path] = []
    for pat in patterns:
        p = pathlib.Path(pat)
        if p.is_dir():
            out.extend(sorted(q for q in p.iterdir() if q.is_file()
                              and q.suffix.lower() in (".cbf", ".img", ".mccd")))
        elif any(ch in pat for ch in "*?["):
            out.extend(sorted(pathlib.Path(m) for m in glob.glob(pat)))
        else:
            out.append(p)
    return out


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------

def _load_ca_key(path, args):
    return load_private_key_for(
        path,
        env_var=getattr(args, "password_env", None),
        file_path=getattr(args, "password_file", None),
        prompt="Passphrase for the CA private key: ",
    )


def _passphrase_args(sp, *, creating: bool):
    """Passphrase sources -- never argv.

    A passphrase on the command line is visible in `ps`, in Task Manager, in
    shell history and in CI logs. It is one of the most reliable ways to leak a
    key, and it looks perfectly safe, so the option simply does not exist.
    """
    sp.add_argument("--password-env", metavar="VAR",
                    help="read the passphrase (or hardware-key PIN) from this environment variable")
    sp.add_argument("--password-file", metavar="PATH",
                    help="read the passphrase (or hardware-key PIN) from this file "
                         "(trailing newline stripped)")
    if creating:
        sp.add_argument(
            PLAINTEXT_OPT_IN,
            action="store_true",
            help="write the private key with no encryption at all (do not do this)",
        )


def cmd_keygen(args) -> int:
    key = generate_private_key(args.algorithm)
    priv = pathlib.Path(args.out)
    pub = priv.with_suffix(".pub.pem")

    passphrase = None
    if not args.i_accept_an_unencrypted_key:
        passphrase = resolve_passphrase(
            env_var=args.password_env,
            file_path=args.password_file,
            confirm=True,
            prompt="Passphrase to protect the new private key: ",
        )
    write_private_key(
        key, priv, passphrase,
        allow_plaintext=args.i_accept_an_unencrypted_key,
        encoding=args.encoding,
    )
    _write(pub, public_key_pem(key.public_key()))

    print(f"private key: {priv}  ({'encrypted ' if passphrase else 'UNENCRYPTED '}"
          f"PKCS#8 {args.encoding.upper()})")
    print(f"public key:  {pub}")
    print(f"algorithm:   {args.algorithm}")
    print(f"key id:      {key_id(key.public_key())}")
    if not passphrase:
        print()
        print("WARNING: this key is stored in the clear. Anyone who can read that file")
        print("can sign frames that verify as yours. Prefer a device-held key:")
        print("    framesig tpm create <name>")
    warning = check_key_file_permissions(priv)
    if warning:
        print(f"WARNING: {warning}")
    return EXIT_OK


#: Where ``ca init --issuing-crl-url`` records the issuing CA's list address,
#: so that ``ca issue`` writes it into every unit certificate by default.
_ISSUING_CRL_FILE = "issuing.crl-url"


def _http_url(value: str) -> str:
    # A distribution point that is not HTTP(S) is ignored by --online, which
    # would leave every certificate naming it uncheckable (suspect) for good;
    # so would one with a space or a stray newline in it, which no fetch can
    # follow. Non-ASCII has to arrive IDNA/percent-encoded (an X.509 URI is IA5).
    if not re.fullmatch(r"https?://[!-~]+", value, re.IGNORECASE):
        raise argparse.ArgumentTypeError(f"not an http(s) URL: {value!r}")
    return value


def cmd_ca_init(args) -> int:
    out = pathlib.Path(args.dir)
    root_key = generate_private_key(args.algorithm)
    root_cert = make_root_ca(root_key, f"{args.org} Detector Root CA", args.org)
    sub_key = generate_private_key(args.algorithm)
    sub_cert = make_intermediate_ca(
        root_key, root_cert, sub_key, f"{args.org} Detector Issuing CA", args.org,
        crl_url=args.root_crl_url,
    )
    from cryptography.hazmat.primitives.serialization import Encoding

    passphrase = None
    if not args.i_accept_an_unencrypted_key:
        passphrase = resolve_passphrase(
            env_var=args.password_env, file_path=args.password_file, confirm=True,
            prompt="Passphrase to protect the CA private keys: ",
        )
    write_private_key(root_key, out / "root.key.pem", passphrase,
                      allow_plaintext=args.i_accept_an_unencrypted_key, encoding="der")
    _write(out / "root.cert.pem", root_cert.public_bytes(Encoding.PEM))
    write_private_key(sub_key, out / "issuing.key.pem", passphrase,
                      allow_plaintext=args.i_accept_an_unencrypted_key, encoding="der")
    _write(out / "issuing.cert.pem", sub_cert.public_bytes(Encoding.PEM))
    if args.issuing_crl_url:
        _write(out / _ISSUING_CRL_FILE, args.issuing_crl_url.encode("utf-8") + b"\n")
    print(f"vendor root CA:    {out / 'root.cert.pem'}  (this is the public trust anchor)")
    print(f"issuing CA:        {out / 'issuing.cert.pem'}")
    print("keep root.key.pem offline; in production the root never signs a frame")
    lists = [(u, n) for u, n in ((args.root_crl_url, "root"),
                                 (args.issuing_crl_url, "issuing")) if u]
    if lists:
        print("\npublish a signed list at each address, even while nothing is withdrawn;")
        print("until one is there, every certificate naming it verifies as suspect:")
        for url, name in lists:
            print(f"  framesig revoke create --empty --issuer \"{args.org}\" "
                  f"--key {out / (name + '.key.pem')} --cert {out / (name + '.cert.pem')} "
                  f"--next-update <date> --out <the file served at {url}>")
    return EXIT_OK


def cmd_ca_issue(args) -> int:
    from cryptography.hazmat.primitives.serialization import Encoding, load_pem_public_key

    ca_dir = pathlib.Path(args.ca)
    ca_key, _ = _load_ca_key(ca_dir / "issuing.key.pem", args)
    ca_cert = load_certificates_pem((ca_dir / "issuing.cert.pem").read_bytes())[0]
    pub = load_pem_public_key(pathlib.Path(args.public_key).read_bytes())
    crl_url = args.crl_url
    recorded = ca_dir / _ISSUING_CRL_FILE
    if crl_url is None and recorded.is_file():
        try:
            crl_url = _http_url(recorded.read_text(encoding="utf-8", errors="replace")[:4096]
                                .strip())
        except argparse.ArgumentTypeError as exc:
            print(f"{recorded}: {exc}", file=sys.stderr)
            return EXIT_USAGE
    cert = make_device_certificate(
        ca_key, ca_cert, pub, args.serial, args.model, args.org,
        instrument_attested=args.instrument_attested, crl_url=crl_url or None,
    )
    chain = cert.public_bytes(Encoding.PEM) + ca_cert.public_bytes(Encoding.PEM)
    _write(pathlib.Path(args.out), chain)
    ref = ref_from_certificate(cert)
    print(f"unit certificate chain: {args.out}")
    print(f"  subject: CN={args.serial}, OU={args.model}, O={args.org}")
    print(f"  key id:  {ref.key_id}")
    print(f"  cert:    {ref.cert}  (what 'revoke create --cert-digest' names)")
    print(f"  list:    {crl_url or 'none named; --online cannot check this unit'}")
    if args.instrument_attested:
        print("  policy:  instrument-attested (key inside the instrument)")
    else:
        print("  policy:  custodial (software- or facility-held key)")
        print("  frames signed with this key cannot reach instrument-level assurance.")
    return EXIT_OK


def _signer_and_certs(args):
    tpm_key = getattr(args, "tpm_key", None)
    if tpm_key:
        from .signers import HardwareSigner, tpm_key_requires_auth

        auth = None
        if tpm_key_requires_auth(tpm_key):
            auth = resolve_passphrase(
                env_var=getattr(args, "password_env", None),
                file_path=getattr(args, "password_file", None),
                prompt=f"PIN for hardware key {tpm_key!r}: ",
            )
        else:
            print(
                f"WARNING: hardware key {tpm_key!r} has no PIN; any process running as "
                "this user can sign with it. Recreate it with 'framesig tpm create' to "
                "bind one.",
                file=sys.stderr,
            )
        signer = HardwareSigner(tpm_key, auth=auth)
    elif args.key:
        key, encrypted = load_private_key_for(
            args.key, env_var=args.password_env, file_path=args.password_file
        )
        if not encrypted:
            print(
                f"WARNING: {args.key} holds an unencrypted private key; anyone who can "
                "read that file can forge your signatures.",
                file=sys.stderr,
            )
        warning = check_key_file_permissions(args.key)
        if warning:
            print(f"WARNING: {warning}", file=sys.stderr)
        signer = SoftwareSigner(key)
    else:
        raise SystemExit("supply a signing key with --key, or a TPM key with --tpm-key")
    certs = []
    # --cert is one path when signing, repeatable for 'revoke create'.
    for path in [args.cert] if isinstance(args.cert, str) else (args.cert or []):
        certs.extend(load_certificates_pem(pathlib.Path(path).read_bytes()))
    return signer, certs


def cmd_tpm_check(args) -> int:
    from .signers import tpm_available

    ok, detail = tpm_available()
    print(("available: " if ok else "unavailable: ") + detail)
    if ok:
        print(
            "Keys created here are non-exportable: the private key is generated inside\n"
            "the TPM and cannot be read out by framesig or by anything else."
        )
    return EXIT_OK if ok else EXIT_BAD


def cmd_tpm_create(args) -> int:
    from .signers import tpm_create_key

    unprotected = args.i_accept_an_unprotected_hardware_key
    auth = None
    if not unprotected:
        auth = resolve_passphrase(
            env_var=args.password_env, file_path=args.password_file, confirm=True,
            prompt="PIN to authorize every signature with the new key: ",
        )
    public = tpm_create_key(args.name, auth=auth, allow_unprotected=unprotected)
    out = pathlib.Path(args.out) if args.out else pathlib.Path(f"{args.name}.pub.pem")
    _write(out, public_key_pem(public))
    print(f"TPM key created: {args.name}")
    print(f"public key:      {out}")
    print(f"key id:          {key_id(public)}")
    print(f"algorithm:       {ALG_ECDSA_P256}")
    print("\nThe private key is inside the TPM and cannot be exported.")
    print(f"Share {out} with anyone who needs to verify; it reveals nothing secret.")
    if unprotected:
        print("\nWARNING: this key has no PIN. Nothing can copy it, but any process running")
        print("as this user can sign with it. Recreate it without")
        print("--i-accept-an-unprotected-hardware-key to bind one.")
    else:
        print("Every signature needs the PIN: --tpm-key reads it from --password-env,")
        print("--password-file or a prompt.")
    return EXIT_OK


def cmd_tpm_export(args) -> int:
    from .signers import tpm_public_key

    public = tpm_public_key(args.name)
    out = pathlib.Path(args.out) if args.out else pathlib.Path(f"{args.name}.pub.pem")
    _write(out, public_key_pem(public))
    print(f"public key: {out}")
    print(f"key id:     {key_id(public)}")
    return EXIT_OK


def cmd_tpm_delete(args) -> int:
    from .signers import tpm_delete_key

    tpm_delete_key(args.name)
    print(f"deleted TPM key {args.name!r}")
    print("Frames already signed with it can no longer be re-signed, but they")
    print("remain verifiable: verification only ever needed the public key.")
    return EXIT_OK


def _claims_from(args) -> dict:
    claims = {}
    if args.claim:
        for item in args.claim:
            if "=" not in item:
                raise SystemExit(f"--claim expects key=value, got {item!r}")
            k, _, v = item.partition("=")
            claims[k.strip()] = v.strip()
    if args.claims_file:
        claims.update(json.loads(pathlib.Path(args.claims_file).read_text("utf-8")))
    return claims


def _attestation_from(args) -> dict:
    """Build the instrument attestation block.

    Refuses to invent one. A signer that quietly stamps `mode=physical` on
    everything would make the whole assurance ladder decorative, so the mode has
    to be stated and has to be a mode we know.
    """
    from .attestation import ACQUISITION_MODES

    att = {}
    for item in getattr(args, "attest", None) or []:
        if "=" not in item:
            raise SystemExit(f"--attest expects key=value, got {item!r}")
        k, _, v = item.partition("=")
        att[k.strip()] = v.strip()
    if not att:
        return {}
    mode = att.get("mode")
    if mode is None:
        raise SystemExit(
            "--attest requires mode=... ; one of: " + ", ".join(sorted(ACQUISITION_MODES))
        )
    if mode not in ACQUISITION_MODES:
        raise SystemExit(
            f"unknown acquisition mode {mode!r}; expected one of: "
            + ", ".join(sorted(ACQUISITION_MODES))
        )
    return att


def cmd_sign(args) -> int:
    signer, certs = _signer_and_certs(args)
    claims = _claims_from(args)
    attestation = _attestation_from(args)
    files = _expand(args.files)
    if not files:
        print("no input files matched", file=sys.stderr)
        return EXIT_USAGE
    for f in files:
        report = sign_file(
            f,
            signer,
            embed=not args.sidecar,
            output=args.output,
            certificates=certs,
            claims=claims or None,
            attestation=attestation or None,
            format_name=args.format,
        )
        if report.get("container"):
            print(f"signed {report['signed']} in place ({report['payloads']} array(s) and the "
                  "metadata tree covered)")
        else:
            print(
                f"signed {report['signed']} -> {report['signature']} "
                f"({report['payloads']} payload(s), {report['signed_length']} bytes covered)"
            )
    return EXIT_OK


def cmd_sign_derived(args) -> int:
    from .derivation import references_for

    files = _expand(args.files)
    if not files:
        print("no input files matched", file=sys.stderr)
        return EXIT_USAGE
    inputs = _expand(args.input)
    targets = files + ([pathlib.Path(args.output)] if args.output else [])
    if {t.resolve() for t in targets} & {i.resolve() for i in inputs}:
        raise ValueError("an output cannot be its own input: signing it would replace "
                         "the very signature it names")
    # Resolved before the key is touched: an input that does not verify is
    # refused without prompting for a passphrase or a TPM authorisation.
    parents = references_for(inputs)
    signer, certs = _signer_and_certs(args)
    claims = _claims_from(args)
    for f in files:
        report = sign_file(
            f,
            signer,
            embed=not args.sidecar,
            output=args.output,
            certificates=certs,
            claims=claims or None,
            parents=parents,
            format_name=args.format,
        )
        print(f"signed {report['signed']} -> {report['signature']} "
              f"(derived from {len(parents)} signed input(s))")
    return EXIT_OK


def cmd_verify_chain(args) -> int:
    from .derivation import verify_derivation
    from .keys import load_public_key

    report = verify_derivation(
        args.file,
        _expand(args.input or []),
        roots=_load_roots(args.trust or []),
        public_keys=[load_public_key(pathlib.Path(k).read_bytes())
                     for k in (args.public_key or [])],
        timestamp_roots=_load_roots(args.timestamp_trust or []),
    )
    # Each link answers to its own bar: a source frame (one that names no
    # inputs) is where instrument origin lives, a processing step can at most
    # be custodial.  A complete chain of self-attested links is still WEAK.
    weak = []
    for link in report["links"]:
        need = args.require_processing if link["derived"] else args.require
        link["meets_requirement"] = (
            ASSURANCE_ORDER.index(link["assurance"]) >= ASSURANCE_ORDER.index(need))
        if not link["meets_requirement"]:
            weak.append(link)
    code = EXIT_OK if report["chain"] == "complete" and not weak else EXIT_BAD

    if args.json:
        print(json.dumps(report, indent=2))
        return code
    for link in report["links"]:
        role = "processing" if link["derived"] else "source"
        mark = ("FAIL" if link["status"] not in ("valid", "repackaged")
                else "OK  " if link["meets_requirement"] else "WEAK")
        print(f"{'  ' * min(link['depth'], 8)}{mark} {link['status']:10s} "
              f"{link['assurance']:14s} {role:10s} {link['file']}")
        pad = "  " * min(link["depth"], 8) + "     "
        print(f"{pad}signer: {link['signer']!r}, time: {link['time']}")
        for p in link["problems"]:
            print(f"{pad}! {p}")
        for i in link["inputs"]:
            print(f"{pad}<- {i['name']!r} {i['manifest'][:19]}...: {i['state']}"
                  + (f" ({i['file']})" if i["file"] and i["state"] != "found" else ""))
    for p in report["problems"]:
        print(f"! {p}")
    for u in report["unused"]:
        print(f"! supplied but named by no link: {u}")
    print()
    print(f"chain: {report['chain']} ({len(report['links'])} link(s) checked, "
          f"{len(report['missing'])} input(s) missing)")
    if report["missing"]:
        print("a missing input is unverified, not clean: supply it with --input")
    if weak:
        print(f"{len(weak)} link(s) below the required assurance "
              f"(--require {args.require} for sources, "
              f"--require-processing {args.require_processing} for processing steps)")
    return code


def cmd_pack_run(args) -> int:
    from .pki import certificate_der
    from .run_h5 import pack_run

    signer, certs = _signer_and_certs(args)
    files = _expand(args.files)
    if not files:
        print("no input files matched", file=sys.stderr)
        return EXIT_USAGE
    pack_run(files, args.out, signer, series_id=args.series_id,
             certificates_der=[certificate_der(c) for c in certs],
             claims=_claims_from(args) or None, attestation=_attestation_from(args) or None,
             jobs=args.jobs, timestamp_urls=args.tsa_url or ())
    print(f"packed {len(files)} frames into {args.out}, one signature")
    return EXIT_OK


def cmd_verify_run(args) -> int:
    from .keys import load_public_key
    from .run_h5 import verify_run

    from .revocation import RevocationSet, verify_revocation_list

    keys = [load_public_key(pathlib.Path(k).read_bytes()) for k in (args.public_key or [])]
    revocations = None
    if args.revocations:
        revocations = verify_revocation_list(
            json.loads(pathlib.Path(args.revocations).read_text(encoding="utf-8")),
            public_keys=[load_public_key(pathlib.Path(k).read_bytes())
                         for k in (args.revocations_key or [])],
            source=args.revocations)
    r = verify_run(args.file, keys, roots=_load_roots(args.trust or []),
                   timestamp_roots=_load_roots(args.timestamp_trust or []),
                   revocations=revocations, online=args.online)
    if args.json:
        print(json.dumps(r, indent=2, default=str))
        return EXIT_OK if r["ok"] else EXIT_BAD
    bad = sum(f["status"] != "repackaged" for f in r["frames"])
    print(f"run: {r['status']}" + (f" ({bad} of {len(r['frames'])} frame(s) differ from what was signed)"
                                   if bad else ""))
    for p in r["problems"]:
        print(f"FAIL {p}")
    for f in r["frames"]:
        tag = "OK  " if f["status"] == "repackaged" else "FAIL"
        print(f"{tag} {f['status']:<18} frame {f['index']}" +
              (f"  ({'; '.join(f['problems'])})" if f["problems"] else ""))
    trust = r["trust"] or {}
    if trust:
        print(f"signer: {trust['status']}" + "".join(f"\n  {n}" for n in trust["problems"] + trust["notes"]))
    if r["time"]:
        print(f"time: {r['time']['level']}" +
              (f", no later than {r['time']['established_at']}" if r["time"].get("established_at") else "") +
              "".join(f"\n  {n}" for n in r["time"].get("limits", [])))
    if r["revocation"]:
        print(r["revocation"]["list"])
        for i in r["revocation"]["identities"]:
            print(f"  {i['state']:8s} {i['role']:12s} {i['identity']}: {i['headline']}")
    if r["intact"] and not r["pinned"] and trust.get("status") != "trusted":
        print("FAIL origin not established: intact against the key inside the file, "
              "which proves integrity, not who signed; pass --public-key or --trust")
    return EXIT_OK if r["ok"] else EXIT_BAD


def _series_signer(args):
    """Signer, certificate chain and the ``signer`` block frame manifests carry."""
    from .pki import public_key_matches, subject_string

    signer, certs = _signer_and_certs(args)
    if certs and not public_key_matches(certs[0], signer.public_key):
        print("leaf certificate does not match the signing key", file=sys.stderr)
        raise SystemExit(EXIT_USAGE)
    signer_info = {"key_id": signer.key_id, "alg": signer.algorithm}
    if certs:
        signer_info["subject"] = subject_string(certs[0])
    return signer, certs, signer_info


def cmd_sign_series(args) -> int:
    from ._canon import canonicalize
    from ._parallel import ordered_map
    from .api import series_frame_manifest
    from .formats import adapter_by_name, adapter_for
    from .formats.cbf import make_block
    from . import manifest as _m
    from .pki import certificate_der
    from .series import build_series

    signer, certs, signer_info = _series_signer(args)
    claims = _claims_from(args)
    attestation = _attestation_from(args)
    files = _expand(args.files)
    if not files:
        print("no input files matched", file=sys.stderr)
        return EXIT_USAGE

    # A run that was checkpointed keeps the manifests its checkpoints signed,
    # so the series chain_head extends them; none of them knew the count.
    manifests = []
    if args.checkpoints:
        if not pathlib.Path(args.checkpoints).exists():
            print(f"{args.checkpoints} does not exist", file=sys.stderr)
            return EXIT_USAGE
        manifests = [m for _, m in _checkpointed_prefix(
            args.checkpoints, args.series_id, files, signer)[1]]
    count = None if args.checkpoints else len(files)
    work = [(f, args.format, i, count, args.series_id, signer_info,
             claims or None, attestation or None)
            for i, f in enumerate(files) if i >= len(manifests)]
    for i, m in enumerate(ordered_map(series_frame_manifest, work, args.jobs), len(manifests)):
        manifests.append(m)
        print(f"  hashed [{i + 1}/{len(files)}] {files[i].name}")

    series_env, frame_envs = build_series(
        manifests,
        signer,
        series_id=args.series_id,
        certificates_der=[certificate_der(c) for c in certs],
        claims=claims or None,
    )
    if args.checkpoints:
        # verify-checkpoints --series pairs frames with state manifests: the
        # frames after the last checkpoint must be in it too.
        _write_state(args.checkpoints, [(f.name, m) for f, m in zip(files, manifests)])

    # Files are read a second time rather than held: a 3600-frame 6M run does
    # not fit in memory. A file that changed since it was hashed is refused,
    # or its envelope would be written next to bytes it does not cover.
    for f, manifest, env in zip(files, manifests, frame_envs):
        data = f.read_bytes()
        adapter = adapter_by_name(args.format) if args.format else adapter_for(data)
        base = adapter.normalise_base(adapter.strip(data))
        if _m.hash_body(base) != json.loads(manifest)["digests"]["body"]:
            print(f"{f} changed while the series was being signed; nothing "
                  f"written for it or the frames after it", file=sys.stderr)
            return EXIT_BAD
        env_json = canonicalize(env)
        if args.sidecar or not adapter.supports_embedding:
            atomic_write(f.with_name(f.name + SIDECAR_SUFFIX),
                json.dumps(env, indent=2).encode("utf-8") + b"\n"
            )
        else:
            atomic_write(f, base + make_block(env_json))

    root = json.loads(
        __import__("base64").b64decode(series_env["manifest"])
    )["merkle_root"]
    if args.series_out:
        atomic_write(args.series_out,
            json.dumps(series_env, indent=2).encode("utf-8") + b"\n"
        )
        print(f"series envelope: {args.series_out}")
    print(f"signed series {args.series_id!r}: {len(files)} frames, one signature")
    print(f"merkle root: {root}")
    return EXIT_OK


# --------------------------------------------------------------------------
# acquisition checkpoints (SPEC §7.1)
# --------------------------------------------------------------------------

_STATE_SPEC = "framesig-checkpoint-state/1"
_MAX_CHECKPOINTS = 1 << 20  # each costs one signature check


def _state_path(checkpoints) -> pathlib.Path:
    p = pathlib.Path(checkpoints)
    return p.with_name(p.name + ".state")


def _read_state(path):
    """``[(file name, frame manifest bytes)]`` from the unsigned state file."""
    try:
        doc = json.loads(pathlib.Path(path).read_text(encoding="utf-8"))
        if doc["spec"] != _STATE_SPEC:
            raise ValueError(f"not a {_STATE_SPEC} file")
        return [(str(e["name"]), base64.b64decode(e["manifest"], validate=True))
                for e in doc["frames"]]
    except (KeyError, TypeError) as exc:
        raise ValueError(f"{path}: malformed checkpoint state: {exc!r}") from None


def _write_state(checkpoints, entries) -> None:
    _write(_state_path(checkpoints), json.dumps({"spec": _STATE_SPEC, "frames": [
        {"name": n, "manifest": base64.b64encode(m).decode("ascii")} for n, m in entries
    ]}).encode("utf-8") + b"\n")


def _read_checkpoints(path) -> list:
    p = pathlib.Path(path)
    if not p.exists():
        return []
    envs = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(envs, list):
        raise ValueError(f"{p}: not a list of checkpoint envelopes")
    return envs


def _checkpointed_prefix(checkpoints, series_id, files, signer):
    """``(envelopes, [(name, manifest)])`` for what the last checkpoint covers.

    The state file is unsigned working data, trusted only as far as the last
    checkpoint reproduces from it under this signer's key. Editing it can make
    this refuse; it cannot make a new checkpoint vouch for frames the earlier
    ones did not, and the uncovered tail is always hashed again.
    """
    from .series import verify_checkpoints

    envs = _read_checkpoints(checkpoints)
    if not envs:
        return [], []
    state = _state_path(checkpoints)
    if not state.exists():
        raise SystemExit(f"{checkpoints} holds checkpoints but {state} is missing; "
                         "restore it or start a new checkpoints file")
    entries = _read_state(state)
    ok, covered, problems = verify_checkpoints(
        envs[-1:], [m for _, m in entries], [signer.public_key])
    if not ok:
        raise SystemExit(f"the last checkpoint in {checkpoints} does not reproduce from "
                         f"{state} under this key: " + "; ".join(problems))
    signed_id = json.loads(base64.b64decode(envs[-1]["manifest"]))["series_id"]
    if signed_id != series_id:
        raise SystemExit(f"{checkpoints} belongs to series {signed_id!r}, not {series_id!r}")
    entries = entries[:covered]
    if len(files) < covered:
        raise SystemExit(f"{len(files)} frames given, but {checkpoints} already covers {covered}")
    for i, (f, (name, _)) in enumerate(zip(files, entries)):
        if f.name != name:
            raise SystemExit(f"frame {i} is {f.name}, but the checkpoints signed {name} "
                             "there; give the frames in acquisition order")
    return envs, entries


def cmd_checkpoint(args) -> int:
    from ._parallel import ordered_map
    from .api import series_frame_manifest
    from .pki import certificate_der
    from .series import SeriesChain

    signer, certs, signer_info = _series_signer(args)
    claims = _claims_from(args)
    attestation = _attestation_from(args)
    files = _expand(args.files)
    if not files:
        print("no input files matched", file=sys.stderr)
        return EXIT_USAGE
    envs, entries = _checkpointed_prefix(args.checkpoints, args.series_id, files, signer)
    new = files[len(entries):]
    if not new:
        print(f"nothing new: {len(entries)} frames already checkpointed")
        return EXIT_OK
    # count None: nobody knows yet how long the run will be.
    work = [(f, args.format, len(entries) + i, None, args.series_id, signer_info,
             claims or None, attestation or None) for i, f in enumerate(new)]
    for f, m in zip(new, ordered_map(series_frame_manifest, work, args.jobs)):
        entries.append((f.name, m))
    # ponytail: refolds the whole run, one SHA-256 per frame per call; keep the
    # head in the state file if runs of 10^6 frames make that show.
    chain = SeriesChain(args.series_id)
    for _, m in entries:
        chain.add(m)
    env = chain.checkpoint(signer, certificates_der=[certificate_der(c) for c in certs])
    # State first: a crash before the checkpoints are written leaves the state
    # ahead of the last checkpoint, and the next call truncates it again.
    # ponytail: both files are rewritten whole each call; an append-only log
    # if that ever costs more than the hashing.
    _write_state(args.checkpoints, entries)
    _write(pathlib.Path(args.checkpoints),
           json.dumps(envs + [env], indent=2).encode("utf-8") + b"\n")
    print(f"checkpoint {len(envs) + 1}: {len(entries)} frames ({len(new)} new), "
          f"written to {args.checkpoints}")
    return EXIT_OK


def _manifest_body(mb: bytes):
    try:
        body = json.loads(mb)["digests"]["body"]
    except Exception:  # noqa: BLE001 - unsigned state: an unusable entry matches nothing
        return None
    return body if isinstance(body, str) else None


def cmd_verify_checkpoints(args) -> int:
    from types import SimpleNamespace

    from cryptography.exceptions import UnsupportedAlgorithm
    from cryptography.hazmat.primitives.serialization import load_der_public_key

    from ._parallel import ordered_map
    from .api import _assess_trust, frame_body_digest
    from .keys import load_public_key
    from .series import verify_checkpoints

    files = _expand(args.files)
    problems = []
    notes = ["revocation and timestamps are not consulted; a checkpoint's "
             "'created' is the signer's own claim"]
    try:
        envs = _read_checkpoints(args.checkpoints)
    except (OSError, ValueError) as exc:
        envs = []
        problems.append(f"checkpoints unreadable: {exc}")
    if args.series:
        try:
            envs.append(json.loads(pathlib.Path(args.series).read_text(encoding="utf-8")))
        except (OSError, ValueError) as exc:
            problems.append(f"series envelope unreadable: {exc}")
    if len(envs) > _MAX_CHECKPOINTS:
        problems.append(f"{len(envs)} envelopes, more than the {_MAX_CHECKPOINTS} checked")
        envs = []
    try:
        entries = _read_state(_state_path(args.checkpoints))
    except (OSError, ValueError) as exc:
        entries = []
        problems.append(f"state unreadable: {exc}")

    # The state is unsigned: it only proposes which manifest each frame had.
    # A frame is paired with one whose body digest matches it, and the signed
    # chain decides whether those manifests are the ones that were signed.
    bodies = list(ordered_map(frame_body_digest, [(f, args.format) for f in files], args.jobs))
    state_bodies = [_manifest_body(m) for _, m in entries]
    by_body = {}
    for b, (_, m) in zip(state_bodies, entries):
        if b is not None:
            by_body.setdefault(b, m)
    observed, unmatched = [], []
    for i, b in enumerate(bodies):
        m = None
        if b is not None:
            m = entries[i][1] if i < len(entries) and state_bodies[i] == b else by_body.get(b)
        if m is None:
            unmatched.append(files[i].name)
        observed.append(m or b"")

    # Pinned keys and nothing else; otherwise the key the first envelope
    # carries, which proves integrity only (as framesig.run_h5.verify_run).
    keys = [load_public_key(pathlib.Path(k).read_bytes()) for k in args.public_key or []]
    pinned, certs = bool(keys), []
    first = envs[0] if envs and isinstance(envs[0], dict) else {}
    try:
        certs = [x509.load_der_x509_certificate(base64.b64decode(c, validate=True))
                 for c in first.get("certificates", [])[:8]]
        if not keys and certs:
            keys = [certs[0].public_key()]
        elif not keys and "public_key" in first:
            keys = [load_der_public_key(base64.b64decode(first["public_key"], validate=True))]
    except (KeyError, TypeError, ValueError, UnsupportedAlgorithm) as exc:
        certs = []
        problems.append(f"malformed signer in the first envelope: {exc}")

    ok, covered, chain_problems = verify_checkpoints(envs, observed, keys)
    intact = ok and not problems
    problems += chain_problems
    origin = "pinned" if pinned else "not assessed"
    if intact and not pinned:
        signed = json.loads(base64.b64decode(first["manifest"]))
        signer_block = signed.get("signer")
        # Only the signer block: never 'created', which the signer asserts.
        sink = SimpleNamespace(problems=[], notes=[])
        origin, _ = _assess_trust(
            certs, _load_roots(args.trust or []), keys[0],
            {"signer": signer_block if isinstance(signer_block, dict) else {}}, None, sink)
        notes += sink.problems + sink.notes
    unauth = [f.name for f in files[covered:]] if intact else []
    passed = intact and origin in ("pinned", "trusted") and not unauth

    if args.json:
        print(json.dumps({
            "ok": passed, "intact": intact, "covered": covered if intact else 0,
            "frames": len(files), "unauthenticated": unauth, "unmatched": unmatched,
            "problems": problems, "origin": origin, "notes": notes}, indent=2))
        return EXIT_OK if passed else EXIT_BAD
    for p in problems:
        print(f"FAIL {p}")
    if not intact and unmatched:
        print(f"FAIL no state entry matches {len(unmatched)} frame(s): "
              + ", ".join(unmatched[:20]) + (" ..." if len(unmatched) > 20 else ""))
    if intact:
        print(f"OK   {covered} of {len(files)} frames match the signed checkpoints")
    for name in unauth:
        print(f"UNAUTH {name}  (after the last checkpoint: not covered by any signature)")
    print(f"signer: {origin}" + "".join(f"\n  {n}" for n in notes))
    if intact and origin not in ("pinned", "trusted"):
        print("FAIL origin not established: intact against the key inside the file, "
              "which proves integrity, not who signed; pass --public-key or --trust")
    return EXIT_OK if passed else EXIT_BAD


def cmd_verify(args) -> int:
    if args.bundle:
        # The option was accepted and then ignored, so `verify --bundle` said
        # nothing about the bundle while reading as though it had. Refusing is
        # better than that until the two checks share a single read.
        print("verify --bundle is not implemented, so the bundle would not be "
              "checked. Use:\n  framesig bundle verify BUNDLE FILES...", file=sys.stderr)
        return EXIT_USAGE
    roots = _load_roots(args.trust or [])
    files = _expand(args.files)
    if not files:
        print("no input files matched", file=sys.stderr)
        return EXIT_USAGE
    worst = EXIT_OK
    results = []
    for f in files:
        result = verify_file(
            f,
            roots=roots,
            public_key_paths=args.public_key or [],
            sidecar=args.sidecar,
            timestamp_roots=_load_roots(getattr(args, "timestamp_trust", None) or []),
        )
        worst = max(worst, _STATUS_EXIT.get(result.status, EXIT_BAD))
        # Integrity alone is not success. The default question this tool answers
        # is "did an instrument produce this", so a frame that is intact but
        # only self-attested must not exit 0 -- a CI job or a journal pipeline
        # reads the exit code, and silently passing fabrications is the exact
        # failure this repository exists to prevent.
        if ASSURANCE_ORDER.index(result.assurance.level) < ASSURANCE_ORDER.index(args.require):
            worst = max(worst, EXIT_BAD)
        results.append((f, result))

    # A series signs its frame count and every frame proves its own index, so a
    # dropped frame is detectable -- but only by looking at the run as a whole.
    # Each frame above was judged on its own; this is the look at the run.
    from .series import describe_indices, series_completeness

    runs = series_completeness((str(f), r.series) for f, r in results)
    incomplete = [run for run in runs if not run["complete"]]
    if incomplete and not args.allow_partial_series:
        worst = max(worst, EXIT_BAD)

    if args.json:
        print(json.dumps(
            [{"file": str(f), **r.to_dict()} for f, r in results], indent=2
        ))
        for run in incomplete:
            print(f"series {run['series_id']!r}: {len(run['present'])} of {run['count']} "
                  "frame(s) present", file=sys.stderr)
        return worst

    for f, result in results:
        if len(files) > 1 and not args.verbose:
            if result.ok:
                mark = "OK  "
            elif result.intact:
                mark = "WEAK"  # intact, but origin not established
            else:
                mark = "FAIL"
            print(f"{mark} {result.status:18s} {result.assurance.level:14s} {f}")
        else:
            print(f"=== {f}")
            print(result.summary())
            print()
    attested = sum(1 for _, r in results if r.ok)
    weak = sum(1 for _, r in results if r.intact and not r.ok)
    broken = len(results) - attested - weak
    print()
    if weak or broken:
        print(
            f"{attested} instrument-attested, {weak} intact but unattested, "
            f"{broken} failing, of {len(files)} frame(s)."
        )
        if weak:
            print(
                "WEAK means the bytes are unchanged but nothing establishes that an\n"
                "instrument produced them -- a simulated or generated frame reaches\n"
                "this level too. Pass --require custodial or --require self-attested\n"
                "to accept it deliberately."
            )
    else:
        print(f"{len(files)} frame(s) verified and instrument-attested")

    for run in runs:
        label = f"series {run['series_id']!r}"
        if run["complete"]:
            print(f"{label}: all {run['count']} frame(s) present")
            continue
        print(f"{label}: {len(run['present'])} of {run['count']} frame(s) present")
        if run["missing"]:
            print(f"  MISSING   index {describe_indices(run['missing'])}")
        for index, names in run["duplicates"].items():
            print(f"  DUPLICATE index {index} in {len(names)} files: {', '.join(names[:4])}")
    if incomplete:
        if args.allow_partial_series:
            print("accepted as a partial run (--allow-partial-series)")
        else:
            print(
                "A run with frames missing or doubled is not the run that was signed.\n"
                "Pass --allow-partial-series to check a subset of a run deliberately."
            )
    return worst


def cmd_inspect(args) -> int:
    for f in _expand(args.files):
        print(json.dumps(inspect_file(f), indent=2))
    return EXIT_OK


# --------------------------------------------------------------------------
# bundles: one signed statement about a set of already-signed frames
# --------------------------------------------------------------------------

def _collect_members(files, roots, public_key_paths, name_of=None, keep_bytes=False):
    """Verify each frame and describe it as a prospective bundle member.

    **Each file is read exactly once.** An earlier version read every frame
    three times -- once to verify, once to pull out its envelope, once to pack
    it -- which is a time-of-check-to-time-of-use hole: a file swapped between
    reads would be attested under one digest and stored under different bytes,
    producing a bundle that certifies frames it does not contain. That is not a
    hypothetical race on a beamline, where an acquisition process may still be
    writing into the directory being bundled.

    ``keep_bytes`` retains what was read so the caller can write it straight
    into a container without going back to disk.
    """
    from .api import manifest_bytes_of, verify_data
    from .bundle import member_of
    from .keys import load_public_key

    keys = [load_public_key(pathlib.Path(k).read_bytes()) for k in (public_key_paths or [])]
    members, skipped = [], []
    for f in files:
        try:
            data = f.read_bytes()          # <-- the one and only read
        except OSError as exc:
            skipped.append((f, f"unreadable: {exc}"))
            continue

        sidecar = None
        sidecar_path = pathlib.Path(str(f) + SIDECAR_SUFFIX)
        if sidecar_path.exists():
            try:
                sidecar = json.loads(sidecar_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                skipped.append((f, f"unreadable sidecar: {exc}"))
                continue

        raw = manifest_bytes_of(data, sidecar)
        if raw is None:
            skipped.append((f, "no readable signature"))
            continue

        result = verify_data(data, roots=roots, public_keys=keys, sidecar=sidecar)
        if not result.intact:
            # A valid signature is not enough: a frame edited after it was
            # signed still carries one. Bundling it would sign a statement that
            # the edited bytes are the measurement.
            skipped.append((f, result.status))
            continue

        series = (result.manifest or {}).get("series") or {}
        record = {
            # Identity is the digest of the exact manifest bytes that were
            # signed, so it binds contents, payload digests, attestation and
            # signer in one value.
            "manifest_digest": member_of(raw),
            "name": name_of(f) if name_of else f.name,
            "assurance": result.assurance.level,
            "series_id": series.get("id"),
            "series_index": series.get("index"),
            "status": result.status,
        }
        if keep_bytes:
            record["data"] = data
        members.append(record)
    return members, skipped


def _envelope_of(path):
    """Pull the envelope out of a frame, embedded or sidecar."""
    import json as _json

    from .api import SIDECAR_SUFFIX
    from .formats.cbf import CbfAdapter, read_block

    data = pathlib.Path(path).read_bytes()
    offset = CbfAdapter()._find_block(data)
    if offset is not None:
        return _json.loads(read_block(data[offset:]).decode("utf-8"))
    sidecar = pathlib.Path(str(path) + SIDECAR_SUFFIX)
    if sidecar.exists():
        return _json.loads(sidecar.read_text(encoding="utf-8"))
    raise ValueError("no signature found")


def _relative_namer(all_paths):
    """A function giving each path a stable in-archive name.

    Uses the deepest common parent of everything being bundled, so that
    `run_A/f_0000.cbf` and `run_B/f_0000.cbf` stay distinct instead of
    colliding on their bare filenames. The common parent is worked out once,
    not once per frame: a run is thousands of files.
    """
    import os

    try:
        common = pathlib.Path(os.path.commonpath([str(p.resolve().parent) for p in all_paths]))
    except (ValueError, OSError):
        common = None

    def name_of(path):
        if common is None:
            return path.name
        try:
            return str(path.resolve().relative_to(common)).replace("\\", "/")
        except (ValueError, OSError):
            return path.name

    return name_of


def _relative_name(path, all_paths):
    """A stable in-archive name; see :func:`_relative_namer`."""
    return _relative_namer(all_paths)(path)


def cmd_bundle_create(args) -> int:
    from .bundle import PROVENANCE_FIELDS, build_bundle, validate_provenance
    from .keys import public_key_bytes
    from .pki import certificate_der

    signer, certs = _signer_and_certs(args)
    roots = _load_roots(args.trust or [])
    files = _expand(args.files)
    if not files:
        print("no input files matched", file=sys.stderr)
        return EXIT_USAGE

    provenance = {}
    for item in args.provenance or []:
        if "=" not in item:
            raise SystemExit(f"--set expects key=value, got {item!r}")
        k, _, v = item.partition("=")
        provenance[k.strip()] = v.strip()
    unknown = set(provenance) - set(PROVENANCE_FIELDS)
    for key in sorted(unknown):
        print(f"note: {key!r} is not a well-known provenance field; it will be "
              "signed but not interpreted")
    for problem in validate_provenance(provenance):
        print(f"WARNING: {problem}", file=sys.stderr)

    out = pathlib.Path(args.out)
    pack = args.pack if args.pack is not None else out.suffix.lower() in CONTAINER_SUFFIXES
    members, skipped = _collect_members(
        files, roots, args.public_key or [],
        name_of=_relative_namer(files),
        # When packing, hold on to what was verified: writing the container
        # from a second read would let a file change in between, and the bundle
        # would then attest digests it does not contain.
        keep_bytes=pack,
    )
    for f, why in skipped:
        print(f"skipped {f}: {why}", file=sys.stderr)
    if not members:
        print("no verifiable frames to bundle", file=sys.stderr)
        return EXIT_BAD
    if skipped and not args.allow_unverifiable:
        print(
            f"refusing to bundle: {len(skipped)} frame(s) could not be verified. "
            "A bundle that quietly omits frames misrepresents the dataset; pass "
            "--allow-unverifiable to bundle the rest deliberately.",
            file=sys.stderr,
        )
        return EXIT_BAD

    envelope = build_bundle(
        [{k: v for k, v in m.items() if k != "data"} for m in members], signer,
        bundle_id=args.bundle_id,
        provenance=provenance or None,
        certificates_der=[certificate_der(c) for c in certs],
        public_key_der=public_key_bytes(signer.public_key),
    )
    if pack:
        from .container import write_container

        write_container(out, envelope, [(m["name"], m["data"]) for m in members])
    else:
        atomic_write(out, json.dumps(envelope, indent=2).encode("utf-8") + b"\n")

    import base64

    bundle = json.loads(base64.b64decode(envelope["manifest"]))
    print(f"bundle written: {out}" + ("  (single file, frames inside)" if pack else ""))
    print(f"  id:      {bundle['bundle_id']}")
    print(f"  frames:  {bundle['counts']['frames']} in {bundle['counts']['runs']} run(s)")
    print(f"  root:    {bundle['members_root']}")
    print(f"  floor:   {bundle['member_assurance_floor']}  (weakest member assurance)")
    if bundle["member_assurance_floor"] != ASSURANCE_INSTRUMENT:
        print()
        print("NOTE: a bundle cannot raise the assurance of its members. This one")
        print("contains frames whose origin is not established, and says so in the")
        print("signed manifest; it is not evidence that the data were measured.")
    return EXIT_OK


def _container_items(container):
    """``(name, read)`` pairs for the frames stored inside a ``.framebundle``."""
    return [(name, (lambda n=name: (container.read_frame(n), None)))
            for name in container.frame_names]


def _path_items(files):
    """``(name, read)`` pairs for frames on disk.

    Names are relative to the deepest common parent, as ``bundle create``
    stores them, so a deposition laid out the way it was bundled reports no
    spurious renames. A frame's sidecar is read along with it, as it is when
    the bundle is created; a sidecar file is never itself taken for a frame.
    """
    frames = [f for f in files if not str(f).endswith(SIDECAR_SUFFIX)]
    name_of = _relative_namer(frames)

    def reader(f):
        def read():
            data = f.read_bytes()
            sidecar = None
            sidecar_path = pathlib.Path(str(f) + SIDECAR_SUFFIX)
            if sidecar_path.exists():
                sidecar = json.loads(sidecar_path.read_text(encoding="utf-8"))
            return data, sidecar
        return read

    return [(name_of(f), reader(f)) for f in frames]


def _print_bundle_findings(report, *, allow_unsigned=False, file=None, limit=20):
    """Name every frame that keeps a bundle from verifying, then the advisories."""
    file = file or sys.stdout

    def listing(key, line):
        entries = report[key]
        for entry in entries[:limit]:
            print(line(entry), file=file)
        if len(entries) > limit:
            print(f"  ... and {len(entries) - limit} more", file=file)

    listing("missing", lambda e: f"  MISSING    {e['name']}")
    listing("unexpected", lambda e: f"  UNEXPECTED {e['name']}  (not a member of this bundle)")
    listing("not_intact", lambda e: f"  NOT INTACT {e['name']}  ({e['status']}: a member, "
                                    "but changed since it was signed)")
    if allow_unsigned:
        listing("unsigned", lambda e: f"  unsigned   {e['name']}  (accepted by --allow-unsigned; "
                                      "not part of the signed dataset)")
    else:
        listing("unsigned", lambda e: f"  UNSIGNED   {e['name']}  (carries no signature, so it "
                                      "cannot be a member)")
    listing("unreadable", lambda e: f"  UNREADABLE {e['name']}: {e['reason']}")
    listing("duplicates", lambda e: f"  DUPLICATE  {e['name']}  (the same signed frame as "
                                    f"{e['duplicate_of']})")
    listing("renamed", lambda e: f"  renamed    {e['signed_as']} -> {e['found_as']}")
    listing("downgraded", lambda e: f"  DOWNGRADED {e['name']}: bundled as {e['bundled_as']}, "
                                    f"now verifies as {e['verifies_as']}")


def cmd_bundle_verify(args) -> int:
    from .bundle import scan_frames, verify_bundle
    from .container import is_container, open_container
    from .keys import load_public_key

    roots = _load_roots(args.trust or [])
    keys = [load_public_key(pathlib.Path(k).read_bytes()) for k in (args.public_key or [])]
    bundle_path = pathlib.Path(args.bundle)

    container = open_container(bundle_path) if is_container(bundle_path) else None
    if container is not None:
        envelope = container.envelope
    else:
        envelope = json.loads(bundle_path.read_text(encoding="utf-8"))

    scan = None
    if args.files:
        # Frames named on the command line are what gets checked -- with a
        # .framebundle too. That is the referee's question: do the copies I
        # have match the dataset that was signed? Checking the frames stored
        # inside the container instead, without a word, answered a different
        # question while appearing to answer this one.
        files = _expand(args.files)
        if container is not None:
            print(f"manifest:  {bundle_path.name}  (its signed member list only; the "
                  "frames stored inside it are not used)")
            print(f"checking:  {len(files)} file(s) named on the command line")
        scan = scan_frames(_path_items(files), roots=roots, public_keys=keys)
    elif container is not None:
        # A single-file bundle carries its own frames, so there is nothing to
        # point at and nothing that can have been left behind.
        print(f"container: {bundle_path.name}  ({len(container.frame_names)} frame(s) inside)")
        scan = scan_frames(_container_items(container), roots=roots, public_keys=keys)

    report = verify_bundle(
        envelope,
        found=None if scan is None else scan["found"],
        public_keys=keys,
        unsigned=() if scan is None else scan["unsigned"],
        unreadable=() if scan is None else scan["unreadable"],
        duplicates=() if scan is None else scan["duplicates"],
        allow_unsigned=args.allow_unsigned,
    )
    bundle = report["bundle"] or {}

    print(f"bundle:    {bundle.get('bundle_id')}")
    print(f"signature: {'valid' if report['signature_valid'] else 'INVALID'}")
    print(f"declares:  {(bundle.get('counts') or {}).get('frames')} frame(s) in "
          f"{(bundle.get('counts') or {}).get('runs')} run(s)")
    print(f"floor:     {report['member_assurance_floor']}  (weakest member, as signed)")
    if "observed_assurance_floor" in report:
        print(f"observed:  {report['observed_assurance_floor']}  (weakest member, as verified)")
    for key, value in sorted((bundle.get("provenance") or {}).items()):
        print(f"  {key:22s} {value}")

    if scan is not None:
        print()
        print(f"present:    {len(report['present'])}")
        print(f"missing:    {len(report['missing'])}")
        print(f"unexpected: {len(report['unexpected'])}")
        for key, label in (("not_intact", "not intact"), ("unsigned", "unsigned"),
                           ("unreadable", "unreadable"), ("duplicates", "duplicates")):
            if report[key]:
                print(f"{label + ':':12s}{len(report[key])}")
        _print_bundle_findings(report, allow_unsigned=args.allow_unsigned)

    for problem in report["problems"]:
        print(f"  ! {problem}")
    for note in report["notes"]:
        print(f"  - {note}")

    if scan is None:
        return EXIT_OK if report["signature_valid"] else EXIT_BAD
    print()
    print("complete and consistent" if report["complete"] else "BUNDLE DOES NOT MATCH THESE FILES")
    return EXIT_OK if report["complete"] else EXIT_BAD


def cmd_bundle_extract(args) -> int:
    from .bundle import scan_frames, verify_bundle
    from .container import open_container, safe_member_paths

    container = open_container(args.bundle)
    roots = _load_roots(args.trust or [])
    destination = pathlib.Path(args.out)
    wanted = set(args.frame) if args.frame else None

    # Read each entry once, and hold it only long enough to verify and write.
    # Verifying everything and *then* re-reading to extract would let the
    # archive change in between; and holding a whole dataset in memory is not
    # an option when a run is tens of gigabytes.
    scan = scan_frames(
        _container_items(container), roots=roots,
        keep=lambda name: wanted is None or name in wanted,
    )
    staged = scan["data"]

    report = verify_bundle(
        container.envelope, found=scan["found"], unsigned=scan["unsigned"],
        unreadable=scan["unreadable"], duplicates=scan["duplicates"],
    )
    if not report["complete"] and not args.force:
        print("refusing to extract: this bundle does not verify.", file=sys.stderr)
        for problem in report["problems"]:
            print(f"  ! {problem}", file=sys.stderr)
        _print_bundle_findings(report, file=sys.stderr)
        print("pass --force to extract anyway.", file=sys.stderr)
        return EXIT_BAD

    targets = safe_member_paths([name for name, _ in staged], destination)  # all, before any write
    destination.mkdir(parents=True, exist_ok=True)
    written = []
    for (name, data), target in zip(staged, targets):
        target.parent.mkdir(parents=True, exist_ok=True)
        atomic_write(target, data)
        written.append(target)
        print(target)
    print(f"\nextracted {len(written)} frame(s) to {destination}")
    if not report["complete"]:
        print("WARNING: extracted from a bundle that does not verify.", file=sys.stderr)
    return EXIT_OK


def cmd_bundle_list(args) -> int:
    from .api import manifest_bytes_of, verify_data
    from .bundle import member_of
    from .container import open_container

    container = open_container(args.bundle)
    roots = _load_roots(args.trust or [])
    import base64

    bundle = json.loads(base64.b64decode(container.envelope["manifest"]))
    members = {e["m"]: e for e in bundle.get("members", [])}

    print(f"{bundle.get('bundle_id')}  -  {bundle['counts']['frames']} frame(s), "
          f"{bundle['counts']['runs']} run(s)")
    for key, value in sorted((bundle.get("provenance") or {}).items()):
        print(f"  {key:22s} {value}")
    print()
    for name in container.frame_names:
        data = container.read_frame(name)
        raw = manifest_bytes_of(data)
        member = raw is not None and member_of(raw) in members
        if args.verify:
            result = verify_data(data, roots=roots)
            mark = "OK  " if result.ok else ("WEAK" if result.intact else "FAIL")
            note = result.assurance.level
        else:
            mark, note = "    ", ""
        print(f"{mark} {'member' if member else 'NOT A MEMBER':12s} "
              f"{container.frame_size(name):>10,d}  {note:14s} {name}")
    return EXIT_OK


def cmd_oids(args) -> int:
    from .oids import (
        ACTIVE_PEN,
        DOCUMENTATION_PEN,
        IANA_APPLY_URL,
        RECOGNISED_PENS,
        is_provisional,
        registry,
    )

    print(f"active enterprise number: {ACTIVE_PEN}")
    print(f"recognised on verify:     {', '.join(str(p) for p in RECOGNISED_PENS)}")
    print()
    for oid, label in registry():
        print(f"  {oid:<34s} {label}")
    if is_provisional(ACTIVE_PEN):
        print()
        print(f"WARNING: {ACTIVE_PEN} is the RFC 5612 documentation arc. It is reserved for")
        print("examples and belongs to no organisation, so the identifiers above are not")
        print("globally unique. Register a Private Enterprise Number before deploying:")
        print(f"  {IANA_APPLY_URL}")
        print("Then set ACTIVE_PEN in src/framesig/oids.py and web/framesig/oids.js.")
        print("See docs/OIDS.md.")
    return EXIT_OK


def cmd_view(args) -> int:
    from .viewer import run_viewer

    return run_viewer(
        folder=args.folder,
        trust=args.trust or [],
        public_keys=args.public_key or [],
    )


# --------------------------------------------------------------------------
# parser
# --------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="framesig", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--version", action="version", version=f"framesig {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    g = sub.add_parser("keygen", help="generate a signing key pair")
    g.add_argument("out", help="path for the private key")
    g.add_argument("--algorithm", choices=ALGORITHMS, default=ALG_ED25519)
    g.add_argument("--encoding", choices=("der", "pem"), default="der",
                   help="encrypted PKCS#8 DER (binary, default) or PEM")
    _passphrase_args(g, creating=True)
    g.set_defaults(func=cmd_keygen)

    ca = sub.add_parser("ca", help="demo vendor certificate authority")
    casub = ca.add_subparsers(dest="ca_command", required=True)
    ci = casub.add_parser("init", help="create a root CA and an issuing CA")
    ci.add_argument("dir", help="directory to create the CA in")
    ci.add_argument("--org", default="Example Detectors GmbH")
    ci.add_argument("--algorithm", choices=ALGORITHMS, default=ALG_ED25519)
    ci.add_argument("--root-crl-url", type=_http_url,
                    help="where the root publishes its withdrawal list; written into "
                         "the issuing CA certificate, so --online can check whether the "
                         "issuing CA itself was withdrawn")
    ci.add_argument("--issuing-crl-url", type=_http_url,
                    help="where the issuing CA publishes its withdrawal list; recorded "
                         f"in {_ISSUING_CRL_FILE} and written into every unit "
                         "certificate 'ca issue' makes from this directory")
    _passphrase_args(ci, creating=True)
    ci.set_defaults(func=cmd_ca_init)
    cis = casub.add_parser("issue", help="issue a detector unit certificate")
    cis.add_argument("--ca", required=True, help="CA directory from 'ca init'")
    cis.add_argument("--public-key", required=True, help="the unit's public key (PEM)")
    cis.add_argument("--serial", required=True, help="detector serial number")
    cis.add_argument("--model", default="unspecified")
    cis.add_argument("--org", default="Example Detectors GmbH")
    cis.add_argument("--out", required=True, help="output certificate chain (PEM)")
    cis.add_argument("--crl-url", type=lambda v: v and _http_url(v),
                     help="where this CA publishes its withdrawal list; written into "
                          "the certificate for 'verify-run/audit --online'. Default: "
                          "the --issuing-crl-url given at 'ca init'; '' names none")
    cis.add_argument(
        "--instrument-attested", action="store_true",
        help="assert that this key is held in a secure element inside the "
             "instrument and was provisioned during manufacture. Only a "
             "manufacturer can honestly set this; it is what separates a "
             "signature that proves origin from one that does not.",
    )
    _passphrase_args(cis, creating=False)
    cis.set_defaults(func=cmd_ca_issue)

    def _sign_args(sp, embeds=True, attest=True):
        sp.add_argument("files", nargs="+", help="files, globs or a directory")
        sp.add_argument("--key", help="signing private key (PEM)")
        sp.add_argument(
            "--tpm-key",
            help="name of a hardware-held key to sign with instead (TPM or Secure Enclave; "
                 "see 'framesig tpm')",
        )
        _passphrase_args(sp, creating=False)
        sp.add_argument("--cert", help="unit certificate chain (PEM) to embed")
        if embeds:
            sp.add_argument("--sidecar", action="store_true",
                            help=f"write a detached '{SIDECAR_SUFFIX}' file instead of embedding")
        sp.add_argument("--claim", action="append",
                        help="operator-supplied provenance claim as key=value; repeatable")
        sp.add_argument("--claims-file", help="JSON file of provenance claims")
        if attest:
            sp.add_argument(
                "--attest", action="append", metavar="KEY=VALUE",
                help="instrument attestation as key=value (mode, model, serial, "
                     "firmware, sensor); repeatable. Without mode=physical the frame "
                     "cannot reach instrument-level assurance.",
            )
        sp.add_argument("--format", help="force a format adapter (cbf, raw)")

    s = sub.add_parser("sign", help="sign one or more frames individually")
    _sign_args(s)
    s.add_argument("--output", help="write to this path instead of in place (single file only)")
    s.set_defaults(func=cmd_sign)

    sd = sub.add_parser("sign-derived",
                        help="sign a processed frame, naming the signed frames it was made from")
    _sign_args(sd, attest=False)  # an output of processing attests no acquisition
    sd.add_argument("--input", action="append", required=True,
                    help="a signed input frame (embedded or with its sidecar); repeatable")
    sd.add_argument("--output", help="write to this path instead of in place (single file only)")
    sd.set_defaults(func=cmd_sign_derived)

    vc = sub.add_parser("verify-chain",
                        help="verify a derived frame and every link back to its sources")
    vc.add_argument("file", help="the derived frame")
    vc.add_argument("--input", action="append",
                    help="a candidate input frame, glob or directory; repeatable. "
                         "Only these files are opened; names inside manifests never are.")
    vc.add_argument("--trust", action="append", help="trusted root CA (PEM); repeatable")
    vc.add_argument("--public-key", action="append",
                    help="pin every link to this public key (PEM); repeatable")
    vc.add_argument("--timestamp-trust", action="append",
                    help="trusted root for timestamp authorities (PEM); repeatable")
    vc.add_argument("--json", action="store_true", help="machine-readable output")
    vc.add_argument(
        "--require", choices=ASSURANCE_ORDER, default=ASSURANCE_INSTRUMENT,
        help="minimum assurance of each source frame (one naming no inputs) to "
             "exit 0 (default: instrument)",
    )
    vc.add_argument(
        "--require-processing", choices=ASSURANCE_ORDER, default="custodial",
        help="minimum assurance of each processing step to exit 0 (default: "
             "custodial, the highest a derived frame can reach)",
    )
    vc.set_defaults(func=cmd_verify_chain)

    ss = sub.add_parser("sign-series", help="sign a run with one Merkle-rooted signature")
    _sign_args(ss)
    ss.add_argument("--series-id", required=True, help="identifier for this run")
    ss.add_argument("--series-out", help="also write the series envelope here")
    ss.add_argument("--jobs", type=int, help="processes hashing frames in "
                    "parallel (default: one per CPU); the run is still signed once")
    ss.add_argument("--checkpoints", help="finish a run signed with 'framesig "
                    "checkpoint': reuse the frames those checkpoints cover, so the "
                    "series extends their chain")
    ss.set_defaults(func=cmd_sign_series)

    cp = sub.add_parser("checkpoint",
                        help="sign a checkpoint over the frames acquired so far")
    _sign_args(cp, embeds=False)
    cp.add_argument("--series-id", required=True, help="identifier for this run")
    cp.add_argument("--checkpoints", required=True,
                    help="file the signed checkpoints are appended to; the unsigned "
                         "running state is kept next to it as <file>.state")
    cp.add_argument("--jobs", type=int, help="processes hashing the new frames "
                    "in parallel (default: one per CPU)")
    cp.set_defaults(func=cmd_checkpoint)

    vc = sub.add_parser("verify-checkpoints",
                        help="check frames against signed acquisition checkpoints")
    vc.add_argument("files", nargs="+", help="the frames in acquisition order: "
                    "files, globs or a directory")
    vc.add_argument("--checkpoints", required=True,
                    help="checkpoints file written by 'framesig checkpoint'")
    vc.add_argument("--series", help="the run's series envelope "
                    "(sign-series --series-out), once the run was finished")
    vc.add_argument("--public-key", action="append", help="pin to this public key (PEM); repeatable")
    vc.add_argument("--trust", action="append", help="trusted root CA (PEM); repeatable")
    vc.add_argument("--format", help="force a format adapter (cbf, raw)")
    vc.add_argument("--jobs", type=int, help="processes hashing frames in parallel")
    vc.add_argument("--json", action="store_true", help="machine-readable output")
    vc.set_defaults(func=cmd_verify_checkpoints)

    pr = sub.add_parser("pack-run", help="pack a run into one HDF5 stack, signed once")
    _sign_args(pr)
    pr.add_argument("--series-id", required=True, help="identifier for this run")
    pr.add_argument("--out", required=True, help="Run-HDF5 file to write")
    pr.add_argument("--jobs", type=int, help="processes hashing frames in "
                    "parallel (default: one per CPU); the run is still signed once")
    pr.add_argument("--tsa-url", action="append", help="RFC 3161 authority to "
                    "timestamp the run signature; repeatable")
    pr.set_defaults(func=cmd_pack_run)

    vr = sub.add_parser("verify-run", help="verify a Run-HDF5 frame by frame")
    vr.add_argument("file", help="the Run-HDF5 file")
    vr.add_argument("--public-key", action="append", help="pin to this public key (PEM); repeatable")
    vr.add_argument("--trust", action="append", help="trusted root CA (PEM); repeatable")
    vr.add_argument("--timestamp-trust", action="append",
                    help="trusted root for timestamp authorities (PEM); repeatable")
    vr.add_argument("--revocations", help="a signed withdrawal list")
    vr.add_argument("--revocations-key", action="append",
                    help="key the withdrawal list should verify under (PEM)")
    vr.add_argument("--online", action="store_true", help=_ONLINE_HELP)
    vr.add_argument("--json", action="store_true", help="machine-readable output")
    vr.set_defaults(func=cmd_verify_run)

    v = sub.add_parser("verify", help="verify frames")
    v.add_argument("files", nargs="+", help="files, globs or a directory")
    v.add_argument("--trust", action="append", help="trusted root CA (PEM); repeatable")
    v.add_argument("--public-key", action="append",
                   help="accept this bare public key (PEM); repeatable")
    v.add_argument("--sidecar", help="explicit sidecar path (single file only)")
    v.add_argument("--timestamp-trust", action="append",
                   help="trusted root for timestamp authorities (PEM); repeatable")
    v.add_argument("--bundle", help="verify these frames against a signed bundle")
    v.add_argument("--json", action="store_true", help="machine-readable output")
    v.add_argument("-v", "--verbose", action="store_true", help="full report per file")
    v.add_argument("--allow-partial-series", action="store_true",
                   help="exit 0 even when frames of a signed series are missing or "
                        "doubled -- for checking a subset of a run on purpose; the "
                        "gaps are still listed")
    v.add_argument(
        "--require", choices=ASSURANCE_ORDER, default=ASSURANCE_INSTRUMENT,
        help="minimum assurance level to exit 0 (default: instrument). Lower it "
             "only when you knowingly accept frames whose origin is not established.",
    )
    v.set_defaults(func=cmd_verify)

    i = sub.add_parser("inspect", help="structural report, no cryptography")
    i.add_argument("files", nargs="+")
    i.set_defaults(func=cmd_inspect)

    b = sub.add_parser("bundle", help="sign or check a whole dataset as one object")
    bsub = b.add_subparsers(dest="bundle_command", required=True)

    bc = bsub.add_parser("create", help="sign a set of already-signed frames as a dataset")
    bc.add_argument("files", nargs="+", help="frames, globs or directories")
    bc.add_argument("--out", required=True, help="output bundle (JSON)")
    bc.add_argument("--bundle-id", required=True, help="identifier for this dataset")
    bc.add_argument("--key", help="signing private key")
    bc.add_argument("--tpm-key", help="name of a TPM-held key to sign the bundle with")
    bc.add_argument("--cert", help="certificate chain (PEM) for the bundle signer")
    bc.add_argument("--trust", action="append", help="trusted root for verifying members")
    bc.add_argument("--public-key", action="append", help="pinned key for verifying members")
    bc.add_argument("--set", dest="provenance", action="append", metavar="KEY=VALUE",
                    help="provenance: operator, orcid, facility, beamline, proposal, "
                         "doi, publication_doi, sample, licence, contact; repeatable")
    bc.add_argument("--allow-unverifiable", action="store_true",
                    help="bundle the verifiable frames even if some could not be verified")
    bc.add_argument("--pack", dest="pack", action="store_true", default=None,
                    help="write one file containing the frames (default for .framebundle)")
    bc.add_argument("--no-pack", dest="pack", action="store_false",
                    help="write only the bundle manifest, leaving the frames where they are")
    _passphrase_args(bc, creating=False)
    bc.set_defaults(func=cmd_bundle_create)

    bv = bsub.add_parser("verify", help="check a bundle, and optionally the frames it names")
    bv.add_argument("bundle", help="the bundle file")
    bv.add_argument("files", nargs="*",
                    help="the frames it should contain; with a .framebundle, these copies "
                         "are checked against its signed member list instead of the "
                         "frames stored inside it")
    bv.add_argument("--trust", action="append", help="trusted root CA (PEM)")
    bv.add_argument("--public-key", action="append", help="accept this bare public key (PEM)")
    bv.add_argument("--allow-unsigned", action="store_true",
                    help="accept unsigned frames among the files deliberately; they are "
                         "still listed, and still count against the observed floor")
    bv.set_defaults(func=cmd_bundle_verify)

    be = bsub.add_parser("extract", help="take the frames back out of a single-file bundle")
    be.add_argument("bundle")
    be.add_argument("--out", required=True, help="directory to extract into")
    be.add_argument("--frame", action="append", help="extract only this frame; repeatable")
    be.add_argument("--trust", action="append", help="trusted root CA (PEM)")
    be.add_argument("--force", action="store_true",
                    help="extract even if the bundle does not verify")
    be.set_defaults(func=cmd_bundle_extract)

    bl = bsub.add_parser("list", help="list what is inside a single-file bundle")
    bl.add_argument("bundle")
    bl.add_argument("--verify", action="store_true", help="verify each frame while listing")
    bl.add_argument("--trust", action="append", help="trusted root CA (PEM)")
    bl.set_defaults(func=cmd_bundle_list)

    t = sub.add_parser("tpm", help="use a key held in this machine's TPM or Secure Enclave")
    tsub = t.add_subparsers(dest="tpm_command", required=True)
    tc = tsub.add_parser("check", help="is a TPM-backed key provider usable here?")
    tc.set_defaults(func=cmd_tpm_check)
    tn = tsub.add_parser("create", help="create a non-exportable P-256 key in the TPM")
    tn.add_argument("name", help="a name for the key, e.g. detector-01")
    tn.add_argument("--out", help="where to write the public key (default <name>.pub.pem)")
    _passphrase_args(tn, creating=False)  # the PIN every signature must present
    tn.add_argument(
        "--i-accept-an-unprotected-hardware-key", action="store_true",
        help="create the key with no PIN, so any process running as you can sign "
             "with it (do not do this outside a demo)",
    )
    tn.set_defaults(func=cmd_tpm_create)
    te = tsub.add_parser("export-public", help="write the public key of an existing TPM key")
    te.add_argument("name")
    te.add_argument("--out")
    te.set_defaults(func=cmd_tpm_export)
    td = tsub.add_parser("delete", help="destroy a TPM key (irreversible)")
    td.add_argument("name")
    td.set_defaults(func=cmd_tpm_delete)

    o = sub.add_parser("oids", help="show the object identifiers this build uses")
    o.set_defaults(func=cmd_oids)

    inv_p = sub.add_parser(
        "inventory",
        help="list every key and certificate a dataset depends on",
    )
    inv_p.add_argument("files", nargs="+",
                       help="frames, a folder, a .framebundle, or a Run-HDF5 (.h5)")
    inv_p.add_argument("--json", action="store_true", help="emit the canonical records")
    inv_p.set_defaults(func=cmd_inventory)

    r = sub.add_parser("revoke", help="issue or inspect a signed withdrawal list")
    rsub = r.add_subparsers(dest="revoke_command", required=True)

    rc = rsub.add_parser("create", help="sign a withdrawal list")
    rc.add_argument("--out", required=True, help="where to write the list")
    rc.add_argument("--issuer", required=True, help="who is withdrawing (organisation name)")
    rc.add_argument("--key", help="signing key (PEM); the authority's key, not a detector's")
    rc.add_argument("--tpm-key", help="sign with this TPM key instead")
    rc.add_argument("--password-env", help="env var holding the key passphrase")
    rc.add_argument("--password-file", help="file holding the key passphrase")
    rc.add_argument("--cert", action="append", help="certificate chain for the list signer (PEM)")
    rc.add_argument("--key-id", action="append", default=[],
                    help="withdraw this key fingerprint (sha256:...); repeatable")
    rc.add_argument("--cert-digest", action="append", default=[],
                    help="withdraw this certificate digest (sha256:...); repeatable")
    rc.add_argument("--reason", choices=list(REASONS),
                    help="RFC 5280 CRLReason (required unless --empty)")
    rc.add_argument("--empty", action="store_true",
                    help="sign a list that withdraws nothing. A CA publishes one so that "
                         "'--online' can tell 'nothing withdrawn' from 'no answer'")
    rc.add_argument("--invalidity-date",
                    help="UTC date the key stopped being trustworthy "
                         "(required for the compromise reasons)")
    rc.add_argument("--next-update", help="UTC date after which this list is stale")
    rc.add_argument("--note", help="free text recorded with the entry")
    rc.set_defaults(func=cmd_revoke_create)

    rs = rsub.add_parser("show", help="check a withdrawal list's signature and print it")
    rs.add_argument("list", help="the revocation list")
    rs.add_argument("--public-key", action="append", help="key the list should verify under")
    rs.set_defaults(func=cmd_revoke_show)

    a = sub.add_parser(
        "audit",
        help="intersect a dataset's signer inventory with a withdrawal list",
    )
    a.add_argument("files", nargs="+",
                   help="frames, a folder, a .framebundle, or a Run-HDF5 (.h5)")
    a.add_argument("--revocations", help="a signed withdrawal list")
    a.add_argument("--public-key", action="append",
                   help="key the withdrawal list should verify under (PEM)")
    a.add_argument("--timestamp-trust", action="append",
                   help="trusted root for timestamp authorities (PEM); repeatable. "
                        "Without one, no signature can be shown to predate a compromise")
    a.add_argument("--trust", action="append",
                   help="vendor root CA (PEM) the fetched lists must chain to; repeatable")
    a.add_argument("--online", action="store_true", help=_ONLINE_HELP)
    a.set_defaults(func=cmd_audit)

    tsa = sub.add_parser("tsa", help="run or provision an RFC 3161 timestamp authority")
    tsasub = tsa.add_subparsers(dest="tsa_command", required=True)
    ti = tsasub.add_parser("init", help="create a timestamp authority under an existing CA")
    ti.add_argument("--ca-key", required=True, help="issuing CA private key (PEM)")
    ti.add_argument("--ca-cert", required=True, help="issuing CA certificate (PEM)")
    ti.add_argument("--name", default="Timestamp Authority")
    ti.add_argument("--org", required=True, help="the organisation operating it")
    ti.add_argument("--out", required=True, help="directory for the key and certificate")
    ti.add_argument("--password-env", help="env var holding the CA key passphrase")
    ti.add_argument("--password-file", help="file holding the CA key passphrase")
    ti.set_defaults(func=cmd_tsa_init)

    tst = tsasub.add_parser("stamp", help="timestamp a file's signature, offline")
    tst.add_argument("files", nargs="+")
    tst.add_argument("--tsa-key", required=True, help="the authority's private key (PEM)")
    tst.add_argument("--tsa-cert", required=True, help="the authority's certificate (PEM)")
    tst.add_argument("--password-env", help="env var holding the key passphrase")
    tst.add_argument("--password-file", help="file holding the key passphrase")
    tst.set_defaults(func=cmd_tsa_stamp)

    w = sub.add_parser("view", help="browse frames, from a folder or a single-file bundle")
    w.add_argument("folder", nargs="?", default=".",
                   help="a directory of frames, or a .framebundle")
    w.add_argument("--trust", action="append", help="trusted root CA (PEM); repeatable")
    w.add_argument("--public-key", action="append", help="accept this bare public key (PEM)")
    w.set_defaults(func=cmd_view)

    return p


# --------------------------------------------------------------------------
# inventory / revocation / audit
# --------------------------------------------------------------------------

_ONLINE_HELP = ("fetch the withdrawal lists the certificates name (needs --trust; "
                "cached in FRAMESIG_CACHE or ~/.cache/framesig). Off by default: "
                "nothing else touches the network")


def _inventory_of_paths(patterns: List[str], timestamp_roots=(), certs=None):
    """Observe every signing identity the named files depend on.

    Returns ``(refs, times, unexamined)``, where ``times`` maps each ``via``
    label to the instant a trusted timestamp places that file at, or None. Time
    is per file, not per dataset: two frames signed with one key can have
    entirely different time evidence, and a withdrawal may spare one and not
    the other.

    Each file is read once. Enumeration never verifies the *signature*, because
    an audit has to list the signers of files whose signatures have stopped
    verifying -- which is exactly what a withdrawal creates.

    A Run-HDF5 contributes its series envelope once, labelled with its frame
    count, and its time the way ``verify-run`` judges it. ``unexamined`` lists
    ``(name, reason)`` for runs that could not be read (or h5py is missing):
    they are not known to be clean, so callers must report them.

    *certs*, if a list, collects the certificates the files carry (for
    ``--online``).
    """
    from .api import envelope_of, inventory_of, _assess_timestamps
    from .container import is_container, open_container
    from .inventory import inventory_from_envelope, merge
    from .run_h5 import RUN_SUFFIXES, run_signers

    from .online import certificates_of

    collected, times, unexamined = [], {}, []

    def _fresh(short: str, full: str) -> str:
        # Namesakes in two folders must not share one `times` entry: a stamped
        # file would then vouch for an unstamped one with the same name.
        return full if short in times else short

    def _record(data: bytes, label: str, full: str, sidecar=None):
        label = _fresh(label, full)
        collected.append(inventory_of(data, sidecar=sidecar, via=label))
        envelope = envelope_of(data, sidecar)
        if envelope and certs is not None:
            certs.extend(certificates_of(envelope))
        if envelope:
            evidence = _assess_timestamps(envelope, [], timestamp_roots)
            times[label] = evidence.established_at if evidence.usable else None

    def _record_run(path: pathlib.Path):
        r = run_signers(path, timestamp_roots)
        env = r["envelope"]
        label = _fresh(f"{path.name} (run of {r['frames']} frames)",
                       f"{path} (run of {r['frames']} frames)")
        refs = inventory_from_envelope(env, via=label) if env else []
        if not refs:
            unexamined.append((path.name, "; ".join(r["problems"])
                               or "the run carries no signing identity"))
            return
        collected.append(refs)
        times[label] = r["trusted_time"]
        if certs is not None:
            certs.extend(certificates_of(env))

    for pattern in patterns:
        path = pathlib.Path(pattern)
        if path.is_file() and is_container(path):
            with open_container(path) as container:
                collected.append(
                    inventory_from_envelope(container.envelope, via=f"{path.name}:bundle")
                )
                if certs is not None:
                    certs.extend(certificates_of(container.envelope))
                for name, data in container.iter_frames():
                    _record(data, f"{path.name}:{name}", f"{path}:{name}")
            continue
        files = _expand([pattern])
        if path.is_dir():
            files += sorted(q for q in path.iterdir()
                            if q.is_file() and q.suffix.lower() in RUN_SUFFIXES)
        for f in files:
            if f.suffix.lower() in RUN_SUFFIXES:
                _record_run(f)  # a missing run is reported, not skipped
            elif f.is_file() and not str(f).endswith(SIDECAR_SUFFIX):
                # A frame signed with a sidecar depends on the signer named there;
                # without reading it, such frames had no signer at all here.
                sidecar = None
                sidecar_path = pathlib.Path(str(f) + SIDECAR_SUFFIX)
                if sidecar_path.exists():
                    try:
                        sidecar = json.loads(sidecar_path.read_text(encoding="utf-8"))
                    except (OSError, ValueError):
                        sidecar = None  # observation, not verification: fewer rows
                _record(f.read_bytes(), f.name, str(f), sidecar)
    return merge(*collected), times, unexamined


def _report_unexamined(unexamined, file=None) -> None:
    for name, why in unexamined:
        print(f"??   {name}: not examined -- {why}", file=file)
    if unexamined:
        print(f"{len(unexamined)} file(s) could not be examined; they are not known "
              "to be clean.", file=file)


def cmd_inventory(args) -> int:
    from .inventory import inventory_digest, records_of

    refs, _times, unexamined = _inventory_of_paths(args.files)
    _report_unexamined(unexamined, file=sys.stderr)
    if not refs:
        print("no signing identities found; are these files signed?", file=sys.stderr)
        return EXIT_BAD

    # An inventory that skipped a run is incomplete, which must not look like success.
    status = EXIT_BAD if unexamined else EXIT_OK
    records = records_of(refs)
    if args.json:
        print(json.dumps({"spec": "framesig-inventory/1",
                          "digest": inventory_digest(records),
                          "signers": records}, indent=2))
        return status

    print(f"{len(refs)} signing identit{'y' if len(refs) == 1 else 'ies'}")
    print(f"digest: {inventory_digest(records)}\n")
    for ref in refs:
        print(f"  {ref.role:12s} {ref.subject or '(bare key)'}")
        print(f"  {'':12s} key    {ref.key_id}")
        if ref.cert:
            print(f"  {'':12s} cert   {ref.cert}")
            print(f"  {'':12s} valid  {ref.not_before} .. {ref.not_after}")
        shown = ref.via[:3]
        more = f" (+{len(ref.via) - 3} more)" if len(ref.via) > 3 else ""
        if shown:
            print(f"  {'':12s} via    {', '.join(shown)}{more}")
        print()
    return status


def cmd_revoke_create(args) -> int:
    from .revocation import build_revocation_list

    signer, certs = _signer_and_certs(args)
    entries = []
    for value in args.key_id:
        entries.append({"key_id": value})
    for value in args.cert_digest:
        entries.append({"cert": value})
    if entries and args.empty:
        print("--empty contradicts --key-id/--cert-digest", file=sys.stderr)
        return EXIT_USAGE
    if not entries and not args.empty:
        # An accidental empty list tells every verifier "nothing withdrawn",
        # so saying that takes an explicit flag.
        print("nothing to withdraw: pass --key-id and/or --cert-digest "
              "(or --empty for a list that withdraws nothing)", file=sys.stderr)
        return EXIT_USAGE
    if entries and not args.reason:
        print("--reason is required to withdraw anything", file=sys.stderr)
        return EXIT_USAGE
    for entry in entries:
        entry["reason"] = args.reason
        if args.invalidity_date:
            entry["invalidity_date"] = args.invalidity_date
        if args.note:
            entry["note"] = args.note

    envelope = build_revocation_list(
        entries, signer,
        issuer=args.issuer,
        next_update=args.next_update,
        certificates_der=[certificate_der(c) for c in certs],
    )
    out = pathlib.Path(args.out)
    _write(out, json.dumps(envelope, indent=2).encode("utf-8") + b"\n")

    print(f"withdrawal list written: {out}")
    print(f"  issuer:  {args.issuer}")
    print(f"  entries: {len(entries)}")
    if not entries:
        print(f"  states:  nothing is withdrawn, until {args.next_update or 'no stated end'}")
        return EXIT_OK
    print(f"  reason:  {args.reason}")
    if args.invalidity_date:
        print(f"  since:   {args.invalidity_date}")
        print("           signatures provably made before this date are unaffected")
    else:
        print("  since:   not stated -- this is a retirement, not an accusation")
    return EXIT_OK


def _load_revocations(args):
    from .keys import load_public_key
    from .revocation import RevocationSet, verify_revocation_list

    if not getattr(args, "revocations", None):
        return RevocationSet.absent()
    keys = [load_public_key(pathlib.Path(k).read_bytes()) for k in (args.public_key or [])]
    envelope = json.loads(pathlib.Path(args.revocations).read_text(encoding="utf-8"))
    return verify_revocation_list(envelope, public_keys=keys, source=args.revocations)


def cmd_revoke_show(args) -> int:
    args.revocations = args.list
    rs = _load_revocations(args)
    print(rs.describe())
    for problem in rs.problems:
        print(f"  ! {problem}")
    print()
    for entry in rs.entries:
        target = entry.get("key_id") or entry.get("cert")
        print(f"  {entry.get('reason'):22s} {target}")
        if entry.get("invalidity_date"):
            print(f"  {'':22s} untrustworthy from {entry['invalidity_date']}")
        if entry.get("note"):
            print(f"  {'':22s} {entry['note']}")
    return EXIT_OK if rs.signature_valid else EXIT_BAD


def cmd_audit(args) -> int:
    from .revocation import STATE_CLEAN, STATE_SUSPECT, _severity

    timestamp_roots = _load_roots(args.timestamp_trust or [])
    certs = []
    refs, times, unexamined = _inventory_of_paths(args.files, timestamp_roots, certs)
    if not refs:
        _report_unexamined(unexamined)
        print("no signing identities found; are these files signed?", file=sys.stderr)
        return EXIT_BAD

    rs = _load_revocations(args)
    if args.online:
        from .online import consult
        from .revocation import RevocationSets

        fetched = consult(certs, _load_roots(args.trust or [])).sets
        rs = RevocationSets(([rs] if args.revocations else []) + fetched)
    print(rs.describe())
    for problem in rs.problems:
        print(f"  ! {problem}")
    stamped = sum(1 for t in times.values() if t is not None)
    if stamped:
        print(f"time evidence: {stamped} of {len(times)} file(s) carry a trusted timestamp")
    elif times:
        print("time evidence: none -- no file carries a timestamp from a trusted authority,")
        print("               so a compromise can only be treated as all-or-nothing")
    print()

    worst = STATE_CLEAN
    implicated = {}
    for ref in refs:
        # Evaluated per file, because time evidence is per file: the same key
        # may be spared for a frame stamped before a compromise and lost for one
        # stamped after. `manifest.created` is never used -- it is asserted by
        # the signer, which is the party a compromise puts in question.
        labels = ref.via or [None]
        outcomes = {
            label: rs.status_of(ref, trusted_time=times.get(label))
            for label in labels
        }
        headline = max(outcomes.values(), key=lambda s: _severity(s.state))

        mark = {"clean": "ok  ", "suspect": "??  ", "revoked": "GONE"}[headline.state]
        print(f"{mark} {ref.role:12s} {ref.subject or ref.key_id}")
        print(f"     {headline.headline()}")
        for note in headline.notes:
            print(f"       - {note}")

        spared = [l for l, s in outcomes.items() if s.state == STATE_CLEAN and l]
        if spared and headline.state != STATE_CLEAN:
            print(f"       + {len(spared)} file(s) are spared by a timestamp predating it")

        for label, status in outcomes.items():
            if label and status.state != STATE_CLEAN:
                if _severity(status.state) > _severity(worst):
                    worst = status.state
                implicated.setdefault(label, status.state)
        if not ref.via and headline.state != STATE_CLEAN:
            worst = max(worst, headline.state, key=_severity)
        print()

    if implicated:
        print(f"{len(implicated)} file(s) depend on a withdrawn or suspect identity:")
        for name in sorted(implicated)[:20]:
            print(f"  {implicated[name]:8s} {name}")
        if len(implicated) > 20:
            print(f"  ... and {len(implicated) - 20} more")
    elif not unexamined:
        print("nothing in this dataset depends on a withdrawn identity.")
    if unexamined:
        print()
        _report_unexamined(unexamined)
        worst = max(worst, STATE_SUSPECT, key=_severity)

    if worst == STATE_CLEAN:
        return EXIT_OK
    print()
    print("A withdrawal removes *evidence*, not necessarily correctness: the data may")
    print("still be right. What is gone is the ability to show where they came from.")
    return EXIT_BAD


# --------------------------------------------------------------------------
# timestamp authority
# --------------------------------------------------------------------------

def _load_tsa(args):
    from .keys import algorithm_of
    from .pki import load_certificates_pem
    from .tsa import ReferenceTSA

    key, _encrypted = load_private_key_for(
        args.tsa_key, env_var=args.password_env, file_path=args.password_file
    )
    certs = load_certificates_pem(pathlib.Path(args.tsa_cert).read_bytes())
    if not certs:
        raise ValueError(f"{args.tsa_cert} holds no certificate")
    algorithm_of(key.public_key())
    from .keys import SoftwareSigner

    return ReferenceTSA(SoftwareSigner(key), certs[0], certs[1:])


def cmd_tsa_init(args) -> int:
    from .keys import ALG_ED25519, generate_private_key, public_key_pem
    from .pki import load_certificates_pem
    from .tsa import make_tsa_certificate

    from cryptography.hazmat.primitives.serialization import Encoding

    ca_key, _ = load_private_key_for(
        args.ca_key, env_var=args.password_env, file_path=args.password_file
    )
    ca_certs = load_certificates_pem(pathlib.Path(args.ca_cert).read_bytes())
    if not ca_certs:
        raise ValueError(f"{args.ca_cert} holds no certificate")

    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    key = generate_private_key(ALG_ED25519)
    cert = make_tsa_certificate(ca_key, ca_certs[0], key.public_key(), args.name, args.org)

    write_private_key(key, out / "tsa.key", None, allow_plaintext=True)
    _write(out / "tsa.pem", cert.public_bytes(Encoding.PEM) + ca_certs[0].public_bytes(Encoding.PEM))
    _write(out / "tsa.pub.pem", public_key_pem(key.public_key()))

    print(f"timestamp authority provisioned in {out}/")
    print(f"  operator:    {args.org}")
    print(f"  certificate: {out / 'tsa.pem'}")
    print("  extended key usage: id-kp-timeStamping only, marked critical")
    print()
    print("Run it for a different organisation than the one that issues detector")
    print("certificates. A timestamp from the same body that signs the data cannot")
    print("survive that body being compromised, which is the case it exists for.")
    return EXIT_OK


def cmd_tsa_stamp(args) -> int:
    """Add a timestamp to frames that are already signed.

    Separate from signing on purpose: a facility can stamp a visit's frames
    after acquisition without holding the detector's key, which is exactly the
    division of labour that makes the facility timestamp *independent*.
    """
    import base64

    from ._canon import canonicalize
    from .api import CorruptSignature, _load_envelope_for
    from .formats import adapter_for
    from .manifest import timestamped_value
    from .timestamp import verify_token

    tsa = _load_tsa(args)
    stamped = failed = 0
    # A series has one signature for the whole run, so it gets one token: the
    # first frame of a run seen here asks the authority, the rest of the run
    # carries the same token. Keyed by the signature itself, so two runs that
    # share a series_id are still stamped separately.
    series_tokens = {}
    for path in _expand(args.files):
        if path.suffix.lower() in (".h5", ".hdf5", ".nxs"):
            from .run_h5 import stamp_run

            try:
                stamp_run(path, tsa)
            except (OSError, ValueError) as exc:
                print(f"skipped {path}: {exc}", file=sys.stderr)
                failed += 1
                continue
            stamped += 1
            print(f"timestamped {path}")
            continue
        # One read: the bytes that are inspected are the bytes rewritten, so a
        # file replaced in between cannot end up carrying a token for content
        # it does not have.
        data = path.read_bytes()
        adapter = adapter_for(data)
        try:
            envelope, base, source = _load_envelope_for(path, data, adapter)
        except (CorruptSignature, ValueError) as exc:
            print(f"skipped {path}: {exc}", file=sys.stderr)
            failed += 1
            continue
        if envelope is None:
            print(f"skipped {path}: not signed, so there is no signature to timestamp",
                  file=sys.stderr)
            failed += 1
            continue

        # What gets the token: the frame's own signature, or -- for a frame
        # signed as part of a series -- the run's signature, which lives in the
        # series envelope every frame of the run carries.
        from .manifest import signing_envelope

        target = signing_envelope(envelope)
        try:
            signature = base64.b64decode(target["signature"]["value"], validate=True)
        except (KeyError, TypeError, ValueError) as exc:
            print(f"skipped {path}: no readable signature to timestamp ({exc})",
                  file=sys.stderr)
            failed += 1
            continue
        digest = timestamped_value(signature)
        shared = target is not envelope
        encoded = series_tokens.get(signature) if shared else None
        if encoded is None:
            token = tsa.stamp(digest)
            # Check before storing: an unverifiable token in an archive looks
            # like evidence right up until somebody needs it.
            verify_token(token, digest)
            encoded = base64.b64encode(token).decode("ascii")
            if shared:
                series_tokens[signature] = encoded

        target.setdefault("timestamps", []).append(encoded)
        if source == "embedded":
            from .formats.cbf import make_block

            atomic_write(path, base + make_block(canonicalize(envelope)))
        else:
            sidecar = path.with_name(path.name + SIDECAR_SUFFIX)
            atomic_write(sidecar, json.dumps(envelope, indent=2).encode("utf-8") + b"\n")
        stamped += 1
        print(f"timestamped {path}" + ("  (series signature)" if shared else ""))

    if series_tokens:
        print(f"\n{len(series_tokens)} series signature(s) timestamped, one token each")
    print(f"\n{stamped} timestamped, {failed} skipped")
    return EXIT_OK if stamped and not failed else (EXIT_BAD if failed else EXIT_OK)


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except (OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_BAD
    except RuntimeError as exc:  # TpmError and friends
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_BAD


if __name__ == "__main__":  # pragma: no cover
    # `python -m framesig.cli` puts the current directory first on sys.path, so
    # an h5py.py (or numpy/, zipfile.py) in the data directory would be picked
    # up by the lazy imports below. Too late for what framesig/__init__ has
    # already imported: the `framesig` console script or `python -P -m
    # framesig.cli` avoids the problem entirely. Spawned workers are covered
    # either way: _parallel starts them with PYTHONSAFEPATH set.
    import os

    if sys.path and os.path.abspath(sys.path[0] or os.curdir) == os.getcwd():
        del sys.path[0]
    sys.exit(main())
