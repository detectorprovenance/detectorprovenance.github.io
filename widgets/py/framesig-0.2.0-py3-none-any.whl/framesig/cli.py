"""Command line interface.

    framesig keygen        make a signing key
    framesig ca init       stand up a demo vendor root + issuing CA
    framesig ca issue      issue a detector unit certificate
    framesig sign          sign one frame
    framesig sign-series   sign a run with one signature over a Merkle root
    framesig pack-run      pack a run into one HDF5 stack, signed once
    framesig verify-run    verify a packed Run-HDF5 frame by frame
    framesig verify        verify one or many frames
    framesig inspect       structural report, no cryptography
    framesig bundle create sign a set of frames as one dataset (counts, runs, DOI)
    framesig bundle verify check a bundle against the frames it names
    framesig bundle extract take the frames back out of a single-file bundle
    framesig bundle list   list what is inside a single-file bundle
    framesig oids          show the object identifiers this build uses
    framesig view          folder browser with per-frame validation badges
"""

from __future__ import annotations

import argparse
import glob
import json
import pathlib
import sys
from typing import List

from cryptography import x509

from . import __version__
from .api import SIDECAR_SUFFIX, inspect_file, sign_file, verify_file
from .keys import (
    ALGORITHMS,
    ALG_ECDSA_P256,
    ALG_ED25519,
    SoftwareSigner,
    generate_private_key,
    key_id,
    load_private_key,
    private_key_pem,
    public_key_pem,
)
from .attestation import ASSURANCE_INSTRUMENT, ASSURANCE_ORDER
from .container import CONTAINER_SUFFIXES
from .revocation import REASONS
from .keystore import (
    PLAINTEXT_OPT_IN,
    KeyCustodyError,
    check_key_file_permissions,
    load_private_key_for,
    read_private_key,
    resolve_passphrase,
    write_private_key,
)
from .pki import (
    load_certificates_pem,
    make_device_certificate,
    make_intermediate_ca,
    make_root_ca,
)

EXIT_OK = 0
EXIT_BAD = 1
EXIT_USAGE = 2

_STATUS_EXIT = {
    "valid": EXIT_OK,
    "repackaged": EXIT_OK,
    "metadata-modified": EXIT_BAD,
    "tampered": EXIT_BAD,
    "invalid": EXIT_BAD,
    "unsigned": EXIT_BAD,
}


def _write(path: pathlib.Path, data: bytes, secret: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    if secret:
        try:
            path.chmod(0o600)
        except OSError:  # pragma: no cover - Windows ACLs
            pass


def _load_roots(paths: List[str]) -> List[x509.Certificate]:
    roots: List[x509.Certificate] = []
    for p in paths:
        roots.extend(load_certificates_pem(pathlib.Path(p).read_bytes()))
    return roots


def _expand(patterns: List[str]) -> List[pathlib.Path]:
    out: List[pathlib.Path] = []
    for pat in patterns:
        p = pathlib.Path(pat)
        if p.is_dir():
            out.extend(sorted(q for q in p.iterdir() if q.is_file()
                              and q.suffix.lower() in (".cbf", ".img", ".mccd")))
        elif any(ch in pat for ch in "*?["):
            out.extend(sorted(pathlib.Path(m) for m in glob.glob(pat)))
        else:
            out.append(p)
    return out


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------

def _load_ca_key(path, args):
    return load_private_key_for(
        path,
        env_var=getattr(args, "password_env", None),
        file_path=getattr(args, "password_file", None),
        prompt="Passphrase for the CA private key: ",
    )


def _passphrase_args(sp, *, creating: bool):
    """Passphrase sources -- never argv.

    A passphrase on the command line is visible in `ps`, in Task Manager, in
    shell history and in CI logs. It is one of the most reliable ways to leak a
    key, and it looks perfectly safe, so the option simply does not exist.
    """
    sp.add_argument("--password-env", metavar="VAR",
                    help="read the passphrase from this environment variable")
    sp.add_argument("--password-file", metavar="PATH",
                    help="read the passphrase from this file (trailing newline stripped)")
    if creating:
        sp.add_argument(
            PLAINTEXT_OPT_IN,
            action="store_true",
            help="write the private key with no encryption at all (do not do this)",
        )


def cmd_keygen(args) -> int:
    key = generate_private_key(args.algorithm)
    priv = pathlib.Path(args.out)
    pub = priv.with_suffix(".pub.pem")

    passphrase = None
    if not args.i_accept_an_unencrypted_key:
        passphrase = resolve_passphrase(
            env_var=args.password_env,
            file_path=args.password_file,
            confirm=True,
            prompt="Passphrase to protect the new private key: ",
        )
    write_private_key(
        key, priv, passphrase,
        allow_plaintext=args.i_accept_an_unencrypted_key,
        encoding=args.encoding,
    )
    _write(pub, public_key_pem(key.public_key()))

    print(f"private key: {priv}  ({'encrypted ' if passphrase else 'UNENCRYPTED '}"
          f"PKCS#8 {args.encoding.upper()})")
    print(f"public key:  {pub}")
    print(f"algorithm:   {args.algorithm}")
    print(f"key id:      {key_id(key.public_key())}")
    if not passphrase:
        print()
        print("WARNING: this key is stored in the clear. Anyone who can read that file")
        print("can sign frames that verify as yours. Prefer a device-held key:")
        print("    framesig tpm create <name>")
    warning = check_key_file_permissions(priv)
    if warning:
        print(f"WARNING: {warning}")
    return EXIT_OK


def cmd_ca_init(args) -> int:
    out = pathlib.Path(args.dir)
    root_key = generate_private_key(args.algorithm)
    root_cert = make_root_ca(root_key, f"{args.org} Detector Root CA", args.org)
    sub_key = generate_private_key(args.algorithm)
    sub_cert = make_intermediate_ca(
        root_key, root_cert, sub_key, f"{args.org} Detector Issuing CA", args.org
    )
    from cryptography.hazmat.primitives.serialization import Encoding

    passphrase = None
    if not args.i_accept_an_unencrypted_key:
        passphrase = resolve_passphrase(
            env_var=args.password_env, file_path=args.password_file, confirm=True,
            prompt="Passphrase to protect the CA private keys: ",
        )
    write_private_key(root_key, out / "root.key.pem", passphrase,
                      allow_plaintext=args.i_accept_an_unencrypted_key, encoding="der")
    _write(out / "root.cert.pem", root_cert.public_bytes(Encoding.PEM))
    write_private_key(sub_key, out / "issuing.key.pem", passphrase,
                      allow_plaintext=args.i_accept_an_unencrypted_key, encoding="der")
    _write(out / "issuing.cert.pem", sub_cert.public_bytes(Encoding.PEM))
    print(f"vendor root CA:    {out / 'root.cert.pem'}  (this is the public trust anchor)")
    print(f"issuing CA:        {out / 'issuing.cert.pem'}")
    print("keep root.key.pem offline; in production the root never signs a frame")
    return EXIT_OK


def cmd_ca_issue(args) -> int:
    from cryptography.hazmat.primitives.serialization import Encoding, load_pem_public_key

    ca_dir = pathlib.Path(args.ca)
    ca_key, _ = _load_ca_key(ca_dir / "issuing.key.pem", args)
    ca_cert = load_certificates_pem((ca_dir / "issuing.cert.pem").read_bytes())[0]
    pub = load_pem_public_key(pathlib.Path(args.public_key).read_bytes())
    cert = make_device_certificate(
        ca_key, ca_cert, pub, args.serial, args.model, args.org,
        instrument_attested=args.instrument_attested,
    )
    chain = cert.public_bytes(Encoding.PEM) + ca_cert.public_bytes(Encoding.PEM)
    _write(pathlib.Path(args.out), chain)
    print(f"unit certificate chain: {args.out}")
    print(f"  subject: CN={args.serial}, OU={args.model}, O={args.org}")
    if args.instrument_attested:
        print("  policy:  instrument-attested (key inside the instrument)")
    else:
        print("  policy:  custodial (software- or facility-held key)")
        print("  frames signed with this key cannot reach instrument-level assurance.")
    return EXIT_OK


def _signer_and_certs(args):
    tpm_key = getattr(args, "tpm_key", None)
    if tpm_key:
        from .signers import HardwareSigner

        signer = HardwareSigner(tpm_key)
    elif args.key:
        key, encrypted = load_private_key_for(
            args.key, env_var=args.password_env, file_path=args.password_file
        )
        if not encrypted:
            print(
                f"WARNING: {args.key} holds an unencrypted private key; anyone who can "
                "read that file can forge your signatures.",
                file=sys.stderr,
            )
        warning = check_key_file_permissions(args.key)
        if warning:
            print(f"WARNING: {warning}", file=sys.stderr)
        signer = SoftwareSigner(key)
    else:
        raise SystemExit("supply a signing key with --key, or a TPM key with --tpm-key")
    certs = []
    if args.cert:
        certs = load_certificates_pem(pathlib.Path(args.cert).read_bytes())
    return signer, certs


def cmd_tpm_check(args) -> int:
    from .signers import tpm_available

    ok, detail = tpm_available()
    print(("available: " if ok else "unavailable: ") + detail)
    if ok:
        print(
            "Keys created here are non-exportable: the private key is generated inside\n"
            "the TPM and cannot be read out by framesig or by anything else."
        )
    return EXIT_OK if ok else EXIT_BAD


def cmd_tpm_create(args) -> int:
    from .signers import tpm_create_key

    public = tpm_create_key(args.name)
    out = pathlib.Path(args.out) if args.out else pathlib.Path(f"{args.name}.pub.pem")
    _write(out, public_key_pem(public))
    print(f"TPM key created: {args.name}")
    print(f"public key:      {out}")
    print(f"key id:          {key_id(public)}")
    print(f"algorithm:       {ALG_ECDSA_P256}")
    print("\nThe private key is inside the TPM and cannot be exported.")
    print(f"Share {out} with anyone who needs to verify; it reveals nothing secret.")
    return EXIT_OK


def cmd_tpm_export(args) -> int:
    from .signers import tpm_public_key

    public = tpm_public_key(args.name)
    out = pathlib.Path(args.out) if args.out else pathlib.Path(f"{args.name}.pub.pem")
    _write(out, public_key_pem(public))
    print(f"public key: {out}")
    print(f"key id:     {key_id(public)}")
    return EXIT_OK


def cmd_tpm_delete(args) -> int:
    from .signers import tpm_delete_key

    tpm_delete_key(args.name)
    print(f"deleted TPM key {args.name!r}")
    print("Frames already signed with it can no longer be re-signed, but they")
    print("remain verifiable: verification only ever needed the public key.")
    return EXIT_OK


def _claims_from(args) -> dict:
    claims = {}
    if args.claim:
        for item in args.claim:
            if "=" not in item:
                raise SystemExit(f"--claim expects key=value, got {item!r}")
            k, _, v = item.partition("=")
            claims[k.strip()] = v.strip()
    if args.claims_file:
        claims.update(json.loads(pathlib.Path(args.claims_file).read_text("utf-8")))
    return claims


def _attestation_from(args) -> dict:
    """Build the instrument attestation block.

    Refuses to invent one. A signer that quietly stamps `mode=physical` on
    everything would make the whole assurance ladder decorative, so the mode has
    to be stated and has to be a mode we know.
    """
    from .attestation import ACQUISITION_MODES

    att = {}
    for item in getattr(args, "attest", None) or []:
        if "=" not in item:
            raise SystemExit(f"--attest expects key=value, got {item!r}")
        k, _, v = item.partition("=")
        att[k.strip()] = v.strip()
    if not att:
        return {}
    mode = att.get("mode")
    if mode is None:
        raise SystemExit(
            "--attest requires mode=... ; one of: " + ", ".join(sorted(ACQUISITION_MODES))
        )
    if mode not in ACQUISITION_MODES:
        raise SystemExit(
            f"unknown acquisition mode {mode!r}; expected one of: "
            + ", ".join(sorted(ACQUISITION_MODES))
        )
    return att


def cmd_sign(args) -> int:
    signer, certs = _signer_and_certs(args)
    claims = _claims_from(args)
    attestation = _attestation_from(args)
    files = _expand(args.files)
    if not files:
        print("no input files matched", file=sys.stderr)
        return EXIT_USAGE
    for f in files:
        report = sign_file(
            f,
            signer,
            embed=not args.sidecar,
            output=args.output,
            certificates=certs,
            claims=claims or None,
            attestation=attestation or None,
            format_name=args.format,
        )
        print(
            f"signed {report['signed']} -> {report['signature']} "
            f"({report['payloads']} payload(s), {report['signed_length']} bytes covered)"
        )
    return EXIT_OK


def cmd_pack_run(args) -> int:
    from .pki import certificate_der
    from .run_h5 import pack_run

    signer, certs = _signer_and_certs(args)
    files = _expand(args.files)
    if not files:
        print("no input files matched", file=sys.stderr)
        return EXIT_USAGE
    pack_run(files, args.out, signer, series_id=args.series_id,
             certificates_der=[certificate_der(c) for c in certs],
             claims=_claims_from(args) or None, attestation=_attestation_from(args) or None,
             jobs=args.jobs)
    print(f"packed {len(files)} frames into {args.out}, one signature")
    return EXIT_OK


def cmd_verify_run(args) -> int:
    from .keys import load_public_key
    from .run_h5 import verify_run

    keys = [load_public_key(pathlib.Path(k).read_bytes()) for k in (args.public_key or [])]
    r = verify_run(args.file, keys)
    if args.json:
        print(json.dumps(r, indent=2))
        return EXIT_OK if r["ok"] else EXIT_BAD
    for p in r["problems"]:
        print(f"FAIL {p}")
    for f in r["frames"]:
        tag = "OK  " if f["status"] == "repackaged" else "FAIL"
        print(f"{tag} {f['status']:<18} frame {f['index']}" +
              (f"  ({'; '.join(f['problems'])})" if f["problems"] else ""))
    if r["intact"] and not r["pinned"]:
        print("FAIL unpinned: intact against the key inside the file, which proves "
              "integrity, not who signed; pass --public-key")
    return EXIT_OK if r["ok"] else EXIT_BAD


def cmd_sign_series(args) -> int:
    from ._canon import canonicalize
    from ._parallel import ordered_map
    from .api import series_frame_manifest
    from .formats import adapter_by_name, adapter_for
    from .formats.cbf import make_block
    from . import manifest as _m
    from .pki import certificate_der, public_key_matches, subject_string
    from .series import build_series

    signer, certs = _signer_and_certs(args)
    claims = _claims_from(args)
    attestation = _attestation_from(args)
    files = _expand(args.files)
    if not files:
        print("no input files matched", file=sys.stderr)
        return EXIT_USAGE
    if certs and not public_key_matches(certs[0], signer.public_key):
        print("leaf certificate does not match the signing key", file=sys.stderr)
        return EXIT_USAGE

    signer_info = {"key_id": signer.key_id, "alg": signer.algorithm}
    if certs:
        signer_info["subject"] = subject_string(certs[0])

    work = [(f, args.format, i, len(files), args.series_id, signer_info,
             claims or None, attestation or None) for i, f in enumerate(files)]
    manifests = []
    for i, m in enumerate(ordered_map(series_frame_manifest, work, args.jobs)):
        manifests.append(m)
        print(f"  hashed [{i + 1}/{len(files)}] {files[i].name}")

    series_env, frame_envs = build_series(
        manifests,
        signer,
        series_id=args.series_id,
        certificates_der=[certificate_der(c) for c in certs],
        claims=claims or None,
    )

    # Files are read a second time rather than held: a 3600-frame 6M run does
    # not fit in memory. A file that changed since it was hashed is refused,
    # or its envelope would be written next to bytes it does not cover.
    for f, manifest, env in zip(files, manifests, frame_envs):
        data = f.read_bytes()
        adapter = adapter_by_name(args.format) if args.format else adapter_for(data)
        base = adapter.normalise_base(adapter.strip(data))
        if _m.hash_body(base) != json.loads(manifest)["digests"]["body"]:
            print(f"{f} changed while the series was being signed; nothing "
                  f"written for it or the frames after it", file=sys.stderr)
            return EXIT_BAD
        env_json = canonicalize(env)
        if args.sidecar or not adapter.supports_embedding:
            f.with_name(f.name + SIDECAR_SUFFIX).write_bytes(
                json.dumps(env, indent=2).encode("utf-8") + b"\n"
            )
        else:
            f.write_bytes(base + make_block(env_json))

    root = json.loads(
        __import__("base64").b64decode(series_env["manifest"])
    )["merkle_root"]
    if args.series_out:
        pathlib.Path(args.series_out).write_bytes(
            json.dumps(series_env, indent=2).encode("utf-8") + b"\n"
        )
        print(f"series envelope: {args.series_out}")
    print(f"signed series {args.series_id!r}: {len(files)} frames, one signature")
    print(f"merkle root: {root}")
    return EXIT_OK


def cmd_verify(args) -> int:
    roots = _load_roots(args.trust or [])
    files = _expand(args.files)
    if not files:
        print("no input files matched", file=sys.stderr)
        return EXIT_USAGE
    worst = EXIT_OK
    results = []
    for f in files:
        result = verify_file(
            f,
            roots=roots,
            public_key_paths=args.public_key or [],
            sidecar=args.sidecar,
            timestamp_roots=_load_roots(getattr(args, "timestamp_trust", None) or []),
        )
        worst = max(worst, _STATUS_EXIT.get(result.status, EXIT_BAD))
        # Integrity alone is not success. The default question this tool answers
        # is "did an instrument produce this", so a frame that is intact but
        # only self-attested must not exit 0 -- a CI job or a journal pipeline
        # reads the exit code, and silently passing fabrications is the exact
        # failure this repository exists to prevent.
        if ASSURANCE_ORDER.index(result.assurance.level) < ASSURANCE_ORDER.index(args.require):
            worst = max(worst, EXIT_BAD)
        results.append((f, result))

    if args.json:
        print(json.dumps(
            [{"file": str(f), **r.to_dict()} for f, r in results], indent=2
        ))
        return worst

    for f, result in results:
        if len(files) > 1 and not args.verbose:
            if result.ok:
                mark = "OK  "
            elif result.intact:
                mark = "WEAK"  # intact, but origin not established
            else:
                mark = "FAIL"
            print(f"{mark} {result.status:18s} {result.assurance.level:14s} {f}")
        else:
            print(f"=== {f}")
            print(result.summary())
            print()
    attested = sum(1 for _, r in results if r.ok)
    weak = sum(1 for _, r in results if r.intact and not r.ok)
    broken = len(results) - attested - weak
    print()
    if weak or broken:
        print(
            f"{attested} instrument-attested, {weak} intact but unattested, "
            f"{broken} failing, of {len(files)} frame(s)."
        )
        if weak:
            print(
                "WEAK means the bytes are unchanged but nothing establishes that an\n"
                "instrument produced them -- a simulated or generated frame reaches\n"
                "this level too. Pass --require custodial or --require self-attested\n"
                "to accept it deliberately."
            )
    else:
        print(f"{len(files)} frame(s) verified and instrument-attested")
    return worst


def cmd_inspect(args) -> int:
    for f in _expand(args.files):
        print(json.dumps(inspect_file(f), indent=2))
    return EXIT_OK


# --------------------------------------------------------------------------
# bundles: one signed statement about a set of already-signed frames
# --------------------------------------------------------------------------

def _collect_members(files, roots, public_key_paths, name_of=None, keep_bytes=False):
    """Verify each frame and describe it as a prospective bundle member.

    **Each file is read exactly once.** An earlier version read every frame
    three times -- once to verify, once to pull out its envelope, once to pack
    it -- which is a time-of-check-to-time-of-use hole: a file swapped between
    reads would be attested under one digest and stored under different bytes,
    producing a bundle that certifies frames it does not contain. That is not a
    hypothetical race on a beamline, where an acquisition process may still be
    writing into the directory being bundled.

    ``keep_bytes`` retains what was read so the caller can write it straight
    into a container without going back to disk.
    """
    from .api import manifest_bytes_of, verify_data
    from .bundle import member_of
    from .keys import load_public_key

    keys = [load_public_key(pathlib.Path(k).read_bytes()) for k in (public_key_paths or [])]
    members, skipped = [], []
    for f in files:
        try:
            data = f.read_bytes()          # <-- the one and only read
        except OSError as exc:
            skipped.append((f, f"unreadable: {exc}"))
            continue

        sidecar = None
        sidecar_path = pathlib.Path(str(f) + SIDECAR_SUFFIX)
        if sidecar_path.exists():
            try:
                sidecar = json.loads(sidecar_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                skipped.append((f, f"unreadable sidecar: {exc}"))
                continue

        raw = manifest_bytes_of(data, sidecar)
        if raw is None:
            skipped.append((f, "no readable signature"))
            continue

        result = verify_data(data, roots=roots, public_keys=keys, sidecar=sidecar)
        if not result.signature_valid:
            skipped.append((f, result.status))
            continue

        series = (result.manifest or {}).get("series") or {}
        record = {
            # Identity is the digest of the exact manifest bytes that were
            # signed, so it binds contents, payload digests, attestation and
            # signer in one value.
            "manifest_digest": member_of(raw),
            "name": name_of(f) if name_of else f.name,
            "assurance": result.assurance.level,
            "series_id": series.get("id"),
            "series_index": series.get("index"),
            "status": result.status,
        }
        if keep_bytes:
            record["data"] = data
        members.append(record)
    return members, skipped


def _envelope_of(path):
    """Pull the envelope out of a frame, embedded or sidecar."""
    import json as _json

    from .api import SIDECAR_SUFFIX
    from .formats.cbf import CbfAdapter, read_block

    data = pathlib.Path(path).read_bytes()
    offset = CbfAdapter()._find_block(data)
    if offset is not None:
        return _json.loads(read_block(data[offset:]).decode("utf-8"))
    sidecar = pathlib.Path(str(path) + SIDECAR_SUFFIX)
    if sidecar.exists():
        return _json.loads(sidecar.read_text(encoding="utf-8"))
    raise ValueError("no signature found")


def _relative_name(path, all_paths):
    """A stable in-archive name.

    Uses the deepest common parent of everything being bundled, so that
    `run_A/f_0000.cbf` and `run_B/f_0000.cbf` stay distinct instead of
    colliding on their bare filenames.
    """
    import os

    try:
        common = pathlib.Path(os.path.commonpath([str(p.resolve().parent) for p in all_paths]))
        return str(path.resolve().relative_to(common)).replace("\\", "/")
    except (ValueError, OSError):
        return path.name


def cmd_bundle_create(args) -> int:
    from .bundle import PROVENANCE_FIELDS, build_bundle, validate_provenance
    from .keys import public_key_bytes
    from .pki import certificate_der

    signer, certs = _signer_and_certs(args)
    roots = _load_roots(args.trust or [])
    files = _expand(args.files)
    if not files:
        print("no input files matched", file=sys.stderr)
        return EXIT_USAGE

    provenance = {}
    for item in args.provenance or []:
        if "=" not in item:
            raise SystemExit(f"--set expects key=value, got {item!r}")
        k, _, v = item.partition("=")
        provenance[k.strip()] = v.strip()
    unknown = set(provenance) - set(PROVENANCE_FIELDS)
    for key in sorted(unknown):
        print(f"note: {key!r} is not a well-known provenance field; it will be "
              "signed but not interpreted")
    for problem in validate_provenance(provenance):
        print(f"WARNING: {problem}", file=sys.stderr)

    out = pathlib.Path(args.out)
    pack = args.pack if args.pack is not None else out.suffix.lower() in CONTAINER_SUFFIXES
    members, skipped = _collect_members(
        files, roots, args.public_key or [],
        name_of=lambda f: _relative_name(f, files),
        # When packing, hold on to what was verified: writing the container
        # from a second read would let a file change in between, and the bundle
        # would then attest digests it does not contain.
        keep_bytes=pack,
    )
    for f, why in skipped:
        print(f"skipped {f}: {why}", file=sys.stderr)
    if not members:
        print("no verifiable frames to bundle", file=sys.stderr)
        return EXIT_BAD
    if skipped and not args.allow_unverifiable:
        print(
            f"refusing to bundle: {len(skipped)} frame(s) could not be verified. "
            "A bundle that quietly omits frames misrepresents the dataset; pass "
            "--allow-unverifiable to bundle the rest deliberately.",
            file=sys.stderr,
        )
        return EXIT_BAD

    envelope = build_bundle(
        [{k: v for k, v in m.items() if k != "data"} for m in members], signer,
        bundle_id=args.bundle_id,
        provenance=provenance or None,
        certificates_der=[certificate_der(c) for c in certs],
        public_key_der=public_key_bytes(signer.public_key),
    )
    if pack:
        from .container import write_container

        write_container(out, envelope, [(m["name"], m["data"]) for m in members])
    else:
        out.write_bytes(json.dumps(envelope, indent=2).encode("utf-8") + b"\n")

    import base64

    bundle = json.loads(base64.b64decode(envelope["manifest"]))
    print(f"bundle written: {out}" + ("  (single file, frames inside)" if pack else ""))
    print(f"  id:      {bundle['bundle_id']}")
    print(f"  frames:  {bundle['counts']['frames']} in {bundle['counts']['runs']} run(s)")
    print(f"  root:    {bundle['members_root']}")
    print(f"  floor:   {bundle['member_assurance_floor']}  (weakest member assurance)")
    if bundle["member_assurance_floor"] != ASSURANCE_INSTRUMENT:
        print()
        print("NOTE: a bundle cannot raise the assurance of its members. This one")
        print("contains frames whose origin is not established, and says so in the")
        print("signed manifest; it is not evidence that the data were measured.")
    return EXIT_OK


def cmd_bundle_verify(args) -> int:
    from .api import verify_file
    from .bundle import member_of, verify_bundle
    from .keys import load_public_key

    from .api import manifest_bytes_of, verify_data
    from .container import is_container, open_container

    roots = _load_roots(args.trust or [])
    keys = [load_public_key(pathlib.Path(k).read_bytes()) for k in (args.public_key or [])]
    bundle_path = pathlib.Path(args.bundle)

    found = None
    if is_container(bundle_path):
        # A single-file bundle carries its own frames, so there is nothing to
        # point at and nothing that can have been left behind.
        container = open_container(bundle_path)
        envelope = container.envelope
        found = {}
        for name, data in container.iter_frames():
            raw = manifest_bytes_of(data)
            if raw is None:
                continue
            result = verify_data(data, roots=roots, public_keys=keys)
            found[member_of(raw)] = {
                "name": name,
                "assurance": result.assurance.level,
                "status": result.status,
            }
        print(f"container: {bundle_path.name}  ({len(container.frame_names)} frame(s) inside)")
    else:
        envelope = json.loads(bundle_path.read_text(encoding="utf-8"))
        if args.files:
            found = {}
            for f in _expand(args.files):
                # One read: identity and verdict must describe the same bytes,
                # or a file swapped between them is reported under the wrong
                # verdict.
                data = f.read_bytes()
                raw = manifest_bytes_of(data)
                if raw is None:
                    continue
                result = verify_data(data, roots=roots, public_keys=keys)
                found[member_of(raw)] = {
                    "name": f.name,
                    "assurance": result.assurance.level,
                    "status": result.status,
                }

    report = verify_bundle(envelope, found=found, public_keys=keys)
    bundle = report["bundle"] or {}

    print(f"bundle:    {bundle.get('bundle_id')}")
    print(f"signature: {'valid' if report['signature_valid'] else 'INVALID'}")
    print(f"declares:  {(bundle.get('counts') or {}).get('frames')} frame(s) in "
          f"{(bundle.get('counts') or {}).get('runs')} run(s)")
    print(f"floor:     {report['member_assurance_floor']}  (weakest member, as signed)")
    if "observed_assurance_floor" in report:
        print(f"observed:  {report['observed_assurance_floor']}  (weakest member, as verified)")
    for key, value in sorted((bundle.get("provenance") or {}).items()):
        print(f"  {key:22s} {value}")

    if found is not None:
        print()
        print(f"present:    {len(report['present'])}")
        print(f"missing:    {len(report['missing'])}")
        print(f"unexpected: {len(report['unexpected'])}")
        for entry in report["missing"][:20]:
            print(f"  MISSING    {entry['name']}")
        for entry in report["unexpected"][:20]:
            print(f"  UNEXPECTED {entry['name']}  (not a member of this bundle)")
        for entry in report["renamed"][:20]:
            print(f"  renamed    {entry['signed_as']} -> {entry['found_as']}")
        for entry in report["downgraded"][:20]:
            print(f"  DOWNGRADED {entry['name']}: bundled as {entry['bundled_as']}, "
                  f"now verifies as {entry['verifies_as']}")

    for problem in report["problems"]:
        print(f"  ! {problem}")
    for note in report["notes"]:
        print(f"  - {note}")

    if found is None:
        return EXIT_OK if report["signature_valid"] else EXIT_BAD
    print()
    print("complete and consistent" if report["complete"] else "BUNDLE DOES NOT MATCH THESE FILES")
    return EXIT_OK if report["complete"] else EXIT_BAD


def cmd_bundle_extract(args) -> int:
    from .api import manifest_bytes_of, verify_data
    from .bundle import member_of, verify_bundle
    from .container import open_container, safe_member_path

    container = open_container(args.bundle)
    roots = _load_roots(args.trust or [])
    destination = pathlib.Path(args.out)
    wanted = set(args.frame) if args.frame else None

    # Read each entry once, and hold it only long enough to verify and write.
    # Verifying everything and *then* re-reading to extract would let the
    # archive change in between; and holding a whole dataset in memory is not
    # an option when a run is tens of gigabytes.
    found, staged = {}, []
    for name, data in container.iter_frames():
        raw = manifest_bytes_of(data)
        if raw is not None:
            result = verify_data(data, roots=roots)
            found[member_of(raw)] = {"name": name, "assurance": result.assurance.level}
        if wanted is None or name in wanted:
            staged.append((name, data))

    report = verify_bundle(container.envelope, found=found)
    if not report["complete"] and not args.force:
        print("refusing to extract: this bundle does not verify.", file=sys.stderr)
        for problem in report["problems"]:
            print(f"  ! {problem}", file=sys.stderr)
        for entry in report["missing"]:
            print(f"  MISSING {entry['name']}", file=sys.stderr)
        for entry in report["unexpected"]:
            print(f"  UNEXPECTED {entry['name']}", file=sys.stderr)
        print("pass --force to extract anyway.", file=sys.stderr)
        return EXIT_BAD

    destination.mkdir(parents=True, exist_ok=True)
    written = []
    for name, data in staged:
        target = safe_member_path(name, destination)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        written.append(target)
        print(target)
    print(f"\nextracted {len(written)} frame(s) to {destination}")
    if not report["complete"]:
        print("WARNING: extracted from a bundle that does not verify.", file=sys.stderr)
    return EXIT_OK


def cmd_bundle_list(args) -> int:
    from .api import manifest_bytes_of, verify_data
    from .bundle import member_of
    from .container import open_container

    container = open_container(args.bundle)
    roots = _load_roots(args.trust or [])
    import base64

    bundle = json.loads(base64.b64decode(container.envelope["manifest"]))
    members = {e["m"]: e for e in bundle.get("members", [])}

    print(f"{bundle.get('bundle_id')}  -  {bundle['counts']['frames']} frame(s), "
          f"{bundle['counts']['runs']} run(s)")
    for key, value in sorted((bundle.get("provenance") or {}).items()):
        print(f"  {key:22s} {value}")
    print()
    for name in container.frame_names:
        data = container.read_frame(name)
        raw = manifest_bytes_of(data)
        member = raw is not None and member_of(raw) in members
        if args.verify:
            result = verify_data(data, roots=roots)
            mark = "OK  " if result.ok else ("WEAK" if result.intact else "FAIL")
            note = result.assurance.level
        else:
            mark, note = "    ", ""
        print(f"{mark} {'member' if member else 'NOT A MEMBER':12s} "
              f"{container.frame_size(name):>10,d}  {note:14s} {name}")
    return EXIT_OK


def cmd_oids(args) -> int:
    from .oids import (
        ACTIVE_PEN,
        DOCUMENTATION_PEN,
        IANA_APPLY_URL,
        RECOGNISED_PENS,
        is_provisional,
        registry,
    )

    print(f"active enterprise number: {ACTIVE_PEN}")
    print(f"recognised on verify:     {', '.join(str(p) for p in RECOGNISED_PENS)}")
    print()
    for oid, label in registry():
        print(f"  {oid:<34s} {label}")
    if is_provisional(ACTIVE_PEN):
        print()
        print(f"WARNING: {ACTIVE_PEN} is the RFC 5612 documentation arc. It is reserved for")
        print("examples and belongs to no organisation, so the identifiers above are not")
        print("globally unique. Register a Private Enterprise Number before deploying:")
        print(f"  {IANA_APPLY_URL}")
        print("Then set ACTIVE_PEN in src/framesig/oids.py and web/framesig/oids.js.")
        print("See docs/OIDS.md.")
    return EXIT_OK


def cmd_view(args) -> int:
    from .viewer import run_viewer

    return run_viewer(
        folder=args.folder,
        trust=args.trust or [],
        public_keys=args.public_key or [],
    )


# --------------------------------------------------------------------------
# parser
# --------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="framesig", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--version", action="version", version=f"framesig {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    g = sub.add_parser("keygen", help="generate a signing key pair")
    g.add_argument("out", help="path for the private key")
    g.add_argument("--algorithm", choices=ALGORITHMS, default=ALG_ED25519)
    g.add_argument("--encoding", choices=("der", "pem"), default="der",
                   help="encrypted PKCS#8 DER (binary, default) or PEM")
    _passphrase_args(g, creating=True)
    g.set_defaults(func=cmd_keygen)

    ca = sub.add_parser("ca", help="demo vendor certificate authority")
    casub = ca.add_subparsers(dest="ca_command", required=True)
    ci = casub.add_parser("init", help="create a root CA and an issuing CA")
    ci.add_argument("dir", help="directory to create the CA in")
    ci.add_argument("--org", default="Example Detectors GmbH")
    ci.add_argument("--algorithm", choices=ALGORITHMS, default=ALG_ED25519)
    _passphrase_args(ci, creating=True)
    ci.set_defaults(func=cmd_ca_init)
    cis = casub.add_parser("issue", help="issue a detector unit certificate")
    cis.add_argument("--ca", required=True, help="CA directory from 'ca init'")
    cis.add_argument("--public-key", required=True, help="the unit's public key (PEM)")
    cis.add_argument("--serial", required=True, help="detector serial number")
    cis.add_argument("--model", default="unspecified")
    cis.add_argument("--org", default="Example Detectors GmbH")
    cis.add_argument("--out", required=True, help="output certificate chain (PEM)")
    cis.add_argument(
        "--instrument-attested", action="store_true",
        help="assert that this key is held in a secure element inside the "
             "instrument and was provisioned during manufacture. Only a "
             "manufacturer can honestly set this; it is what separates a "
             "signature that proves origin from one that does not.",
    )
    _passphrase_args(cis, creating=False)
    cis.set_defaults(func=cmd_ca_issue)

    def _sign_args(sp):
        sp.add_argument("files", nargs="+", help="files, globs or a directory")
        sp.add_argument("--key", help="signing private key (PEM)")
        sp.add_argument(
            "--tpm-key",
            help="name of a hardware-held key to sign with instead (TPM or Secure Enclave; "
                 "see 'framesig tpm')",
        )
        _passphrase_args(sp, creating=False)
        sp.add_argument("--cert", help="unit certificate chain (PEM) to embed")
        sp.add_argument("--sidecar", action="store_true",
                        help=f"write a detached '{SIDECAR_SUFFIX}' file instead of embedding")
        sp.add_argument("--claim", action="append",
                        help="operator-supplied provenance claim as key=value; repeatable")
        sp.add_argument("--claims-file", help="JSON file of provenance claims")
        sp.add_argument(
            "--attest", action="append", metavar="KEY=VALUE",
            help="instrument attestation as key=value (mode, model, serial, "
                 "firmware, sensor); repeatable. Without mode=physical the frame "
                 "cannot reach instrument-level assurance.",
        )
        sp.add_argument("--format", help="force a format adapter (cbf, raw)")

    s = sub.add_parser("sign", help="sign one or more frames individually")
    _sign_args(s)
    s.add_argument("--output", help="write to this path instead of in place (single file only)")
    s.set_defaults(func=cmd_sign)

    ss = sub.add_parser("sign-series", help="sign a run with one Merkle-rooted signature")
    _sign_args(ss)
    ss.add_argument("--series-id", required=True, help="identifier for this run")
    ss.add_argument("--series-out", help="also write the series envelope here")
    ss.add_argument("--jobs", type=int, help="processes hashing frames in "
                    "parallel (default: one per CPU); the run is still signed once")
    ss.set_defaults(func=cmd_sign_series)

    pr = sub.add_parser("pack-run", help="pack a run into one HDF5 stack, signed once")
    _sign_args(pr)
    pr.add_argument("--series-id", required=True, help="identifier for this run")
    pr.add_argument("--out", required=True, help="Run-HDF5 file to write")
    pr.add_argument("--jobs", type=int, help="processes hashing frames in "
                    "parallel (default: one per CPU); the run is still signed once")
    pr.set_defaults(func=cmd_pack_run)

    vr = sub.add_parser("verify-run", help="verify a Run-HDF5 frame by frame")
    vr.add_argument("file", help="the Run-HDF5 file")
    vr.add_argument("--public-key", action="append", help="pin to this public key (PEM); repeatable")
    vr.add_argument("--json", action="store_true", help="machine-readable output")
    vr.set_defaults(func=cmd_verify_run)

    v = sub.add_parser("verify", help="verify frames")
    v.add_argument("files", nargs="+", help="files, globs or a directory")
    v.add_argument("--trust", action="append", help="trusted root CA (PEM); repeatable")
    v.add_argument("--public-key", action="append",
                   help="accept this bare public key (PEM); repeatable")
    v.add_argument("--sidecar", help="explicit sidecar path (single file only)")
    v.add_argument("--timestamp-trust", action="append",
                   help="trusted root for timestamp authorities (PEM); repeatable")
    v.add_argument("--bundle", help="verify these frames against a signed bundle")
    v.add_argument("--json", action="store_true", help="machine-readable output")
    v.add_argument("-v", "--verbose", action="store_true", help="full report per file")
    v.add_argument(
        "--require", choices=ASSURANCE_ORDER, default=ASSURANCE_INSTRUMENT,
        help="minimum assurance level to exit 0 (default: instrument). Lower it "
             "only when you knowingly accept frames whose origin is not established.",
    )
    v.set_defaults(func=cmd_verify)

    i = sub.add_parser("inspect", help="structural report, no cryptography")
    i.add_argument("files", nargs="+")
    i.set_defaults(func=cmd_inspect)

    b = sub.add_parser("bundle", help="sign or check a whole dataset as one object")
    bsub = b.add_subparsers(dest="bundle_command", required=True)

    bc = bsub.add_parser("create", help="sign a set of already-signed frames as a dataset")
    bc.add_argument("files", nargs="+", help="frames, globs or directories")
    bc.add_argument("--out", required=True, help="output bundle (JSON)")
    bc.add_argument("--bundle-id", required=True, help="identifier for this dataset")
    bc.add_argument("--key", help="signing private key")
    bc.add_argument("--tpm-key", help="name of a TPM-held key to sign the bundle with")
    bc.add_argument("--cert", help="certificate chain (PEM) for the bundle signer")
    bc.add_argument("--trust", action="append", help="trusted root for verifying members")
    bc.add_argument("--public-key", action="append", help="pinned key for verifying members")
    bc.add_argument("--set", dest="provenance", action="append", metavar="KEY=VALUE",
                    help="provenance: operator, orcid, facility, beamline, proposal, "
                         "doi, publication_doi, sample, licence, contact; repeatable")
    bc.add_argument("--allow-unverifiable", action="store_true",
                    help="bundle the verifiable frames even if some could not be verified")
    bc.add_argument("--pack", dest="pack", action="store_true", default=None,
                    help="write one file containing the frames (default for .framebundle)")
    bc.add_argument("--no-pack", dest="pack", action="store_false",
                    help="write only the bundle manifest, leaving the frames where they are")
    _passphrase_args(bc, creating=False)
    bc.set_defaults(func=cmd_bundle_create)

    bv = bsub.add_parser("verify", help="check a bundle, and optionally the frames it names")
    bv.add_argument("bundle", help="the bundle file")
    bv.add_argument("files", nargs="*", help="the frames it should contain")
    bv.add_argument("--trust", action="append", help="trusted root CA (PEM)")
    bv.add_argument("--public-key", action="append", help="accept this bare public key (PEM)")
    bv.set_defaults(func=cmd_bundle_verify)

    be = bsub.add_parser("extract", help="take the frames back out of a single-file bundle")
    be.add_argument("bundle")
    be.add_argument("--out", required=True, help="directory to extract into")
    be.add_argument("--frame", action="append", help="extract only this frame; repeatable")
    be.add_argument("--trust", action="append", help="trusted root CA (PEM)")
    be.add_argument("--force", action="store_true",
                    help="extract even if the bundle does not verify")
    be.set_defaults(func=cmd_bundle_extract)

    bl = bsub.add_parser("list", help="list what is inside a single-file bundle")
    bl.add_argument("bundle")
    bl.add_argument("--verify", action="store_true", help="verify each frame while listing")
    bl.add_argument("--trust", action="append", help="trusted root CA (PEM)")
    bl.set_defaults(func=cmd_bundle_list)

    t = sub.add_parser("tpm", help="use a key held in this machine's TPM or Secure Enclave")
    tsub = t.add_subparsers(dest="tpm_command", required=True)
    tc = tsub.add_parser("check", help="is a TPM-backed key provider usable here?")
    tc.set_defaults(func=cmd_tpm_check)
    tn = tsub.add_parser("create", help="create a non-exportable P-256 key in the TPM")
    tn.add_argument("name", help="a name for the key, e.g. detector-01")
    tn.add_argument("--out", help="where to write the public key (default <name>.pub.pem)")
    tn.set_defaults(func=cmd_tpm_create)
    te = tsub.add_parser("export-public", help="write the public key of an existing TPM key")
    te.add_argument("name")
    te.add_argument("--out")
    te.set_defaults(func=cmd_tpm_export)
    td = tsub.add_parser("delete", help="destroy a TPM key (irreversible)")
    td.add_argument("name")
    td.set_defaults(func=cmd_tpm_delete)

    o = sub.add_parser("oids", help="show the object identifiers this build uses")
    o.set_defaults(func=cmd_oids)

    inv_p = sub.add_parser(
        "inventory",
        help="list every key and certificate a dataset depends on",
    )
    inv_p.add_argument("files", nargs="+", help="frames, a folder, or a .framebundle")
    inv_p.add_argument("--json", action="store_true", help="emit the canonical records")
    inv_p.set_defaults(func=cmd_inventory)

    r = sub.add_parser("revoke", help="issue or inspect a signed withdrawal list")
    rsub = r.add_subparsers(dest="revoke_command", required=True)

    rc = rsub.add_parser("create", help="sign a withdrawal list")
    rc.add_argument("--out", required=True, help="where to write the list")
    rc.add_argument("--issuer", required=True, help="who is withdrawing (organisation name)")
    rc.add_argument("--key", help="signing key (PEM); the authority's key, not a detector's")
    rc.add_argument("--tpm-key", help="sign with this TPM key instead")
    rc.add_argument("--password-env", help="env var holding the key passphrase")
    rc.add_argument("--password-file", help="file holding the key passphrase")
    rc.add_argument("--cert", action="append", help="certificate chain for the list signer (PEM)")
    rc.add_argument("--key-id", action="append", default=[],
                    help="withdraw this key fingerprint (sha256:...); repeatable")
    rc.add_argument("--cert-digest", action="append", default=[],
                    help="withdraw this certificate digest (sha256:...); repeatable")
    rc.add_argument("--reason", required=True, choices=list(REASONS),
                    help="RFC 5280 CRLReason")
    rc.add_argument("--invalidity-date",
                    help="UTC date the key stopped being trustworthy "
                         "(required for the compromise reasons)")
    rc.add_argument("--next-update", help="UTC date after which this list is stale")
    rc.add_argument("--note", help="free text recorded with the entry")
    rc.set_defaults(func=cmd_revoke_create)

    rs = rsub.add_parser("show", help="check a withdrawal list's signature and print it")
    rs.add_argument("list", help="the revocation list")
    rs.add_argument("--public-key", action="append", help="key the list should verify under")
    rs.set_defaults(func=cmd_revoke_show)

    a = sub.add_parser(
        "audit",
        help="intersect a dataset's signer inventory with a withdrawal list",
    )
    a.add_argument("files", nargs="+", help="frames, a folder, or a .framebundle")
    a.add_argument("--revocations", help="a signed withdrawal list")
    a.add_argument("--public-key", action="append",
                   help="key the withdrawal list should verify under (PEM)")
    a.add_argument("--timestamp-trust", action="append",
                   help="trusted root for timestamp authorities (PEM); repeatable. "
                        "Without one, no signature can be shown to predate a compromise")
    a.set_defaults(func=cmd_audit)

    tsa = sub.add_parser("tsa", help="run or provision an RFC 3161 timestamp authority")
    tsasub = tsa.add_subparsers(dest="tsa_command", required=True)
    ti = tsasub.add_parser("init", help="create a timestamp authority under an existing CA")
    ti.add_argument("--ca-key", required=True, help="issuing CA private key (PEM)")
    ti.add_argument("--ca-cert", required=True, help="issuing CA certificate (PEM)")
    ti.add_argument("--name", default="Timestamp Authority")
    ti.add_argument("--org", required=True, help="the organisation operating it")
    ti.add_argument("--out", required=True, help="directory for the key and certificate")
    ti.add_argument("--password-env", help="env var holding the CA key passphrase")
    ti.add_argument("--password-file", help="file holding the CA key passphrase")
    ti.set_defaults(func=cmd_tsa_init)

    tst = tsasub.add_parser("stamp", help="timestamp a file's signature, offline")
    tst.add_argument("files", nargs="+")
    tst.add_argument("--tsa-key", required=True, help="the authority's private key (PEM)")
    tst.add_argument("--tsa-cert", required=True, help="the authority's certificate (PEM)")
    tst.add_argument("--password-env", help="env var holding the key passphrase")
    tst.add_argument("--password-file", help="file holding the key passphrase")
    tst.set_defaults(func=cmd_tsa_stamp)

    w = sub.add_parser("view", help="browse frames, from a folder or a single-file bundle")
    w.add_argument("folder", nargs="?", default=".",
                   help="a directory of frames, or a .framebundle")
    w.add_argument("--trust", action="append", help="trusted root CA (PEM); repeatable")
    w.add_argument("--public-key", action="append", help="accept this bare public key (PEM)")
    w.set_defaults(func=cmd_view)

    return p


# --------------------------------------------------------------------------
# inventory / revocation / audit
# --------------------------------------------------------------------------

def _inventory_of_paths(patterns: List[str], timestamp_roots=()):
    """Observe every signing identity the named files depend on.

    Returns ``(refs, times)``, where ``times`` maps each ``via`` label to the
    instant a trusted timestamp places that file at, or None. Time is per file,
    not per dataset: two frames signed with one key can have entirely different
    time evidence, and a withdrawal may spare one and not the other.

    Each file is read once. Enumeration never verifies the *signature*, because
    an audit has to list the signers of files whose signatures have stopped
    verifying -- which is exactly what a withdrawal creates.
    """
    from .api import envelope_of, inventory_of, _assess_timestamps
    from .container import is_container, open_container
    from .inventory import inventory_from_envelope, merge

    collected, times = [], {}

    def _record(data: bytes, label: str):
        collected.append(inventory_of(data, via=label))
        envelope = envelope_of(data)
        if envelope:
            evidence = _assess_timestamps(envelope, [], timestamp_roots)
            times[label] = evidence.established_at if evidence.usable else None

    for pattern in patterns:
        path = pathlib.Path(pattern)
        if path.is_file() and is_container(path):
            with open_container(path) as container:
                collected.append(
                    inventory_from_envelope(container.envelope, via=f"{path.name}:bundle")
                )
                for name, data in container.iter_frames():
                    _record(data, f"{path.name}:{name}")
            continue
        for f in _expand([pattern]):
            if f.is_file():
                _record(f.read_bytes(), f.name)
    return merge(*collected), times


def cmd_inventory(args) -> int:
    from .inventory import inventory_digest, records_of

    refs, _times = _inventory_of_paths(args.files)
    if not refs:
        print("no signing identities found; are these files signed?", file=sys.stderr)
        return EXIT_BAD

    records = records_of(refs)
    if args.json:
        print(json.dumps({"spec": "framesig-inventory/1",
                          "digest": inventory_digest(records),
                          "signers": records}, indent=2))
        return EXIT_OK

    print(f"{len(refs)} signing identit{'y' if len(refs) == 1 else 'ies'}")
    print(f"digest: {inventory_digest(records)}\n")
    for ref in refs:
        print(f"  {ref.role:12s} {ref.subject or '(bare key)'}")
        print(f"  {'':12s} key    {ref.key_id}")
        if ref.cert:
            print(f"  {'':12s} cert   {ref.cert}")
            print(f"  {'':12s} valid  {ref.not_before} .. {ref.not_after}")
        shown = ref.via[:3]
        more = f" (+{len(ref.via) - 3} more)" if len(ref.via) > 3 else ""
        if shown:
            print(f"  {'':12s} via    {', '.join(shown)}{more}")
        print()
    return EXIT_OK


def cmd_revoke_create(args) -> int:
    from .revocation import build_revocation_list

    signer, certs = _signer_and_certs(args)
    entries = []
    for value in args.key_id:
        entries.append({"key_id": value})
    for value in args.cert_digest:
        entries.append({"cert": value})
    if not entries:
        print("nothing to withdraw: pass --key-id and/or --cert-digest", file=sys.stderr)
        return EXIT_USAGE
    for entry in entries:
        entry["reason"] = args.reason
        if args.invalidity_date:
            entry["invalidity_date"] = args.invalidity_date
        if args.note:
            entry["note"] = args.note

    envelope = build_revocation_list(
        entries, signer,
        issuer=args.issuer,
        next_update=args.next_update,
        certificates_der=[certificate_der(c) for c in certs],
    )
    out = pathlib.Path(args.out)
    _write(out, json.dumps(envelope, indent=2).encode("utf-8") + b"\n")

    print(f"withdrawal list written: {out}")
    print(f"  issuer:  {args.issuer}")
    print(f"  reason:  {args.reason}")
    print(f"  entries: {len(entries)}")
    if args.invalidity_date:
        print(f"  since:   {args.invalidity_date}")
        print("           signatures provably made before this date are unaffected")
    else:
        print("  since:   not stated -- this is a retirement, not an accusation")
    return EXIT_OK


def _load_revocations(args):
    from .keys import load_public_key
    from .revocation import RevocationSet, verify_revocation_list

    if not getattr(args, "revocations", None):
        return RevocationSet.absent()
    keys = [load_public_key(pathlib.Path(k).read_bytes()) for k in (args.public_key or [])]
    envelope = json.loads(pathlib.Path(args.revocations).read_text(encoding="utf-8"))
    return verify_revocation_list(envelope, public_keys=keys, source=args.revocations)


def cmd_revoke_show(args) -> int:
    args.revocations = args.list
    rs = _load_revocations(args)
    print(rs.describe())
    for problem in rs.problems:
        print(f"  ! {problem}")
    print()
    for entry in rs.entries:
        target = entry.get("key_id") or entry.get("cert")
        print(f"  {entry.get('reason'):22s} {target}")
        if entry.get("invalidity_date"):
            print(f"  {'':22s} untrustworthy from {entry['invalidity_date']}")
        if entry.get("note"):
            print(f"  {'':22s} {entry['note']}")
    return EXIT_OK if rs.signature_valid else EXIT_BAD


def cmd_audit(args) -> int:
    from .revocation import STATE_CLEAN, STATE_REVOKED, _severity

    timestamp_roots = _load_roots(args.timestamp_trust or [])
    refs, times = _inventory_of_paths(args.files, timestamp_roots)
    if not refs:
        print("no signing identities found; are these files signed?", file=sys.stderr)
        return EXIT_BAD

    rs = _load_revocations(args)
    print(rs.describe())
    for problem in rs.problems:
        print(f"  ! {problem}")
    stamped = sum(1 for t in times.values() if t is not None)
    if stamped:
        print(f"time evidence: {stamped} of {len(times)} file(s) carry a trusted timestamp")
    elif times:
        print("time evidence: none -- no file carries a timestamp from a trusted authority,")
        print("               so a compromise can only be treated as all-or-nothing")
    print()

    worst = STATE_CLEAN
    implicated = {}
    for ref in refs:
        # Evaluated per file, because time evidence is per file: the same key
        # may be spared for a frame stamped before a compromise and lost for one
        # stamped after. `manifest.created` is never used -- it is asserted by
        # the signer, which is the party a compromise puts in question.
        labels = ref.via or [None]
        outcomes = {
            label: rs.status_of(ref, trusted_time=times.get(label))
            for label in labels
        }
        headline = max(outcomes.values(), key=lambda s: _severity(s.state))

        mark = {"clean": "ok  ", "suspect": "??  ", "revoked": "GONE"}[headline.state]
        print(f"{mark} {ref.role:12s} {ref.subject or ref.key_id}")
        print(f"     {headline.headline()}")
        for note in headline.notes:
            print(f"       - {note}")

        spared = [l for l, s in outcomes.items() if s.state == STATE_CLEAN and l]
        if spared and headline.state != STATE_CLEAN:
            print(f"       + {len(spared)} file(s) are spared by a timestamp predating it")

        for label, status in outcomes.items():
            if label and status.state != STATE_CLEAN:
                if _severity(status.state) > _severity(worst):
                    worst = status.state
                implicated.setdefault(label, status.state)
        if not ref.via and headline.state != STATE_CLEAN:
            worst = max(worst, headline.state, key=_severity)
        print()

    if implicated:
        print(f"{len(implicated)} file(s) depend on a withdrawn or suspect identity:")
        for name in sorted(implicated)[:20]:
            print(f"  {implicated[name]:8s} {name}")
        if len(implicated) > 20:
            print(f"  ... and {len(implicated) - 20} more")
    else:
        print("nothing in this dataset depends on a withdrawn identity.")

    if worst == STATE_CLEAN:
        return EXIT_OK
    print()
    print("A withdrawal removes *evidence*, not necessarily correctness: the data may")
    print("still be right. What is gone is the ability to show where they came from.")
    return EXIT_BAD


# --------------------------------------------------------------------------
# timestamp authority
# --------------------------------------------------------------------------

def _load_tsa(args):
    from .keys import algorithm_of
    from .pki import load_certificates_pem
    from .tsa import ReferenceTSA

    key, _encrypted = load_private_key_for(
        args.tsa_key, env_var=args.password_env, file_path=args.password_file
    )
    certs = load_certificates_pem(pathlib.Path(args.tsa_cert).read_bytes())
    if not certs:
        raise ValueError(f"{args.tsa_cert} holds no certificate")
    algorithm_of(key.public_key())
    from .keys import SoftwareSigner

    return ReferenceTSA(SoftwareSigner(key), certs[0], certs[1:])


def cmd_tsa_init(args) -> int:
    from .keys import ALG_ED25519, generate_private_key, public_key_pem
    from .pki import load_certificates_pem
    from .tsa import make_tsa_certificate

    from cryptography.hazmat.primitives.serialization import Encoding

    ca_key, _ = load_private_key_for(
        args.ca_key, env_var=args.password_env, file_path=args.password_file
    )
    ca_certs = load_certificates_pem(pathlib.Path(args.ca_cert).read_bytes())
    if not ca_certs:
        raise ValueError(f"{args.ca_cert} holds no certificate")

    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    key = generate_private_key(ALG_ED25519)
    cert = make_tsa_certificate(ca_key, ca_certs[0], key.public_key(), args.name, args.org)

    write_private_key(key, out / "tsa.key", None, allow_plaintext=True)
    _write(out / "tsa.pem", cert.public_bytes(Encoding.PEM) + ca_certs[0].public_bytes(Encoding.PEM))
    _write(out / "tsa.pub.pem", public_key_pem(key.public_key()))

    print(f"timestamp authority provisioned in {out}/")
    print(f"  operator:    {args.org}")
    print(f"  certificate: {out / 'tsa.pem'}")
    print("  extended key usage: id-kp-timeStamping only, marked critical")
    print()
    print("Run it for a different organisation than the one that issues detector")
    print("certificates. A timestamp from the same body that signs the data cannot")
    print("survive that body being compromised, which is the case it exists for.")
    return EXIT_OK


def cmd_tsa_stamp(args) -> int:
    """Add a timestamp to frames that are already signed.

    Separate from signing on purpose: a facility can stamp a visit's frames
    after acquisition without holding the detector's key, which is exactly the
    division of labour that makes the facility timestamp *independent*.
    """
    import base64

    from ._canon import canonicalize
    from .api import CorruptSignature, _load_envelope_for
    from .formats import adapter_for
    from .manifest import timestamped_value
    from .timestamp import verify_token

    tsa = _load_tsa(args)
    stamped = failed = 0
    for path in _expand(args.files):
        # One read: the bytes that are inspected are the bytes rewritten, so a
        # file replaced in between cannot end up carrying a token for content
        # it does not have.
        data = path.read_bytes()
        adapter = adapter_for(data)
        try:
            envelope, base, source = _load_envelope_for(path, data, adapter)
        except (CorruptSignature, ValueError) as exc:
            print(f"skipped {path}: {exc}", file=sys.stderr)
            failed += 1
            continue
        if envelope is None:
            print(f"skipped {path}: not signed, so there is no signature to timestamp",
                  file=sys.stderr)
            failed += 1
            continue

        signature = base64.b64decode(envelope["signature"]["value"], validate=True)
        digest = timestamped_value(signature)
        token = tsa.stamp(digest)
        # Check before storing: an unverifiable token in an archive looks like
        # evidence right up until somebody needs it.
        verify_token(token, digest)

        envelope.setdefault("timestamps", []).append(
            base64.b64encode(token).decode("ascii")
        )
        if source == "embedded":
            from .formats.cbf import make_block

            path.write_bytes(base + make_block(canonicalize(envelope)))
        else:
            sidecar = path.with_name(path.name + SIDECAR_SUFFIX)
            sidecar.write_bytes(json.dumps(envelope, indent=2).encode("utf-8") + b"\n")
        stamped += 1
        print(f"timestamped {path}")

    print(f"\n{stamped} timestamped, {failed} skipped")
    return EXIT_OK if stamped and not failed else (EXIT_BAD if failed else EXIT_OK)


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except (OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_BAD
    except RuntimeError as exc:  # TpmError and friends
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_BAD


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
