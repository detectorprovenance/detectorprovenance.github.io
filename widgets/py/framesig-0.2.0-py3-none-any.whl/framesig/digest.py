"""Hashing primitives and the Merkle tree used to bind a frame series.

Everything here is domain-separated: a digest computed for one purpose must
never be reusable as a digest for another purpose.  The prefixes are part of
the wire spec.
"""

from __future__ import annotations

import hashlib
from typing import Iterable, List, Sequence

__all__ = [
    "HASH_NAME",
    "sha256",
    "sha256_hex",
    "hash_stream",
    "merkle_root",
    "merkle_levels",
    "merkle_proof",
    "merkle_verify",
    "DOMAIN_MANIFEST",
    "DOMAIN_MERKLE_LEAF",
    "DOMAIN_MERKLE_NODE",
]

HASH_NAME = "sha256"

#: Prefixed to the canonical manifest bytes before signing.  Prevents a
#: signature over a manifest being replayed as a signature over anything else.
DOMAIN_MANIFEST = b"framesig/1\x00manifest\x00"

#: Merkle domain separation (RFC 6962 style) so that an internal node digest
#: can never be presented as a leaf digest.
DOMAIN_MERKLE_LEAF = b"\x00"
DOMAIN_MERKLE_NODE = b"\x01"


def sha256(*chunks: bytes) -> bytes:
    h = hashlib.sha256()
    for c in chunks:
        h.update(c)
    return h.digest()


def sha256_hex(*chunks: bytes) -> str:
    return sha256(*chunks).hex()


def hash_stream(chunks: Iterable[bytes]) -> str:
    """Hex SHA-256 over an iterable of byte chunks, hashed incrementally."""
    h = hashlib.sha256()
    for c in chunks:
        h.update(c)
    return h.hexdigest()


# --------------------------------------------------------------------------
# Merkle tree over per-frame manifest digests
# --------------------------------------------------------------------------
#
# A detector cannot sign every frame: an ATECC608-class secure element needs
# tens of milliseconds per ECDSA operation, so per-frame signing caps out
# around 10 Hz while detectors run at hundreds to thousands of Hz.  Hashing is
# cheap and pipelineable, signing is not.  So: hash every frame, build a
# Merkle tree over the series, sign the root once.  Each frame then carries a
# log2(N)-sized inclusion proof and is individually verifiable offline.
#
# This also binds *frame identity within the series*: dropping, duplicating or
# reordering frames invalidates the root, which per-frame signatures alone
# would not catch.


def _hash_leaf(leaf: bytes) -> bytes:
    return sha256(DOMAIN_MERKLE_LEAF, leaf)


def _hash_node(left: bytes, right: bytes) -> bytes:
    return sha256(DOMAIN_MERKLE_NODE, left, right)


def _levels(leaves: Sequence[bytes]) -> List[List[bytes]]:
    if not leaves:
        raise ValueError("a Merkle tree needs at least one leaf")
    level = [_hash_leaf(x) for x in leaves]
    levels = [level]
    while len(level) > 1:
        nxt = []
        for i in range(0, len(level) - 1, 2):
            nxt.append(_hash_node(level[i], level[i + 1]))
        if len(level) % 2:
            # Odd node is promoted unchanged rather than duplicated; duplicating
            # is the CVE-2012-2459 footgun that lets two distinct trees share a
            # root.  Promotion is unambiguous because level sizes are implied by
            # the leaf count, which the signed manifest records.
            nxt.append(level[-1])
        levels.append(nxt)
        level = nxt
    return levels


merkle_levels = _levels


def merkle_root(leaves: Sequence[bytes]) -> bytes:
    return _levels(leaves)[-1][0]


def merkle_proof(leaves: Sequence[bytes], index: int, levels=None) -> List[dict]:
    """Inclusion proof for ``leaves[index]`` as a list of ``{side, hash}``.

    Proving every leaf of a run? Pass ``levels=merkle_levels(leaves)``:
    rebuilding the tree per proof makes a 3600-frame run O(N^2).
    """
    if not 0 <= index < len(leaves):
        raise IndexError(index)
    levels = levels or _levels(leaves)
    proof: List[dict] = []
    idx = index
    for level in levels[:-1]:
        if len(level) == 1:
            break
        sibling = idx ^ 1
        if sibling < len(level):
            proof.append(
                {"side": "left" if sibling < idx else "right", "hash": level[sibling].hex()}
            )
            idx //= 2
        else:
            # promoted odd node: no sibling at this level, index halves down
            idx //= 2
    return proof


def merkle_verify(leaf: bytes, index: int, proof: Sequence[dict], root: bytes) -> bool:
    """Check that *leaf* at *index* is included under *root* via *proof*."""
    cur = _hash_leaf(leaf)
    for step in proof:
        sib = bytes.fromhex(step["hash"])
        if step["side"] == "left":
            cur = _hash_node(sib, cur)
        else:
            cur = _hash_node(cur, sib)
    return cur == root
