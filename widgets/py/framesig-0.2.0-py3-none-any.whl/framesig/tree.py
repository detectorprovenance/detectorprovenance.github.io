"""Signing hierarchical containers in place: HDF5 now, Zarr next.

Why this exists
---------------

HDF5 (HyperSpy ``.hspy``, EMD, NeXus) and Zarr (HyperSpy ``.zspy``, quantEM)
are the open containers microscopy data end up in. Neither is
byte-reproducible: any library may repack chunks, reorder metadata or change
compression without changing a single value. So, as for Run-HDF5 (SPEC §7.1),
nothing here signs container bytes. The signature covers the *logical tree*:

* every array's values, through the SPEC §5.2 canonical digest, one payload
  record per array, identified by its path; and
* a *structure document*: every group, array and link, with its path, and for
  arrays the element type and shape, and every attribute value, encoded so
  that no float ever passes through a decimal string.

The signature itself lives in a reserved node at the root, ``framesig``, which
is the one part of the tree the signature does not cover. Everything else is
covered, so content added after signing -- a mask, a changed calibration, a
retargeted link -- is reported rather than shown as signed.

This module holds what any such container shares. ``hdf5_tree.py`` turns an
HDF5 file into a list of :class:`Node` objects; a Zarr binding will reuse the
same model.
"""

from __future__ import annotations

import base64
import hashlib
import struct
from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

from . import manifest as _m
from ._canon import MAX_SAFE_INT, canonicalize

RESERVED = "framesig"
#: Slabs of about this many bytes are hashed at a time, so a large array is
#: never widened in memory all at once.
SLAB_BYTES = 32 * 1024 * 1024


@dataclass
class Node:
    path: str                      # "/" for the root, "/a/b" otherwise
    kind: str                      # "group", "array" or "link"
    attrs: Dict[str, object] = field(default_factory=dict)
    dtype: Optional[object] = None  # numpy dtype, arrays only
    shape: Optional[Tuple[int, ...]] = None
    target: Optional[str] = None    # links only
    slabs: Optional[Callable[[], Iterable[object]]] = None  # arrays: C-order slabs


# --------------------------------------------------------------------------
# attribute values without floats in decimal (SPEC §2 bans floats in JSON)
# --------------------------------------------------------------------------

def _le(np, dtype):
    return dtype.newbyteorder("<") if dtype.byteorder in (">", "=", "|") and dtype.itemsize > 1 else dtype


def encode_value(value):
    """A canonical, float-free JSON encoding of an attribute value.

    ``float`` becomes ``{"$f64": <IEEE-754 bits, big-endian hex>}``; a numeric
    numpy array or scalar becomes ``{"$array": {dtype, shape, data}}`` with the
    values little-endian in C order; bytes become ``{"$bytes": base64}``.
    Integers outside the JSON-safe range become ``{"$int": "<decimal>"}``.
    """
    import numpy as np

    if value is None or isinstance(value, (bool, str)):
        return value
    if isinstance(value, int):
        return value if abs(value) <= MAX_SAFE_INT else {"$int": str(value)}
    if isinstance(value, float):
        return {"$f64": struct.pack(">d", value).hex()}
    if isinstance(value, (bytes, bytearray)):
        return {"$bytes": base64.b64encode(bytes(value)).decode("ascii")}
    if isinstance(value, dict):
        return {str(k): encode_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode_value(v) for v in value]
    if isinstance(value, (np.ndarray, np.generic)):
        arr = np.asarray(value)
        if arr.dtype.kind in "biufc":
            le = arr.astype(_le(np, arr.dtype), copy=False)
            return {"$array": {"dtype": le.dtype.str, "shape": list(arr.shape),
                               "data": base64.b64encode(np.ascontiguousarray(le).tobytes()).decode("ascii")}}
        if arr.dtype.kind in "US":
            return {"$strings": {"shape": list(arr.shape),
                                 "values": [encode_value(v.item() if hasattr(v, "item") else v)
                                            for v in arr.reshape(-1)]}}
        if arr.dtype.kind == "O":
            return {"$objects": {"shape": list(arr.shape),
                                 "values": [encode_value(v) for v in arr.reshape(-1)]}}
    # Anything else (an HDF5 object reference, an empty dataspace) is recorded
    # by type, deterministically, rather than silently dropped.
    return {"$unsupported": type(value).__name__}


# --------------------------------------------------------------------------
# array values (SPEC §5.2)
# --------------------------------------------------------------------------

def canonical_form(dtype) -> str:
    kind, size = dtype.kind, dtype.itemsize
    if kind in "bi" or (kind == "u" and size < 8):
        return "int64-le"
    if kind == "u":
        return "uint64-le"
    if kind == "f":
        if size <= 4:
            return "ieee754-32-le"
        if size == 8:
            return "ieee754-64-le"
    if kind == "c" and size in (8, 16):
        return f"complex{size * 8}-le"
    if kind in "USO":
        return "strings"
    return "native-le"


_TARGET = {"int64-le": "<i8", "uint64-le": "<u8", "ieee754-32-le": "<f4", "ieee754-64-le": "<f8",
           "complex64-le": "<c8", "complex128-le": "<c16"}


def _string_bytes(v) -> bytes:
    if isinstance(v, bytes):
        return v
    if hasattr(v, "item"):
        v = v.item()
    return v if isinstance(v, bytes) else str(v).encode("utf-8")


def array_digest(dtype, slabs: Iterable[object]) -> Tuple[str, str]:
    """``(canonical_form, "sha256:...")`` over an array's values in C order.

    ``strings``: each element as UTF-8 (or raw bytes), preceded by its length
    as an 8-byte little-endian integer. ``native-le``: the stored bytes with
    every field little-endian, for compound and other types.
    """
    import numpy as np

    form = canonical_form(dtype)
    h = hashlib.sha256()
    for slab in slabs:
        slab = np.asarray(slab)
        if form in _TARGET:
            # casting="safe": a value that does not fit fails, it is never wrapped.
            h.update(np.ascontiguousarray(slab.astype(_TARGET[form], casting="safe")).tobytes())
        elif form == "strings":
            for v in slab.reshape(-1):
                b = _string_bytes(v)
                h.update(struct.pack("<Q", len(b)))
                h.update(b)
        else:
            h.update(np.ascontiguousarray(slab.astype(_le(np, slab.dtype))).tobytes())
    return form, "sha256:" + h.hexdigest()


def slabs_of(np, getitem, shape, itemsize) -> Iterator[object]:
    """C-order slabs along the first axis from an indexable array."""
    if len(shape) == 0:
        yield np.asarray(getitem(())).reshape(1)
        return
    if shape[0] == 0:
        return
    row = max(1, int(np.prod(shape[1:], dtype=np.int64)) * max(itemsize, 8))
    step = max(1, SLAB_BYTES // row)
    for i in range(0, shape[0], step):
        yield getitem(slice(i, i + step))


def dtype_name(dtype) -> str:
    """The element type recorded in the structure document and the manifest."""
    if dtype.kind in "US":
        return "string" if dtype.kind == "U" else "bytes"
    if dtype.kind == "O":
        return "object"
    if dtype.itemsize > 1 and dtype.byteorder != "|":
        return dtype.newbyteorder("<").str
    return dtype.str


# --------------------------------------------------------------------------
# the structure document and the manifest
# --------------------------------------------------------------------------

def structure_document(nodes: Sequence[Node]) -> bytes:
    """Canonical JSON (SPEC §2) of every node except array values."""
    out = []
    for n in sorted(nodes, key=lambda n: n.path.encode("utf-8")):
        entry = {"path": n.path, "kind": n.kind,
                 "attrs": {str(k): encode_value(v) for k, v in n.attrs.items()}}
        if n.kind == "array":
            entry["dtype"] = dtype_name(n.dtype)
            entry["shape"] = [int(s) for s in n.shape]
        if n.kind == "link":
            entry["target"] = n.target
        out.append(entry)
    return canonicalize({"nodes": out})


def payload_records(nodes: Sequence[Node]) -> List[dict]:
    recs = []
    for n in sorted((n for n in nodes if n.kind == "array"), key=lambda n: n.path.encode("utf-8")):
        form, digest = array_digest(n.dtype, n.slabs())
        recs.append({"id": n.path, "element_type": dtype_name(n.dtype),
                     "dimensions": [int(s) for s in n.shape],
                     "canonical_form": form, "canonical": digest})
    return recs


def build_manifest(profile: str, nodes: Sequence[Node], signer_info: dict, *,
                   claims=None, attestation=None) -> Tuple[bytes, bytes]:
    """``(manifest_bytes, structure_bytes)`` for a tree."""
    structure = structure_document(nodes)
    manifest = {
        "spec": _m.SPEC,
        "profile": profile,
        "created": _m.utc_now(),
        "digests": {"structure": "sha256:" + hashlib.sha256(structure).hexdigest()},
        "payloads": payload_records(nodes),
        "signer": signer_info,
        "software": _m.software(),
    }
    if attestation:
        manifest["attestation"] = attestation
    if claims:
        manifest["claims"] = claims
    return canonicalize(manifest), structure


def signer_info_for(signer, certificates_der: Sequence[bytes]) -> dict:
    info = {"key_id": signer.key_id, "alg": signer.algorithm}
    if certificates_der:
        from cryptography import x509

        from .pki import subject_string

        info["subject"] = subject_string(x509.load_der_x509_certificate(certificates_der[0]))
    return info


def sign_tree(profile: str, nodes: Sequence[Node], signer, *, certificates_der=(), claims=None,
              attestation=None) -> Tuple[dict, bytes]:
    """``(envelope, structure_bytes)`` for a tree, signed once."""
    from .keys import public_key_bytes, sign_and_verify

    manifest_bytes, structure = build_manifest(
        profile, nodes, signer_info_for(signer, certificates_der),
        claims=claims, attestation=attestation)
    signature = sign_and_verify(signer, _m.signing_input(manifest_bytes))
    envelope = _m.encode_envelope(manifest_bytes, signature, signer.algorithm,
                                  certificates=list(certificates_der),
                                  public_key_der=public_key_bytes(signer.public_key))
    return envelope, structure


# --------------------------------------------------------------------------
# verification
# --------------------------------------------------------------------------

def _structure_changes(signed: bytes, now: bytes, limit: int = 8) -> List[str]:
    """Which nodes differ between the signed and the current structure."""
    import json

    def index(doc):
        return {n["path"]: n for n in json.loads(doc)["nodes"]}

    a, b = index(signed), index(now)
    out = []
    for path in sorted(set(a) | set(b)):
        if path not in b:
            out.append(f"{path} was removed")
        elif path not in a:
            out.append(f"{path} was added")
        elif a[path] != b[path]:
            changed = sorted(k for k in set(a[path]["attrs"]) | set(b[path]["attrs"])
                             if a[path]["attrs"].get(k) != b[path]["attrs"].get(k))
            what = f"attributes {changed}" if changed else "its type, shape or target"
            out.append(f"{path}: {what} changed")
        if len(out) >= limit:
            out.append("...")
            break
    return out


def verify_tree(profile: str, nodes: Sequence[Node], envelope: dict, stored_structure: Optional[bytes],
                result, *, roots=(), public_keys=(), at_time=None, timestamp_roots=()):
    """Fill *result* (an ``api.VerificationResult``) for a walked tree."""
    from .api import _assess_timestamps, _assess_trust, _authenticate_single
    from .attestation import assess_assurance

    manifest_bytes, certs, signing_key = _authenticate_single(envelope, list(public_keys), result)
    manifest = None
    try:
        manifest = json_loads(manifest_bytes)
        result.manifest = manifest
        if not result.signature_valid:
            result.status = "invalid"
            return
        if manifest.get("spec") != _m.SPEC or manifest.get("profile") != profile:
            result.status = "invalid"
            result.problems.append(f"manifest is not a {profile} manifest")
            return
        _compare(nodes, manifest, stored_structure, result)
    finally:
        result.trust_status, result.trust = _assess_trust(certs, roots, signing_key, manifest or {},
                                                         at_time, result)
        result.assurance = assess_assurance(signature_valid=result.signature_valid,
                                            trust_status=result.trust_status,
                                            certificates=certs, manifest=manifest)
        result.time = _assess_timestamps(envelope, certs, timestamp_roots)


def json_loads(b: bytes):
    import json

    return json.loads(b.decode("utf-8"))


def _compare(nodes, manifest, stored_structure, result):
    problems = result.problems
    signed = {p["id"]: p for p in manifest.get("payloads", [])}
    arrays = {n.path: n for n in nodes if n.kind == "array"}
    values_ok = True
    for path in sorted(set(signed) - set(arrays)):
        problems.append(f"signed array {path} is missing")
        values_ok = False
    for path in sorted(set(arrays) - set(signed)):
        problems.append(f"array {path} is not covered by the signature")
        values_ok = False
    reports = []
    for path in sorted(set(signed) & set(arrays)):
        n, p = arrays[path], signed[path]
        if [int(s) for s in n.shape] != p.get("dimensions") or dtype_name(n.dtype) != p.get("element_type"):
            problems.append(f"{path} is {dtype_name(n.dtype)} {list(n.shape)}, signed as "
                            f"{p.get('element_type')} {p.get('dimensions')}")
            ok = False
        else:
            # Shape and type are the signed ones, so every read is bounded by signed numbers.
            ok = array_digest(n.dtype, n.slabs()) == (p.get("canonical_form"), p.get("canonical"))
            if not ok:
                problems.append(f"{path}: values differ from the signed values")
        values_ok &= ok
        reports.append({"id": path, "canonical_ok": ok})
    result.payload_reports = reports

    structure = structure_document(nodes)
    signed_digest = manifest.get("digests", {}).get("structure")
    structure_ok = "sha256:" + hashlib.sha256(structure).hexdigest() == signed_digest
    result.skeleton_intact = structure_ok
    if not structure_ok:
        if stored_structure and "sha256:" + hashlib.sha256(stored_structure).hexdigest() == signed_digest:
            problems.extend(_structure_changes(stored_structure, structure))
        else:
            problems.append("groups, attributes or links differ from the signed structure")
    if not values_ok:
        result.status = "tampered"
    elif not structure_ok:
        result.status = "metadata-modified"
    else:
        result.status = "valid"
