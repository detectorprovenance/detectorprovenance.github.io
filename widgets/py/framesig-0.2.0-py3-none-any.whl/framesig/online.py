"""Fetch withdrawal lists from where the issuing CA says it publishes them.

Opt-in only. Nothing here runs unless a caller asks for it (``--online``);
without it, verification stays offline, which is what keeps an archive
checkable on an air-gapped machine decades from now.

What the network is trusted for: **nothing**. It is a delivery channel.

* The address comes from the CRL Distribution Points extension of a
  certificate in the file -- signed by that certificate's issuer -- never from
  the unsigned envelope, so a forger cannot point the verifier at a server of
  their choosing.
* A list counts only if it verifies under the key of the CA that issued the
  certificate naming it, and that CA must itself chain to a root the caller
  supplied. TLS proves nothing here; plain HTTP is as good as HTTPS.
* A list that cannot be fetched is *not consulted*, never clean: every
  identity then comes out suspect.
* Lists are static files (no per-check query as in OCSP), so the server
  learns that somebody checks *some* certificate of that CA, not which data.

Verified lists are cached and reused until their own ``next_update``; the
network is not contacted while a cached copy is current. A fetch that fails
falls back to the cached copy and says so; a server that hands back a list
*older* than the cached one is ignored as a replay.
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import pathlib
from typing import List, Optional, Sequence, Tuple

from .revocation import RevocationSet, RevocationSets, parse_time, verify_revocation_list

__all__ = ["default_cache_dir", "certificates_of", "crl_targets", "fetch_revocations", "consult"]

MAX_LIST = 16 * 1024 * 1024
_EPOCH = _dt.datetime(1970, 1, 1, tzinfo=_dt.timezone.utc)


def default_cache_dir() -> pathlib.Path:
    base = os.environ.get("FRAMESIG_CACHE") or pathlib.Path.home() / ".cache" / "framesig"
    return pathlib.Path(base) / "revocations"


def certificates_of(envelope) -> list:
    """The certificates an envelope carries; unreadable ones are skipped."""
    import base64

    from cryptography import x509

    from .manifest import signing_envelope

    out = []
    # A series-signed frame carries its signer's chain in the series envelope;
    # without looking there, --online found no distribution point to fetch.
    envelope = signing_envelope(envelope) if isinstance(envelope, dict) else envelope
    encoded = envelope.get("certificates") if isinstance(envelope, dict) else None
    for item in (encoded if isinstance(encoded, list) else [])[:8]:
        try:
            out.append(x509.load_der_x509_certificate(base64.b64decode(item, validate=True)))
        except Exception:  # noqa: BLE001 - hostile input is data, not a crash
            continue
    return out


def crl_targets(certs: Sequence[object], roots: Sequence[object]
                ) -> List[Tuple[str, Optional[object], Optional[str]]]:
    """``(url, issuer public key, problem)`` for every distribution point.

    The issuer key is None (and *problem* says why) unless the issuing CA
    chains to *roots* -- a key the file vouches for itself would let a forged
    chain authenticate its own forged list.
    """
    from .pki import _cert_signature_ok, certificate_der, crl_urls, subject_string, verify_chain

    certs = list({certificate_der(c): c for c in certs}.values())  # a dataset repeats them
    pool = certs + list(roots)
    out, seen = [], set()
    for cert in certs:
        urls = [u for u in crl_urls(cert) if u not in seen]
        seen.update(urls)
        if not urls:
            continue
        # Several certificates can hold the issuer's key (a renewed or
        # cross-certified CA); any one that chains authenticates the list.
        issuers = [c for c in pool if c.subject == cert.issuer and _cert_signature_ok(cert, c)]
        key, problem = None, None
        if not issuers:
            problem = f"the issuer of {subject_string(cert)!r} is not in the file or the roots"
        for issuer in issuers:
            # The list is signed with the CA's key, so that key must be allowed
            # to sign revocation information (keyUsage cRLSign), not only to
            # issue certificates.
            chain = verify_chain(issuer, certs, roots, leaf_usage=("crl_sign",))
            if chain.ok:
                key, problem = issuer.public_key(), None
                break
            problem = (f"the issuer of {subject_string(cert)!r} does not chain to a "
                       f"trusted root ({chain.reason}), so its list cannot be authenticated")
        out.extend((url, key, problem) for url in urls)
    return out


def _get(url: str, timeout: float) -> bytes:
    import urllib.request

    if not url.lower().startswith(("http://", "https://")):
        raise ValueError(f"not an HTTP(S) URL: {url!r}")
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as response:  # noqa: S310 - scheme checked
        data = response.read(MAX_LIST + 1)
    if len(data) > MAX_LIST:
        raise ValueError(f"larger than {MAX_LIST} bytes")
    return data


def _verify(data: bytes, issuer_key, url: str) -> RevocationSet:
    try:
        envelope = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        rs = RevocationSet(source=url)
        rs.problems.append(f"not a JSON document: {exc}")
        return rs
    return verify_revocation_list(envelope, public_keys=[issuer_key], source=url)


def fetch_revocations(url: str, issuer_key, *, cache_dir=None,
                      timeout: float = 15.0) -> RevocationSet:
    """The list at *url*, verified under *issuer_key*, via the cache."""
    path = pathlib.Path(cache_dir or default_cache_dir()) / (
        hashlib.sha256(url.encode("utf-8")).hexdigest() + ".json")
    cached = None
    try:
        if path.is_file() and path.stat().st_size <= MAX_LIST:
            cached = _verify(path.read_bytes(), issuer_key, url)
            if not cached.signature_valid:
                cached = None  # a damaged or planted cache file is just a miss
    except OSError:
        cached = None
    if cached is not None and parse_time(cached.next_update) and not cached.is_stale():
        return cached

    try:
        data = _get(url, timeout)
    except Exception as exc:  # noqa: BLE001 - any network failure means "not obtained"
        if cached is not None:
            cached.problems.append(f"could not refresh ({type(exc).__name__}: {exc}); "
                                   "using the cached copy")
            return cached
        rs = RevocationSet(consulted=False, source=url)
        rs.problems.append(f"could not be fetched ({type(exc).__name__}: {exc})")
        return rs

    fresh = _verify(data, issuer_key, url)
    if not fresh.signature_valid:
        return fresh  # kept as an unverified report: its silence counts for nothing
    if cached is not None and (parse_time(fresh.this_update) or _EPOCH) < (
            parse_time(cached.this_update) or _EPOCH):
        cached.problems.append(f"the server returned an older list (dated {fresh.this_update}) "
                               "than the cached one; ignored as a possible replay")
        return cached
    try:
        from ._fs import atomic_write

        path.parent.mkdir(parents=True, exist_ok=True)
        atomic_write(path, data)
    except OSError as exc:
        fresh.problems.append(f"could not cache the list: {exc}")
    return fresh


def consult(certs: Sequence[object], roots: Sequence[object], *, cache_dir=None,
            timeout: float = 15.0) -> RevocationSets:
    """Fetch every list the certificate chain points at."""
    sets = []
    for url, key, problem in crl_targets(certs, roots):
        if key is None:
            sets.append(RevocationSet(consulted=False, source=url, problems=[problem]))
        else:
            sets.append(fetch_revocations(url, key, cache_dir=cache_dir, timeout=timeout))
    if not sets:
        sets.append(RevocationSet(consulted=False, problems=[
            "no certificate in the file names a distribution point, so there is "
            "nowhere to ask whether its key was withdrawn"]))
    return RevocationSets(sets)

