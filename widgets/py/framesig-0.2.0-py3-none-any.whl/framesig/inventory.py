"""The signer inventory: every key and certificate a dataset depends on.

Why this exists
---------------

A derived file that names its parent bundle by digest cannot answer the question
*who signed the raw data* without the raw data in hand. For a 200 GB deposition
held at a repository, that is the same as not being able to answer it at all --
and it is exactly the question that matters after a key is withdrawn.

So a derived object carries an **inventory**: the transitive set of signing
identities everything upstream depends on. A revocation list can then be
intersected with the inventory offline, on a laptop, years later, with no access
to the frames and no network.

Leaf-only is the mistake that matters
-------------------------------------

The inventory records **every certificate in every chain, up to and including the
roots** -- not just the detector's own key. Vendor CAs get compromised;
DigiNotar is the canonical case. A derived file that recorded only the leaf key
fingerprint would show nothing at all when the root that vouched for it was
withdrawn, which is precisely the situation the inventory exists for.

Two identities, both needed
---------------------------

A revocation may name a **key** or a **certificate**, and the two are not
interchangeable: a key can be re-certified, and revoking a certificate does not
revoke the key it contains. So each entry carries both -- the SPKI fingerprint
(``key_id``, already what :func:`framesig.keys.key_id` computes) and the
certificate's own digest, issuer and serial.

What is *not* in the canonical record
-------------------------------------

:attr:`SignerRef.via` -- which frame or bundle an identity was observed through
-- is deliberately excluded from :func:`record_of`. It is local observation
context: two people inventorying the same dataset from different directories
would disagree about it, and the inventory has to be byte-identical between them
for recompute-and-compare to work. ``via`` is kept on the runtime object because
it is what makes an audit able to say *which part* of a collection depends on a
withdrawn key.
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from typing import Iterable, List, Optional, Sequence, Tuple

from cryptography import x509

from ._canon import canonicalize
from .digest import sha256
from .keys import algorithm_of, key_id, public_key_bytes

__all__ = [
    "INVENTORY_SPEC",
    "ROLE_LEAF",
    "ROLE_INTERMEDIATE",
    "ROLE_ROOT",
    "ROLE_BARE_KEY",
    "MAX_CERTIFICATES",
    "SignerRef",
    "InventoryError",
    "ref_from_certificate",
    "ref_from_public_key",
    "inventory_from_envelope",
    "merge",
    "record_of",
    "records_of",
    "inventory_digest",
    "compare",
]

INVENTORY_SPEC = "framesig-inventory/1"

ROLE_LEAF = "leaf"
ROLE_INTERMEDIATE = "intermediate"
ROLE_ROOT = "root"
ROLE_BARE_KEY = "bare-key"

#: An envelope is attacker-controlled. `pki.verify_chain` already caps chain
#: walking at depth 8; this caps what we will even parse, so a file carrying ten
#: thousand certificates costs nothing.
MAX_CERTIFICATES = 16


class InventoryError(ValueError):
    """An inventory record is malformed, or two inventories disagree."""


def _der(cert: x509.Certificate) -> bytes:
    from cryptography.hazmat.primitives.serialization import Encoding

    return cert.public_bytes(Encoding.DER)


def _fmt(when: Optional[_dt.datetime]) -> Optional[str]:
    if when is None:
        return None
    if when.tzinfo is None:
        when = when.replace(tzinfo=_dt.timezone.utc)
    return when.astimezone(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _not_before(cert: x509.Certificate) -> _dt.datetime:
    try:
        return cert.not_valid_before_utc
    except AttributeError:  # cryptography < 42
        return cert.not_valid_before.replace(tzinfo=_dt.timezone.utc)


def _not_after(cert: x509.Certificate) -> _dt.datetime:
    try:
        return cert.not_valid_after_utc
    except AttributeError:  # cryptography < 42
        return cert.not_valid_after.replace(tzinfo=_dt.timezone.utc)


@dataclass
class SignerRef:
    """One identity a revocation could name.

    ``key_id`` is always present. The certificate fields are present whenever the
    identity was observed as a certificate rather than a bare key.
    """

    key_id: str
    alg: Optional[str] = None
    role: str = ROLE_BARE_KEY
    #: ``sha256:`` over the certificate DER. The identity a revocation naming a
    #: certificate rather than a key will match on.
    cert: Optional[str] = None
    subject: Optional[str] = None
    issuer: Optional[str] = None
    #: Lowercase hex, **never an integer**: X.509 serials run to 20 octets, far
    #: outside the JSON-safe integer range the canonical encoder permits.
    serial: Optional[str] = None
    not_before: Optional[str] = None
    not_after: Optional[str] = None
    #: Local observation context; excluded from the canonical record. See the
    #: module docstring.
    via: List[str] = field(default_factory=list)

    @property
    def identity(self) -> Tuple[str, Optional[str]]:
        """Deduplication key: the same key under two certificates is two rows.

        Keyed on both because a re-certified key is a genuinely different thing
        to revoke -- withdrawing one certificate must not silently withdraw
        signatures made under another.
        """
        return (self.key_id, self.cert)

    def label(self) -> str:
        if self.subject:
            return f"{self.subject} [{self.role}]"
        return f"{self.key_id} [{self.role}]"


def ref_from_certificate(cert: x509.Certificate, role: str = ROLE_LEAF,
                         via: Optional[str] = None) -> SignerRef:
    public_key = cert.public_key()
    try:
        alg = algorithm_of(public_key)
    except Exception:  # noqa: BLE001 - an unsupported key still has an identity
        alg = None
    return SignerRef(
        key_id=key_id(public_key),
        alg=alg,
        role=role,
        cert="sha256:" + sha256(_der(cert)).hex(),
        subject=cert.subject.rfc4514_string(),
        issuer=cert.issuer.rfc4514_string(),
        serial=format(cert.serial_number, "x"),
        not_before=_fmt(_not_before(cert)),
        not_after=_fmt(_not_after(cert)),
        via=[via] if via else [],
    )


def ref_from_public_key(public_key, role: str = ROLE_BARE_KEY,
                        via: Optional[str] = None) -> SignerRef:
    try:
        alg = algorithm_of(public_key)
    except Exception:  # noqa: BLE001
        alg = None
    return SignerRef(key_id=key_id(public_key), alg=alg, role=role,
                     via=[via] if via else [])


def inventory_from_certificates(certs: Sequence[x509.Certificate],
                                via: Optional[str] = None) -> List[SignerRef]:
    """Chains travel leaf-first.

    An envelope carries leaf + intermediates; the root normally lives in the
    verifier's trust store rather than in the file, so a trailing certificate is
    labelled ``intermediate`` unless it is self-issued -- the only reliable
    in-band signal that a certificate is a root.
    """
    refs: List[SignerRef] = []
    for i, cert in enumerate(certs[:MAX_CERTIFICATES]):
        if cert.issuer == cert.subject:
            role = ROLE_ROOT
        elif i == 0:
            role = ROLE_LEAF
        else:
            role = ROLE_INTERMEDIATE
        refs.append(ref_from_certificate(cert, role, via))
    return refs


def inventory_from_envelope(envelope: dict, via: Optional[str] = None) -> List[SignerRef]:
    """Observe the identities an envelope depends on.

    This is *observation*, not verification: it deliberately does not check the
    signature, because an audit has to be able to enumerate the signers of a
    file whose signature has stopped verifying. Malformed input yields fewer
    rows, never an exception -- the caller is auditing a hostile file.
    """
    import base64

    refs: List[SignerRef] = []
    if not isinstance(envelope, dict):
        return refs

    # A frame signed as part of a series has no signer of its own: it depends
    # on whoever signed the run. Missing that made every batch-signed frame
    # invisible to an audit -- the case a withdrawn key most needs to reach.
    from .manifest import signing_envelope

    envelope = signing_envelope(envelope)

    encoded = envelope.get("certificates")
    if isinstance(encoded, list):
        certs: List[x509.Certificate] = []
        for item in encoded[:MAX_CERTIFICATES]:
            if not isinstance(item, str):
                continue
            try:
                certs.append(x509.load_der_x509_certificate(base64.b64decode(item, validate=True)))
            except Exception:  # noqa: BLE001 - an unreadable certificate is data, not a crash
                continue
        refs.extend(inventory_from_certificates(certs, via))

    if not refs:
        bare = envelope.get("public_key")
        if isinstance(bare, str):
            from cryptography.hazmat.primitives.serialization import load_der_public_key

            try:
                key = load_der_public_key(base64.b64decode(bare, validate=True))
                refs.append(ref_from_public_key(key, ROLE_BARE_KEY, via))
            except Exception:  # noqa: BLE001
                pass
    return refs


def merge(*inventories: Iterable[SignerRef]) -> List[SignerRef]:
    """Combine inventories, deduplicating by identity and unioning ``via``.

    Sorted, so the result depends on the *set* of identities and not on the
    order files happened to be read in -- the same reason
    ``bundle._members_root`` sorts.
    """
    seen: dict = {}
    for inventory in inventories:
        for ref in inventory:
            existing = seen.get(ref.identity)
            if existing is None:
                seen[ref.identity] = SignerRef(**{**ref.__dict__, "via": list(ref.via)})
                continue
            for v in ref.via:
                if v not in existing.via:
                    existing.via.append(v)
            # A leaf seen elsewhere as an intermediate is an intermediate: the
            # stronger statement about position wins, because it is what decides
            # how far a CA compromise reaches.
            if existing.role == ROLE_LEAF and ref.role in (ROLE_INTERMEDIATE, ROLE_ROOT):
                existing.role = ref.role
    out = list(seen.values())
    for ref in out:
        ref.via.sort()
    out.sort(key=lambda r: (r.key_id, r.cert or ""))
    return out


def record_of(ref: SignerRef) -> dict:
    """The canonical, signable record for one identity.

    ``via`` is excluded on purpose -- see the module docstring.
    """
    rec = {"key_id": ref.key_id, "role": ref.role}
    for name in ("alg", "cert", "subject", "issuer", "serial", "not_before", "not_after"):
        value = getattr(ref, name)
        if value:
            rec[name] = value
    return rec


def records_of(refs: Sequence[SignerRef]) -> List[dict]:
    return [record_of(r) for r in merge(refs)]


def inventory_digest(records: Sequence[dict]) -> str:
    """Digest over the canonical inventory, for binding it into a manifest."""
    return "sha256:" + sha256(canonicalize(list(records))).hex()


def compare(declared: Sequence[dict], observed: Sequence[SignerRef]) -> List[str]:
    """Complaints if a declared inventory does not match what was observed.

    **This is the check that stops the inventory being a free-form claim.** If a
    signing step may choose which upstream signers to list, a forger simply omits
    the compromised one; the inventory then looks clean for exactly the reason it
    should look alarming.

    Omissions and additions are reported separately because they mean different
    things: an omission hides a dependency, an addition means the file depends on
    something the declaration did not admit to.
    """
    want = {(r.get("key_id"), r.get("cert")) for r in declared}
    have = {r.identity for r in observed}
    problems: List[str] = []
    for ref in sorted(observed, key=lambda r: r.key_id):
        if ref.identity not in want:
            problems.append(
                f"the inventory does not declare {ref.label()}, which the data actually depends on"
            )
    by_identity = {r.identity: r for r in observed}
    for rec in declared:
        ident = (rec.get("key_id"), rec.get("cert"))
        if ident not in have:
            problems.append(
                f"the inventory declares {rec.get('subject') or rec.get('key_id')}, "
                "which was not found in the data"
            )
        else:
            ref = by_identity[ident]
            for name in ("subject", "issuer", "serial", "not_before", "not_after"):
                declared_value = rec.get(name)
                actual = getattr(ref, name)
                if declared_value and actual and declared_value != actual:
                    problems.append(
                        f"{ref.label()}: inventory says {name}={declared_value!r} "
                        f"but the certificate says {actual!r}"
                    )
    return problems
