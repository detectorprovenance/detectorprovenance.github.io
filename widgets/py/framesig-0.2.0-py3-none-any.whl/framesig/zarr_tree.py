"""Sign a Zarr store in place, and verify one (SPEC §7.2, profile ``zarr/1``).

Covers HyperSpy ``.zspy`` and quantEM files, as a directory or as a ``.zip``
of one, in Zarr format 2 or 3. Like HDF5 (``hdf5_tree.py``) the signature
covers the logical tree (``tree.py``): every array's values and a structure
document of every group, array and attribute, plus any consolidated metadata
(``.zmetadata``, or ``consolidated_metadata`` in a format 3 ``zarr.json``),
which is a second copy that readers act on.

The signature is stored as the ``framesig`` attribute of the root group, which
is the one attribute the signature does not cover. A child group would be the
analogue of HDF5's /framesig, but loaders that rebuild objects from a group's
children (quantEM's does) would then meet a member they never wrote.

This module reads Zarr itself instead of through the zarr package: chunks are
decoded with numcodecs alone, so the same code runs in a browser (Pyodide),
where zarr 3 cannot. Supported: regular chunk grids; format 3 codecs
``bytes``, ``transpose``, ``blosc``, ``zstd``, ``gzip``, ``crc32c``; format 2
compressors and filters from numcodecs, except ``pickle``, which would run
code from the file. Sharded arrays are refused with a clear message.

numpy and numcodecs are optional dependencies (``pip install framesig[zarr]``).
"""

from __future__ import annotations

import base64
import io
import json
import os
import pathlib
import posixpath
import zipfile
from typing import Dict, List, Optional, Sequence, Tuple

from .tree import RESERVED, Node, sign_tree, slabs_of, verify_tree

__all__ = ["ZARR_SPEC", "PROFILE", "sign_zarr", "verify_zarr", "is_zarr", "is_signed_zarr"]

ZARR_SPEC = "framesig-zarr/1"
PROFILE = "zarr/1"
_V2_META = (".zgroup", ".zarray", ".zattrs")
_UNSAFE_CODECS = {"pickle"}


class ZarrError(ValueError):
    """The store cannot be read safely as Zarr."""


# --------------------------------------------------------------------------
# stores: a directory, or a zip of one
# --------------------------------------------------------------------------

class _Store:
    """Read-only key -> bytes view of a Zarr store."""

    def __init__(self, path):
        self.path = pathlib.Path(path)
        self.zip = None
        if self.path.is_dir():
            self.keys = sorted(
                str(p.relative_to(self.path)).replace(os.sep, "/")
                for p in self.path.rglob("*") if p.is_file())
        else:
            self.zip = zipfile.ZipFile(self.path)
            self.keys = sorted(n for n in self.zip.namelist() if not n.endswith("/"))
        self.prefix = _common_root(self.keys)
        self._set = set(self.keys)

    def get(self, key: str) -> Optional[bytes]:
        key = self.prefix + key
        if key not in self._set:
            return None
        if self.zip is not None:
            return self.zip.read(key)
        return (self.path / key).read_bytes()

    def logical_keys(self) -> List[str]:
        return [k[len(self.prefix):] for k in self.keys]

    def close(self):
        if self.zip is not None:
            self.zip.close()


def _common_root(keys: Sequence[str]) -> str:
    """A zip often holds the store inside one top-level directory."""
    for meta in ("zarr.json", ".zgroup", ".zarray"):
        if meta in keys:
            return ""
    roots = sorted({k.split("/", 1)[0] for k in keys if "/" in k})
    if len(roots) == 1 and any(k == f"{roots[0]}/{m}" for k in keys for m in ("zarr.json", ".zgroup", ".zarray")):
        return roots[0] + "/"
    return ""


def is_zarr(path) -> bool:
    """A directory or zip holding a Zarr store (format 2 or 3) at its root."""
    try:
        p = pathlib.Path(path)
        if not (p.is_dir() or zipfile.is_zipfile(p)):
            return False
        s = _Store(p)
        try:
            keys = s.logical_keys()
            return any(k in keys for k in ("zarr.json", ".zgroup", ".zarray"))
        finally:
            s.close()
    except (OSError, zipfile.BadZipFile):
        return False


# --------------------------------------------------------------------------
# metadata
# --------------------------------------------------------------------------

def _json(store, key) -> Optional[dict]:
    raw = store.get(key)
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except (ValueError, UnicodeDecodeError) as exc:
        raise ZarrError(f"{key} is not valid JSON: {exc}") from exc


def _node_paths(keys: Sequence[str], version: int) -> List[str]:
    names = ("zarr.json",) if version == 3 else _V2_META
    dirs = {posixpath.dirname(k) for k in keys if posixpath.basename(k) in names}
    return sorted(dirs)


def _root_meta(store) -> Tuple[int, dict, str]:
    """``(format, root metadata document, key it lives in)``."""
    doc = _json(store, "zarr.json")
    if doc is not None:
        return 3, doc, "zarr.json"
    if store.get(".zgroup") is not None or store.get(".zarray") is not None:
        return 2, _json(store, ".zattrs") or {}, ".zattrs"
    raise ZarrError("no zarr.json, .zgroup or .zarray at the root of the store")


# --------------------------------------------------------------------------
# chunks
# --------------------------------------------------------------------------

def _v3_dtype(np, name, endian="little"):
    if not isinstance(name, str):
        raise ZarrError(f"unsupported data type {name!r}")
    if name == "bool":
        return np.dtype("?")
    try:
        dt = np.dtype(name)
    except TypeError as exc:
        raise ZarrError(f"unsupported data type {name!r}") from exc
    if dt.kind not in "biufc":
        raise ZarrError(f"unsupported data type {name!r}")
    return dt.newbyteorder("<" if endian == "little" else ">") if dt.itemsize > 1 else dt


def _fill(np, dtype, value):
    if value is None:
        return 0
    if isinstance(value, str) and dtype.kind in "fc":
        return {"NaN": np.nan, "Infinity": np.inf, "-Infinity": -np.inf}.get(value, 0)
    if isinstance(value, str) and value.startswith("0x") and dtype.kind == "f":
        return np.frombuffer(bytes.fromhex(value[2:]), dtype=dtype.newbyteorder(">"))[0]
    return value


class _Array:
    """Decodes one Zarr array, chunk by chunk, into C-order numpy slabs."""

    def __init__(self, np, store, path, meta, version):
        self.np, self.store, self.path, self.version = np, store, path, version
        self.shape = tuple(int(n) for n in meta["shape"])
        if version == 3:
            grid = meta.get("chunk_grid", {})
            if grid.get("name") != "regular":
                raise ZarrError(f"{path}: chunk grid {grid.get('name')!r} is not supported")
            self.chunks = tuple(int(n) for n in grid["configuration"]["chunk_shape"])
            enc = meta.get("chunk_key_encoding", {"name": "default"})
            sep = enc.get("configuration", {}).get("separator", "/" if enc.get("name") == "default" else ".")
            self.key = (lambda idx: "c" + "".join(sep + str(i) for i in idx) if idx else "c") \
                if enc.get("name") == "default" else (lambda idx: sep.join(map(str, idx)) or "0")
            self.codecs = meta.get("codecs", [])
            endian = "little"
            for c in self.codecs:
                if c.get("name") == "sharding_indexed":
                    raise ZarrError(f"{path}: sharded arrays are not supported")
                if c.get("name") == "bytes":
                    endian = c.get("configuration", {}).get("endian", "little")
            self.dtype = _v3_dtype(np, meta["data_type"], endian)
            self.fill = _fill(np, self.dtype, meta.get("fill_value"))
            self.order = "C"
        else:
            self.chunks = tuple(int(n) for n in meta["chunks"])
            sep = meta.get("dimension_separator", ".")
            self.key = lambda idx: sep.join(map(str, idx)) or "0"
            self.dtype = np.dtype(meta["dtype"] if not isinstance(meta["dtype"], list)
                                  else [tuple(f) for f in meta["dtype"]])
            self.order = meta.get("order", "C")
            self.compressor = meta.get("compressor")
            self.filters = meta.get("filters") or []
            for c in [self.compressor, *self.filters]:
                if c and c.get("id") in _UNSAFE_CODECS:
                    raise ZarrError(f"{path}: the {c['id']!r} codec would run code from the file")
            self.fill = _fill(np, self.dtype, meta.get("fill_value"))

    def _decode(self, raw: bytes):
        np = self.np
        from numcodecs import get_codec

        if self.version == 3:
            array_codecs, bytes_codecs, seen_bytes = [], [], False
            for c in self.codecs:
                name = c.get("name")
                if name == "bytes":
                    seen_bytes = True
                elif not seen_bytes:
                    array_codecs.append(c)
                else:
                    bytes_codecs.append(c)
            for c in reversed(bytes_codecs):
                name = c.get("name")
                if name == "crc32c":
                    raw = raw[:-4]
                elif name in ("blosc", "zstd", "gzip"):
                    raw = get_codec({"id": name}).decode(raw)
                else:
                    raise ZarrError(f"{self.path}: codec {name!r} is not supported")
            arr = np.frombuffer(bytes(raw), dtype=self.dtype)
            for c in array_codecs:
                if c.get("name") != "transpose":
                    raise ZarrError(f"{self.path}: codec {c.get('name')!r} is not supported")
            shape = self.chunks
            order = None
            for c in array_codecs:
                order = c["configuration"]["order"]
                shape = tuple(self.chunks[i] for i in order)
            arr = arr.reshape(shape)
            if order is not None:
                arr = arr.transpose(np.argsort(order))
            return arr
        out = raw
        if self.compressor:
            out = get_codec(dict(self.compressor)).decode(out)
        for f in reversed(self.filters):
            out = get_codec(dict(f)).decode(out)
        arr = out if isinstance(out, np.ndarray) and out.dtype == self.dtype else np.frombuffer(bytes(out), dtype=self.dtype)
        return arr.reshape(self.chunks, order=self.order)

    def __getitem__(self, idx):
        """Rows ``idx`` (a slice along axis 0, or ``()``) as a C-order array."""
        np = self.np
        if idx == ():
            rows = slice(0, self.shape[0] if self.shape else 1)
        else:
            rows = idx
        lo, hi = rows.start, min(rows.stop, self.shape[0]) if self.shape else 1
        if not self.shape:
            raw = self.store.get(self.path + self.key(()) if self.path else self.key(()))
            return np.asarray(self._decode(raw)).reshape(()) if raw is not None else np.full((), self.fill, self.dtype)
        out_shape = (hi - lo,) + self.shape[1:]
        out = np.full(out_shape, self.fill, dtype=self.dtype if self.dtype.kind != "O" else object)
        grid = [range(-(-n // c)) for n, c in zip(self.shape, self.chunks)]
        first, last = lo // self.chunks[0], (hi - 1) // self.chunks[0]
        import itertools

        for idx0 in range(first, last + 1):
            for rest in itertools.product(*grid[1:]):
                cidx = (idx0, *rest)
                raw = self.store.get(self.path + self.key(cidx))
                if raw is None:
                    continue  # never written: the fill value stands
                chunk = self._decode(raw)
                src, dst = [], []
                for d, (ci, cs, n) in enumerate(zip(cidx, self.chunks, self.shape)):
                    start, stop = ci * cs, min((ci + 1) * cs, n)
                    if d == 0:
                        start, stop = max(start, lo), min(stop, hi)
                        src.append(slice(start - ci * cs, stop - ci * cs))
                        dst.append(slice(start - lo, stop - lo))
                    else:
                        src.append(slice(0, stop - start))
                        dst.append(slice(start, stop))
                out[tuple(dst)] = chunk[tuple(src)]
        return out


def walk(np, store) -> Tuple[List[Node], int, dict, str]:
    """``(nodes, format, root metadata, root metadata key)``, excluding the signature."""
    version, root_doc, root_key = _root_meta(store)
    keys = store.logical_keys()
    nodes: List[Node] = []
    for d in _node_paths(keys, version):
        prefix = d + "/" if d else ""
        path = "/" + d if d else "/"
        if version == 3:
            meta = _json(store, prefix + "zarr.json")
            attrs = dict(meta.get("attributes", {}))
            kind = meta.get("node_type")
        else:
            attrs = dict(_json(store, prefix + ".zattrs") or {})
            meta = _json(store, prefix + ".zarray")
            kind = "array" if meta is not None else "group"
        if path == "/":
            attrs.pop(RESERVED, None)  # the signature itself
        if kind == "array":
            arr = _Array(np, store, prefix, meta, version)
            nodes.append(Node(path=path, kind="array", attrs=attrs, dtype=arr.dtype, shape=arr.shape,
                              slabs=lambda arr=arr: slabs_of(np, arr.__getitem__, arr.shape,
                                                             max(arr.dtype.itemsize, 1))))
        elif kind == "group":
            nodes.append(Node(path=path, kind="group", attrs=attrs))
        else:
            raise ZarrError(f"{path}: unknown node type {kind!r}")
    # Consolidated metadata is a second copy of every node's metadata, and it
    # is the copy readers such as HyperSpy act on. It is signed as it stands,
    # so editing a calibration only there is caught like editing it anywhere.
    if version == 2 and store.get(".zmetadata") is not None:
        nodes.append(Node(path="/.zmetadata", kind="metadata", attrs={"content": _json(store, ".zmetadata")}))
    if version == 3 and root_doc.get("consolidated_metadata") is not None:
        nodes.append(Node(path="/zarr.json#consolidated_metadata", kind="metadata",
                          attrs={"content": root_doc["consolidated_metadata"]}))
    return nodes, version, root_doc, root_key


# --------------------------------------------------------------------------
# signing and verification
# --------------------------------------------------------------------------

def _np():
    try:
        import numcodecs  # noqa: F401
        import numpy as np
    except ImportError as exc:  # pragma: no cover - depends on the install
        raise SystemExit("signing Zarr needs numpy and numcodecs: pip install framesig[zarr]") from exc
    return np


def _write_root_attrs(path: pathlib.Path, store: _Store, version: int, root_doc: dict, root_key: str,
                      signature: Optional[dict]) -> None:
    """Set (or remove) the root ``framesig`` attribute, rewriting only that document."""
    if version == 3:
        doc = dict(root_doc)
        attrs = dict(doc.get("attributes", {}))
    else:
        doc = attrs = dict(root_doc)
    attrs.pop(RESERVED, None)
    if signature is not None:
        attrs[RESERVED] = signature
    if version == 3:
        doc["attributes"] = attrs
    data = json.dumps(doc, indent=2).encode("utf-8")
    key = store.prefix + root_key
    if store.zip is None:
        (path / key).write_bytes(data)
        return
    # A zip entry cannot be replaced in place, so copy the archive.
    buf = io.BytesIO()
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(buf, "w") as zout:
        for info in zin.infolist():
            if info.filename != key:
                zout.writestr(info, zin.read(info.filename))
        zout.writestr(zipfile.ZipInfo(key, date_time=(1980, 1, 1, 0, 0, 0)), data)
    path.write_bytes(buf.getvalue())


def is_signed_zarr(path) -> bool:
    if not is_zarr(path):
        return False
    store = _Store(path)
    try:
        version, root_doc, _ = _root_meta(store)
        attrs = root_doc.get("attributes", {}) if version == 3 else root_doc
        return isinstance(attrs.get(RESERVED), dict) and attrs[RESERVED].get("spec") == ZARR_SPEC
    except ZarrError:
        return False
    finally:
        store.close()


def sign_zarr(path, signer, *, certificates_der: Sequence[bytes] = (), claims: Optional[dict] = None,
              attestation: Optional[dict] = None) -> dict:
    """Sign the Zarr store (directory or .zip) at *path* in place.

    Re-signing replaces the signature. Raises ZarrError, before writing
    anything, for a store that cannot be read safely. The store is verified
    before this returns.
    """
    np = _np()
    path = pathlib.Path(path)
    store = _Store(path)
    try:
        nodes, version, root_doc, root_key = walk(np, store)
        envelope, structure = sign_tree(PROFILE, nodes, signer, certificates_der=certificates_der,
                                        claims=claims, attestation=attestation)
    finally:
        store.close()
    store = _Store(path)
    try:
        _write_root_attrs(path, store, version, root_doc, root_key, {
            "spec": ZARR_SPEC, "envelope": envelope,
            "structure": base64.b64encode(structure).decode("ascii"),
        })
    finally:
        store.close()
    check = verify_zarr(path, public_keys=[signer.public_key])
    if check.status != "valid":
        raise RuntimeError(f"the store just signed does not verify: {check.problems}")
    return {"path": str(path), "arrays": len(check.payload_reports), "format": version}


def verify_zarr(path, *, roots=(), public_keys=(), at_time=None, timestamp_roots=()):
    """Verify a Zarr store signed in place. Returns an ``api.VerificationResult``.

    A malformed or hostile store gives a verdict, never an exception.
    """
    from cryptography.exceptions import UnsupportedAlgorithm

    from . import manifest as _m
    from .api import VerificationResult, _authenticate_single

    result = VerificationResult(status="invalid")
    store = None
    try:
        np = _np()
        store = _Store(path)
        version, root_doc, _ = _root_meta(store)
        attrs = root_doc.get("attributes", {}) if version == 3 else root_doc
        sig = attrs.get(RESERVED)
        if sig is None:
            result.status = "unsigned"
            result.problems.append("no signature found: the root group has no framesig attribute")
            return result
        if not isinstance(sig, dict) or sig.get("spec") != ZARR_SPEC:
            result.problems.append(f"the framesig attribute is not a {ZARR_SPEC} signature")
            return result
        envelope = sig["envelope"]
        stored = base64.b64decode(sig.get("structure", ""), validate=True) or None
        try:
            nodes, _, _, _ = walk(np, store)
        except ZarrError as exc:
            result.problems.append(str(exc))
            _authenticate_single(envelope, list(public_keys), result)
            result.status = "tampered" if result.signature_valid else "invalid"
            return result
        verify_tree(PROFILE, nodes, envelope, stored, result, roots=roots, public_keys=public_keys,
                    at_time=at_time, timestamp_roots=timestamp_roots)
    except (KeyError, TypeError, ValueError, OSError, AttributeError, IndexError, UnicodeDecodeError,
            zipfile.BadZipFile, RuntimeError, UnsupportedAlgorithm, _m.EnvelopeError) as exc:
        result.problems.append(f"malformed signed Zarr store: {type(exc).__name__}: {exc}")
        if result.status in ("valid", "metadata-modified"):
            result.status = "tampered" if result.signature_valid else "invalid"
    finally:
        if store is not None:
            store.close()
    return result
