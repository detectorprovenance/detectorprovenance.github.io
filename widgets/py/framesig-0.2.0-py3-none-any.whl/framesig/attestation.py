"""Assurance levels: how much a valid signature is actually worth.

The problem this solves
-----------------------

"The signature verifies" is not the question. A generative model that fabricates
a diffraction pattern can also generate a key pair, sign its output, and embed
the public key -- and the result is cryptographically flawless. Integrity and
origin are different claims, and conflating them turns a verifier into a rubber
stamp for exactly the adversary it was built to stop.

The adversary here is not a third party editing someone else's data. It is the
**author**, who controls the acquisition computer, the file, and the tooling.
Against that adversary the only thing that carries information is a secret they
could not obtain: a key generated inside the detector's secure element, attested
by the manufacturer, applied to data that came off the sensor.

So verification reports two independent things:

* **integrity** -- have the bytes changed since they were signed? (``status``)
* **assurance** -- what does the signature prove about *where the frame came
  from*? (this module)

A frame can be perfectly intact and worth nothing as evidence.

The ladder
----------

``none``
    Unsigned. Carries no claim at all. Most frames in existence.

``self-attested``
    A valid signature under a key that chains to nothing. Proves the bytes have
    not changed since signing. **Proves nothing about origin** -- this is the
    level a fabricated frame reaches for free, and it must never be presented
    as verification.

``custodial``
    Chains to a trusted root, but the key is software-held, or facility-held, or
    the frame does not attest to a physical acquisition. Someone identifiable
    vouches for the file. Still does not establish that a sensor produced it:
    whoever holds the key can sign anything they are given.

``instrument``
    Chains to a manufacturer root; the leaf certificate asserts the key lives in
    a hardware security module on the instrument and was provisioned during
    manufacture; and the signed manifest attests a physical acquisition. This is
    the only level at which "a real detector recorded this" is supported.

Only ``instrument`` should ever be rendered as a pass.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

__all__ = [
    "OID_ARC",
    "OID_INSTRUMENT_ATTESTATION",
    "OID_CUSTODIAL",
    "ACTIVE_PEN",
    "DOCUMENTATION_PEN",
    "ASSURANCE_NONE",
    "ASSURANCE_SELF",
    "ASSURANCE_CUSTODIAL",
    "ASSURANCE_INSTRUMENT",
    "ASSURANCE_ORDER",
    "MODE_PHYSICAL",
    "ACQUISITION_MODES",
    "NON_PHYSICAL_MODES",
    "Assurance",
    "assess_assurance",
    "validate_attestation",
]

ASSURANCE_NONE = "none"
ASSURANCE_SELF = "self-attested"
ASSURANCE_CUSTODIAL = "custodial"
ASSURANCE_INSTRUMENT = "instrument"

#: Weakest first. Downgrades take the minimum.
ASSURANCE_ORDER = [
    ASSURANCE_NONE,
    ASSURANCE_SELF,
    ASSURANCE_CUSTODIAL,
    ASSURANCE_INSTRUMENT,
]

# --------------------------------------------------------------------------
# certificate policy OIDs
# --------------------------------------------------------------------------
#
# Defined in `oids.py`, which is where the one number that must be registered
# with IANA lives. Re-exported here because that is where callers look for
# them, and aliased rather than duplicated so there is exactly one definition.

from .oids import (  # noqa: E402
    ACTIVE_PEN,
    DOCUMENTATION_PEN,
    all_custodial_oids,
    all_instrument_oids,
    arc,
    classify_policies,
    custodial_oid,
    describe_pen,
    instrument_attestation_oid,
    is_provisional,
)

OID_ARC = arc()
OID_INSTRUMENT_ATTESTATION = instrument_attestation_oid()
OID_CUSTODIAL = custodial_oid()

# --------------------------------------------------------------------------
# acquisition modes
# --------------------------------------------------------------------------
#
# Every detector has test-pattern, calibration and software-trigger modes. If
# frames from those modes are signed with the same key and are not
# distinguishable, the scheme collapses: an author simply asks the detector to
# sign a synthetic pattern. So the mode is part of the signed manifest, and
# anything other than a physical exposure caps assurance at `custodial`.

MODE_PHYSICAL = "physical"

ACQUISITION_MODES = {
    MODE_PHYSICAL: "photons on the sensor, read out normally",
    "test-pattern": "detector-generated synthetic image",
    "calibration": "flat-field, dark, or gain calibration exposure",
    "simulated": "data injected into the detector, not measured",
    "unknown": "the signer did not state a mode",
}

NON_PHYSICAL_MODES = set(ACQUISITION_MODES) - {MODE_PHYSICAL}


@dataclass
class Assurance:
    """What a valid signature establishes about origin."""

    level: str = ASSURANCE_NONE
    mode: Optional[str] = None
    #: The enterprise number whose arc the certificate's policy came from, if
    #: any. Surfaced so a report can say *whose* namespace it trusted.
    policy_pen: Optional[int] = None
    #: Why the level is not higher than it is. Always populated below
    #: `instrument`, because "why not" is the useful part of the answer.
    limits: List[str] = field(default_factory=list)
    instrument: dict = field(default_factory=dict)

    @property
    def proves_instrument_origin(self) -> bool:
        return self.level == ASSURANCE_INSTRUMENT

    def to_dict(self) -> dict:
        return {
            "level": self.level,
            "mode": self.mode,
            "policy_pen": self.policy_pen,
            "policy_provisional": is_provisional(self.policy_pen) if self.policy_pen else False,
            "limits": self.limits,
            "instrument": self.instrument or None,
        }

    def headline(self) -> str:
        return {
            ASSURANCE_NONE: "no origin claim",
            ASSURANCE_SELF: "self-attested - origin NOT established",
            ASSURANCE_CUSTODIAL: "custodial - vouched for, but not instrument-attested",
            ASSURANCE_INSTRUMENT: "instrument-attested",
        }[self.level]


def _certificate_policies(cert) -> List[str]:
    from cryptography import x509

    try:
        ext = cert.extensions.get_extension_for_class(x509.CertificatePolicies).value
    except Exception:  # noqa: BLE001 - absent or unparseable is simply "none"
        return []
    return [p.policy_identifier.dotted_string for p in ext]


def validate_attestation(attestation: Optional[dict]) -> List[str]:
    """Structural complaints about a manifest's attestation block."""
    problems: List[str] = []
    if attestation is None:
        return ["the manifest carries no acquisition attestation"]
    if not isinstance(attestation, dict):
        return ["the attestation block is not an object"]
    mode = attestation.get("mode")
    if mode is None:
        problems.append("the attestation does not state an acquisition mode")
    elif mode not in ACQUISITION_MODES:
        problems.append(f"unrecognised acquisition mode {mode!r}")
    return problems


def assess_assurance(
    *,
    signature_valid: bool,
    trust_status: str,
    certificates: list,
    manifest: Optional[dict],
) -> Assurance:
    """Work out what this signature actually proves about origin.

    Deliberately conservative at every branch: an absent claim is treated the
    same as a claim that is not made, never as a claim that is satisfied. A
    scheme whose default is "probably fine" defends against nothing.
    """
    if not signature_valid or not manifest:
        return Assurance(level=ASSURANCE_NONE, limits=["no verified signature"])

    attestation = manifest.get("attestation")
    mode = (attestation or {}).get("mode")
    limits: List[str] = []

    # -- step 1: is there a chain to someone we trust at all? --------------
    if trust_status != "trusted":
        limits.append(
            "the signing key chains to no trusted authority, so anyone -- including "
            "whoever produced the file -- could have generated it"
        )
        return Assurance(level=ASSURANCE_SELF, mode=mode, limits=limits)

    # -- step 2: does the certificate assert instrument-held hardware? -----
    policies = _certificate_policies(certificates[0]) if certificates else []
    kind, pen = classify_policies(policies)
    level = ASSURANCE_INSTRUMENT
    if kind != "instrument":
        level = ASSURANCE_CUSTODIAL
        if kind == "custodial":
            limits.append(
                "the certificate declares a custodial key: software- or "
                "facility-held, not inside the instrument"
            )
        else:
            limits.append(
                "the certificate makes no instrument-attestation claim, so the key "
                "may be software-held; whoever holds it can sign anything"
            )
    # An arc nobody has registered names a claim that is not globally unique.
    # It does not weaken the chain -- authority comes from the root, not the
    # OID -- but it must never pass silently as though it were a real one.
    provisional = describe_pen(pen)
    if provisional:
        limits.append(provisional)

    # -- step 3: what did the detector say it was doing? -------------------
    problems = validate_attestation(attestation)
    if "parents" in manifest:
        # A derived frame (SPEC section 8) is the output of processing, whatever
        # key signed it. Instrument origin belongs to its inputs, each verified
        # as its own link; it is never inherited, and never claimed here.
        level = min(level, ASSURANCE_CUSTODIAL, key=ASSURANCE_ORDER.index)
        limits.append(
            "a derived frame is the output of processing, not an acquisition; "
            "its inputs carry their own assurance"
        )
    elif problems:
        level = min(level, ASSURANCE_CUSTODIAL, key=ASSURANCE_ORDER.index)
        limits.extend(problems)
    elif mode in NON_PHYSICAL_MODES:
        level = min(level, ASSURANCE_CUSTODIAL, key=ASSURANCE_ORDER.index)
        limits.append(
            f"the detector attests this frame was produced in {mode!r} mode "
            f"({ACQUISITION_MODES[mode]}) -- it is not a measurement"
        )

    instrument = {}
    if attestation:
        # `state` names the configuration epoch: the incarnation of this unit
        # after its most recent repair, sensor swap or firmware change. It is
        # what makes a frame attributable to a configuration rather than only to
        # a serial number -- see docs/KEY-HIERARCHY.md.
        # `settings` identifies the detector's operating configuration at
        # exposure time -- threshold energy, gain mode, ROI, binning, the
        # calibration and dead-pixel files in force. Usually a digest of the
        # full configuration record rather than the record itself, so a frame
        # stays small while any change to how the detector was operated remains
        # detectable and bound to the exposure.
        #
        # Deliberately *not* the same mechanism as `state`: settings change many
        # times a session, and re-keying that often would make a key rotation a
        # routine event that nobody witnesses. See docs/KEY-HIERARCHY.md.
        for field_name in ("model", "serial", "state", "settings", "firmware",
                           "sensor", "detector_time"):
            if attestation.get(field_name):
                instrument[field_name] = attestation[field_name]

    return Assurance(level=level, mode=mode, limits=limits, instrument=instrument,
                     policy_pen=pen)
