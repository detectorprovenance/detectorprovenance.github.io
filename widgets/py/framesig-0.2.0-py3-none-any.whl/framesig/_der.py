"""A minimal DER reader and writer.

Why this exists rather than a dependency
----------------------------------------

RFC 3161 timestamp tokens are CMS ``SignedData`` with an ``id-ct-TSTInfo``
payload. ``cryptography`` (50.0) parses X.509 and can extract certificates from
a PKCS#7 blob, but it exposes no TSTInfo, no ``SignerInfo``, and its
``PKCS7SignatureBuilder`` cannot set an arbitrary ``eContentType`` -- so neither
minting nor checking a timestamp token is reachable through it.

The alternatives were a full ASN.1 stack (``asn1crypto``) or about two hundred
lines of DER. Two hundred lines wins here for the same reason the CBF parser and
the JCS canonicaliser are hand-written: the browser verifier is a second
implementation of this spec and cannot pull in a Python ASN.1 library, so the
subset has to be small enough to write twice.

Scope, stated rather than implied
---------------------------------

This handles the subset RFC 3161 needs: definite-length DER, the universal types
that appear in CMS and TSTInfo, and context-tagged constructed values. It is
**not** a general ASN.1 implementation -- no BER, no indefinite lengths, no
streaming, no schema awareness.

Strictness is deliberate. A timestamp is evidence about *when*, so a parser that
accepts sloppy encodings is a parser an adversary can use to make one token read
two ways. Non-minimal lengths, indefinite lengths and non-minimal integers are
refused rather than tolerated.
"""

from __future__ import annotations

import datetime as _dt
from typing import Iterator, List, Optional, Tuple

__all__ = [
    "DerError",
    "Node",
    "parse",
    "SEQUENCE",
    "SET",
    "INTEGER",
    "BIT_STRING",
    "OCTET_STRING",
    "NULL",
    "OID",
    "BOOLEAN",
    "UTF8_STRING",
    "GENERALIZED_TIME",
    "UTC_TIME",
    "context",
    "tlv",
    "der_bool",
    "der_int",
    "der_null",
    "der_octet",
    "der_oid",
    "der_seq",
    "der_set",
    "der_gentime",
    "explicit",
    "implicit",
    "MAX_INPUT",
]

BOOLEAN = 0x01
INTEGER = 0x02
BIT_STRING = 0x03
OCTET_STRING = 0x04
NULL = 0x05
OID = 0x06
UTF8_STRING = 0x0C
PRINTABLE_STRING = 0x13
IA5_STRING = 0x16
UTC_TIME = 0x17
GENERALIZED_TIME = 0x18
SEQUENCE = 0x30
SET = 0x31

CONSTRUCTED = 0x20
CONTEXT = 0x80

#: A timestamp token is a few kilobytes. Anything past this is not a token, and
#: bounding the input keeps a hostile file from being a denial of service before
#: a single field has been read.
MAX_INPUT = 1 << 20

#: Guards against a deeply nested structure exhausting the Python stack.
MAX_DEPTH = 32


class DerError(ValueError):
    """The input is not well-formed DER, or is not the shape expected."""


def context(number: int, constructed: bool = True) -> int:
    """The tag byte for a context-specific class tag, e.g. ``[0]``."""
    if not 0 <= number <= 30:
        raise DerError(f"context tag {number} outside the single-byte range")
    return CONTEXT | (CONSTRUCTED if constructed else 0) | number


# --------------------------------------------------------------------------
# reading
# --------------------------------------------------------------------------

class Node:
    """One TLV. ``content`` is the raw value; children are parsed on demand."""

    __slots__ = ("tag", "content", "_depth")

    def __init__(self, tag: int, content: bytes, depth: int = 0):
        self.tag = tag
        self.content = content
        self._depth = depth

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"Node(tag=0x{self.tag:02x}, len={len(self.content)})"

    @property
    def constructed(self) -> bool:
        return bool(self.tag & CONSTRUCTED)

    def children(self) -> List["Node"]:
        if not self.constructed:
            raise DerError(f"tag 0x{self.tag:02x} is primitive and has no children")
        if self._depth >= MAX_DEPTH:
            raise DerError("DER nesting too deep")
        return list(_walk(self.content, self._depth + 1))

    def child(self, index: int) -> "Node":
        kids = self.children()
        if index >= len(kids):
            raise DerError(f"expected at least {index + 1} elements, found {len(kids)}")
        return kids[index]

    def expect(self, tag: int) -> "Node":
        if self.tag != tag:
            raise DerError(f"expected tag 0x{tag:02x}, found 0x{self.tag:02x}")
        return self

    # -- typed accessors ---------------------------------------------------
    def as_int(self) -> int:
        self.expect(INTEGER)
        raw = self.content
        if not raw:
            raise DerError("empty INTEGER")
        if len(raw) > 1 and raw[0] in (0x00, 0xFF) and (raw[1] & 0x80) == (
            0x80 if raw[0] == 0xFF else 0x00
        ):
            raise DerError("non-minimal INTEGER encoding")
        return int.from_bytes(raw, "big", signed=True)

    def as_bool(self) -> bool:
        self.expect(BOOLEAN)
        if len(self.content) != 1:
            raise DerError("BOOLEAN must be one byte")
        if self.content[0] not in (0x00, 0xFF):
            raise DerError("DER BOOLEAN must be 0x00 or 0xFF")
        return self.content[0] == 0xFF

    def as_oid(self) -> str:
        self.expect(OID)
        raw = self.content
        if not raw:
            raise DerError("empty OBJECT IDENTIFIER")
        first = raw[0]
        parts = [str(first // 40), str(first % 40)]
        value = 0
        started = False
        for i, byte in enumerate(raw[1:], start=1):
            if not started and byte == 0x80:
                raise DerError("non-minimal OID sub-identifier")
            started = True
            value = (value << 7) | (byte & 0x7F)
            if not byte & 0x80:
                parts.append(str(value))
                value = 0
                started = False
        if started:
            raise DerError("truncated OID sub-identifier")
        return ".".join(parts)

    def as_octets(self) -> bytes:
        self.expect(OCTET_STRING)
        return self.content

    def as_bits(self) -> bytes:
        self.expect(BIT_STRING)
        if not self.content:
            raise DerError("empty BIT STRING")
        unused = self.content[0]
        if unused:
            raise DerError("BIT STRING with unused bits is not expected here")
        return self.content[1:]

    def as_time(self) -> _dt.datetime:
        """GeneralizedTime, restricted to the DER-legal UTC form.

        DER requires a trailing ``Z``, no offset, and no trailing zeros in the
        fractional part. Local-time forms are refused: a timestamp whose zone is
        implied is a timestamp two readers can disagree about, which is the one
        thing this value must never be.
        """
        if self.tag != GENERALIZED_TIME:
            raise DerError(f"expected GeneralizedTime, found tag 0x{self.tag:02x}")
        text = self.content.decode("ascii", errors="strict")
        if not text.endswith("Z"):
            raise DerError("GeneralizedTime must be UTC and end with 'Z'")
        body = text[:-1]
        fraction = 0
        if "." in body:
            body, frac_text = body.split(".", 1)
            if not frac_text or frac_text.endswith("0"):
                raise DerError("non-minimal fractional seconds in GeneralizedTime")
            fraction = int(round(float("0." + frac_text) * 1_000_000))
        if len(body) != 14 or not body.isdigit():
            raise DerError(f"malformed GeneralizedTime {text!r}")
        return _dt.datetime(
            int(body[0:4]), int(body[4:6]), int(body[6:8]),
            int(body[8:10]), int(body[10:12]), int(body[12:14]),
            fraction, tzinfo=_dt.timezone.utc,
        )

    def raw(self) -> bytes:
        """Re-encode this node exactly."""
        return tlv(self.tag, self.content)


def _read_length(data: bytes, offset: int) -> Tuple[int, int]:
    if offset >= len(data):
        raise DerError("truncated: no length byte")
    first = data[offset]
    offset += 1
    if first == 0x80:
        raise DerError("indefinite length is BER, not DER")
    if first < 0x80:
        return first, offset
    count = first & 0x7F
    if count == 0x7F:
        raise DerError("reserved length form")
    if offset + count > len(data):
        raise DerError("truncated: length bytes run past the end")
    chunk = data[offset : offset + count]
    if chunk[0] == 0x00:
        raise DerError("non-minimal length encoding")
    length = int.from_bytes(chunk, "big")
    if length < 0x80:
        raise DerError("long-form length used for a value that fits the short form")
    return length, offset + count


def _walk(data: bytes, depth: int = 0) -> Iterator[Node]:
    offset = 0
    while offset < len(data):
        tag = data[offset]
        if tag & 0x1F == 0x1F:
            raise DerError("multi-byte tags are not supported")
        length, offset = _read_length(data, offset + 1)
        end = offset + length
        if end > len(data):
            raise DerError("truncated: value runs past the end of the input")
        yield Node(tag, data[offset:end], depth)
        offset = end


def parse(data: bytes) -> Node:
    """Parse exactly one top-level TLV, refusing trailing bytes.

    Trailing data is refused rather than ignored: bytes after a token are bytes
    a verifier and a signer can disagree about.
    """
    if len(data) > MAX_INPUT:
        raise DerError(f"input of {len(data)} bytes exceeds the {MAX_INPUT}-byte limit")
    nodes = list(_walk(data))
    if len(nodes) != 1:
        raise DerError(f"expected exactly one top-level value, found {len(nodes)}")
    return nodes[0]


# --------------------------------------------------------------------------
# writing
# --------------------------------------------------------------------------

def _encode_length(n: int) -> bytes:
    if n < 0x80:
        return bytes([n])
    raw = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(raw)]) + raw


def tlv(tag: int, content: bytes) -> bytes:
    return bytes([tag]) + _encode_length(len(content)) + content


def der_int(value: int) -> bytes:
    if value == 0:
        return tlv(INTEGER, b"\x00")
    length = (value.bit_length() + 8) // 8  # room for the sign bit
    return tlv(INTEGER, value.to_bytes(length, "big", signed=True))


def der_bool(value: bool) -> bytes:
    return tlv(BOOLEAN, b"\xff" if value else b"\x00")


def der_null() -> bytes:
    return tlv(NULL, b"")


def der_octet(data: bytes) -> bytes:
    return tlv(OCTET_STRING, data)


def der_oid(dotted: str) -> bytes:
    parts = [int(p) for p in dotted.split(".")]
    if len(parts) < 2:
        raise DerError(f"not an OID: {dotted!r}")
    if parts[0] > 2 or (parts[0] < 2 and parts[1] > 39):
        raise DerError(f"OID {dotted!r} has an out-of-range first arc")
    out = bytearray([parts[0] * 40 + parts[1]])
    for part in parts[2:]:
        if part < 0:
            raise DerError(f"negative OID arc in {dotted!r}")
        chunk = bytearray([part & 0x7F])
        part >>= 7
        while part:
            chunk.insert(0, (part & 0x7F) | 0x80)
            part >>= 7
        out.extend(chunk)
    return tlv(OID, bytes(out))


def der_seq(*parts: bytes) -> bytes:
    return tlv(SEQUENCE, b"".join(parts))


def der_set(*parts: bytes) -> bytes:
    """A SET OF, with DER's mandatory sort by encoding.

    Sorting is not cosmetic: signed attributes are signed *as a SET OF*, so a
    verifier that re-encodes in a different order computes a different digest
    and rejects a perfectly good signature.
    """
    return tlv(SET, b"".join(sorted(parts)))


def der_gentime(when: _dt.datetime) -> bytes:
    if when.tzinfo is None:
        when = when.replace(tzinfo=_dt.timezone.utc)
    when = when.astimezone(_dt.timezone.utc)
    text = when.strftime("%Y%m%d%H%M%S")
    if when.microsecond:
        fraction = f"{when.microsecond:06d}".rstrip("0")
        text += "." + fraction
    return tlv(GENERALIZED_TIME, (text + "Z").encode("ascii"))


def explicit(number: int, inner: bytes) -> bytes:
    """``[n] EXPLICIT`` -- the inner TLV wrapped in a context-tagged one."""
    return tlv(context(number), inner)


def implicit(number: int, content: bytes, constructed: bool = True) -> bytes:
    """``[n] IMPLICIT`` -- the tag replaced, the content kept as-is."""
    return tlv(context(number, constructed), content)


def retag(node: Node, tag: int) -> bytes:
    """Re-encode *node* under a different tag, content untouched.

    Needed exactly once, and it is the classic CMS trap: ``signedAttrs`` travels
    as ``[0] IMPLICIT`` but is **signed as a universal SET OF**. Signing the
    wire form produces a token nothing can verify.
    """
    return tlv(tag, node.content)


def find_context(nodes: List[Node], number: int) -> Optional[Node]:
    """First context-tagged child with the given number, or None."""
    for node in nodes:
        if node.tag & 0xC0 == CONTEXT and (node.tag & 0x1F) == number:
            return node
    return None
