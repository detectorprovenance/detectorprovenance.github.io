"""RFC 3161 timestamps: evidence about *when* a signature existed.

Why a timestamp is load-bearing here
------------------------------------

When a key is withdrawn, the question for every frame it ever signed is: was
this signed before or after? ``manifest.created`` cannot answer it -- the signer
asserts it, so a compromised key backdates it for free, which is exactly the
situation in which the question is asked.

Without external time evidence a compromise can only be handled one way: treat
everything the key ever signed as suspect, including a decade of good data from
a detector that was fine until last Tuesday. **The humane, date-scoped answer is
the one that needs this module**; the destructive one needs nothing. See
:mod:`framesig.revocation` for the asymmetry that falls out of it.

What a token proves, and what it does not
-----------------------------------------

A token says: *this digest existed no later than* ``genTime``. That is all. It
says nothing about who produced the data, nothing about whether the data are
honest, and nothing about the digest being meaningful. It is one fact, and it is
the fact revocation scoping needs.

Independence is part of the evidence
------------------------------------

A vendor's public-key server is the natural place to run a TSA -- no new
organisation to vet, no new key to distribute, and RFC 3161 assumes CA-run
services. But if one organisation issues both the certificates and the
timestamps, an adversary who compromises it gets to mint certificates *and*
backdate tokens, and the scoping mechanism it was introduced for collapses.

That is survivable, because the adversary this project is built against is the
**author** -- who cannot backdate whoever runs the TSA. So a vendor TSA is sound
against the primary threat and unsound against vendor compromise, and the honest
response is to count independent attestations rather than to pick one policy:

``self-asserted``
    only the signer's own ``created`` field. Not evidence.
``issuer-timestamped``
    a token, but from an authority tied to the one that issued the signing
    certificate. Worth strictly less, and must be reported as such.
``independently-timestamped``
    a token from an authority independent of the signing certificate's issuer.
    At a beamline this is free: the detector vendor and the facility are already
    separate organisations.
``logged``
    an append-only transparency log inclusion proof, which removes the need to
    trust a TSA not to backdate. Not implemented; the record format is a list so
    it can be added without a format break.

Strictness
----------

Every check below is one a real deployment gets wrong somewhere, so none of them
are optional and none are inferred:

* the token's ``messageImprint`` must equal the digest we asked about -- a token
  over *something else* is a valid token and no evidence at all;
* the TSA certificate must carry ``id-kp-timeStamping`` as its **only** extended
  key usage, marked critical (RFC 3161 §2.3). This is what stops a CA's
  general-purpose key from doubling as a timestamping key, which is precisely
  the co-location risk above;
* the chain is validated at ``genTime``, not at "now", or every archived token
  stops verifying the day the TSA certificate expires;
* a nonce, if one was sent, must come back.
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, padding, rsa

from . import _der as der
from .digest import sha256

__all__ = [
    "OID_SIGNED_DATA",
    "OID_CT_TSTINFO",
    "OID_SHA256",
    "OID_TIME_STAMPING",
    "STATUS_GRANTED",
    "EVIDENCE_SELF",
    "EVIDENCE_ISSUER",
    "EVIDENCE_INDEPENDENT",
    "EVIDENCE_LOGGED",
    "EVIDENCE_ORDER",
    "TimestampError",
    "TimestampToken",
    "TimeEvidence",
    "build_request",
    "parse_response",
    "verify_token",
    "assess_time_evidence",
    "fetch_token",
]

# -- object identifiers ----------------------------------------------------
OID_SIGNED_DATA = "1.2.840.113549.1.7.2"
OID_CT_TSTINFO = "1.2.840.113549.1.9.16.1.4"
OID_ATTR_CONTENT_TYPE = "1.2.840.113549.1.9.3"
OID_ATTR_MESSAGE_DIGEST = "1.2.840.113549.1.9.4"
OID_ATTR_SIGNING_TIME = "1.2.840.113549.1.9.5"
OID_SHA256 = "2.16.840.1.101.3.4.2.1"
OID_ECDSA_SHA256 = "1.2.840.10045.4.3.2"
OID_ED25519 = "1.3.101.112"
OID_RSA_SHA256 = "1.2.840.113549.1.1.11"
OID_RSA_ENCRYPTION = "1.2.840.113549.1.1.1"
OID_TIME_STAMPING = "1.3.6.1.5.5.7.3.8"

#: PKIStatus values that carry a usable token (RFC 3161 §2.4.2).
STATUS_GRANTED = (0, 1)

_STATUS_TEXT = {
    0: "granted",
    1: "granted with modifications",
    2: "rejected",
    3: "waiting",
    4: "revocation warning",
    5: "revocation notification",
}

EVIDENCE_SELF = "self-asserted"
EVIDENCE_ISSUER = "issuer-timestamped"
EVIDENCE_INDEPENDENT = "independently-timestamped"
EVIDENCE_LOGGED = "logged"

#: Weakest first.
EVIDENCE_ORDER = [EVIDENCE_SELF, EVIDENCE_ISSUER, EVIDENCE_INDEPENDENT, EVIDENCE_LOGGED]


class TimestampError(ValueError):
    """A timestamp request, response or token is malformed or unacceptable."""


# --------------------------------------------------------------------------
# requesting
# --------------------------------------------------------------------------

def build_request(digest: bytes, *, nonce: Optional[int] = None,
                  cert_req: bool = True, policy: Optional[str] = None) -> bytes:
    """A DER ``TimeStampReq`` over a SHA-256 digest.

    ``cert_req`` defaults to True and should stay that way: it asks the TSA to
    include its certificate chain in the token. **A detector may outlive its
    manufacturer**, and a token that references a certificate instead of
    carrying it makes verification in 2040 depend on a company still existing.
    """
    if len(digest) != 32:
        raise TimestampError(f"expected a 32-byte SHA-256 digest, got {len(digest)}")

    parts = [
        der.der_int(1),  # version v1
        der.der_seq(
            der.der_seq(der.der_oid(OID_SHA256)),
            der.der_octet(digest),
        ),
    ]
    if policy:
        parts.append(der.der_oid(policy))
    if nonce is not None:
        parts.append(der.der_int(nonce))
    # DEFAULT FALSE, so DER omits it when false.
    if cert_req:
        parts.append(der.der_bool(True))
    return der.der_seq(*parts)


def parse_response(data: bytes) -> bytes:
    """Pull the ``TimeStampToken`` out of a ``TimeStampResp``, or explain why not."""
    resp = der.parse(data).expect(der.SEQUENCE).children()
    if not resp:
        raise TimestampError("empty TimeStampResp")

    status_info = resp[0].expect(der.SEQUENCE).children()
    status = status_info[0].as_int()
    if status not in STATUS_GRANTED:
        text = _STATUS_TEXT.get(status, f"unknown status {status}")
        detail = ""
        for node in status_info[1:]:
            if node.tag == der.SEQUENCE:  # PKIFreeText
                try:
                    detail = "; " + "; ".join(
                        child.content.decode("utf-8", "replace") for child in node.children()
                    )
                except der.DerError:
                    pass
        raise TimestampError(f"the timestamp authority refused: {text}{detail}")

    if len(resp) < 2:
        raise TimestampError("the response says granted but carries no token")
    return resp[1].raw()


def fetch_token(url: str, request: bytes, *, timeout: float = 15.0) -> bytes:
    """POST a ``TimeStampReq`` to a TSA and return the raw response.

    Made solely at signing time and only when a URL is passed. **Verification
    never needs the network** -- a token carries everything needed to check it,
    which is what makes an archive readable on an air-gapped machine in twenty
    years. The one other outbound call, fetching withdrawal lists
    (:mod:`framesig.online`), happens only when a verifier asks for it.
    """
    import urllib.request

    if not url.lower().startswith(("http://", "https://")):
        raise TimestampError(f"refusing to fetch a timestamp from {url!r}: not an HTTP(S) URL")
    req = urllib.request.Request(
        url, data=request,
        headers={"Content-Type": "application/timestamp-query",
                 "Accept": "application/timestamp-reply"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:  # noqa: S310 - scheme checked
        return response.read(der.MAX_INPUT + 1)


# --------------------------------------------------------------------------
# the token
# --------------------------------------------------------------------------

@dataclass
class TimestampToken:
    """A verified RFC 3161 token."""

    gen_time: _dt.datetime
    serial: int
    policy: Optional[str] = None
    accuracy_seconds: int = 0
    nonce: Optional[int] = None
    tsa_certificate: Optional[x509.Certificate] = None
    chain: List[str] = field(default_factory=list)
    trusted: bool = False
    problems: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @property
    def not_after(self) -> _dt.datetime:
        """The latest instant the digest can have come into existence.

        ``genTime`` plus the TSA's declared accuracy. Using the *late* edge is
        the conservative direction: it is the value that must still fall before
        a compromise date for the signature to be excused.
        """
        return self.gen_time + _dt.timedelta(seconds=self.accuracy_seconds)

    def to_dict(self) -> dict:
        return {
            "gen_time": self.gen_time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "accuracy_seconds": self.accuracy_seconds,
            "serial": str(self.serial),
            "policy": self.policy,
            "tsa": None if self.tsa_certificate is None
            else self.tsa_certificate.subject.rfc4514_string(),
            "trusted": self.trusted,
            "chain": self.chain,
            "problems": self.problems,
            "notes": self.notes,
        }


def _algorithm_oid(node: der.Node) -> str:
    return node.expect(der.SEQUENCE).child(0).as_oid()


def _verify_cms_signature(cert: x509.Certificate, signature: bytes,
                          message: bytes, sig_alg: str) -> bool:
    public_key = cert.public_key()
    try:
        if sig_alg == OID_ED25519:
            if not isinstance(public_key, ed25519.Ed25519PublicKey):
                return False
            public_key.verify(signature, message)
        elif sig_alg == OID_ECDSA_SHA256:
            if not isinstance(public_key, ec.EllipticCurvePublicKey):
                return False
            public_key.verify(signature, message, ec.ECDSA(hashes.SHA256()))
        elif sig_alg in (OID_RSA_SHA256, OID_RSA_ENCRYPTION):
            if not isinstance(public_key, rsa.RSAPublicKey):
                return False
            public_key.verify(signature, message, padding.PKCS1v15(), hashes.SHA256())
        else:
            return False
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


def _certificates_from(signed_data: List[der.Node]) -> List[x509.Certificate]:
    node = der.find_context(signed_data, 0)
    if node is None:
        return []
    certs = []
    for child in node.children():
        if child.tag != der.SEQUENCE:
            continue  # CertificateChoices can hold other things; we want plain certs
        try:
            certs.append(x509.load_der_x509_certificate(child.raw()))
        except Exception:  # noqa: BLE001 - an unreadable entry is data, not a crash
            continue
    return certs


def _match_signer(sid: der.Node, certs: Sequence[x509.Certificate]) -> Optional[x509.Certificate]:
    if sid.tag == der.SEQUENCE:  # issuerAndSerialNumber
        kids = sid.children()
        issuer_der = kids[0].raw()
        serial = kids[1].as_int()
        for cert in certs:
            if cert.serial_number == serial and cert.issuer.public_bytes() == issuer_der:
                return cert
        return None
    if sid.tag & 0xC0 == 0x80:  # [0] subjectKeyIdentifier
        wanted = sid.content
        for cert in certs:
            try:
                ski = cert.extensions.get_extension_for_class(x509.SubjectKeyIdentifier).value
            except x509.ExtensionNotFound:
                continue
            if ski.digest == wanted:
                return cert
        return None
    return None


def _check_tsa_certificate(cert: x509.Certificate) -> List[str]:
    """RFC 3161 §2.3: timeStamping, only timeStamping, and critical.

    The requirement exists to stop a CA's general-purpose key from also issuing
    timestamps -- which is exactly the failure mode when a vendor co-locates its
    TSA with its key server. Co-locating the *service* is fine; co-locating the
    *key* is refused by the standard, so refuse it here.
    """
    problems: List[str] = []
    try:
        ext = cert.extensions.get_extension_for_class(x509.ExtendedKeyUsage)
    except x509.ExtensionNotFound:
        return [
            "the TSA certificate carries no extendedKeyUsage; RFC 3161 requires "
            "id-kp-timeStamping, and without it this key may also be usable for other purposes"
        ]
    usages = [oid.dotted_string for oid in ext.value]
    if OID_TIME_STAMPING not in usages:
        problems.append(
            "the TSA certificate does not permit id-kp-timeStamping, so it is not a "
            "timestamping certificate at all"
        )
    extra = [u for u in usages if u != OID_TIME_STAMPING]
    if extra:
        problems.append(
            "the TSA certificate permits other extended key usages alongside timestamping "
            f"({', '.join(extra)}); RFC 3161 requires timeStamping to be the only one, so "
            "that a general-purpose key cannot also mint timestamps"
        )
    if not ext.critical:
        problems.append(
            "the TSA certificate's extendedKeyUsage is not marked critical, so a verifier "
            "that ignores the extension would accept this key for anything"
        )
    return problems


def _parse_tstinfo(data: bytes) -> dict:
    fields = der.parse(data).expect(der.SEQUENCE).children()
    if len(fields) < 5:
        raise TimestampError("TSTInfo is missing required fields")
    version = fields[0].as_int()
    if version != 1:
        raise TimestampError(f"unsupported TSTInfo version {version}")

    imprint = fields[2].expect(der.SEQUENCE).children()
    info = {
        "policy": fields[1].as_oid(),
        "hash_algorithm": _algorithm_oid(imprint[0]),
        "hashed_message": imprint[1].as_octets(),
        "serial": fields[3].as_int(),
        "gen_time": fields[4].as_time(),
        "accuracy_seconds": 0,
        "nonce": None,
    }
    for node in fields[5:]:
        if node.tag == der.SEQUENCE:  # Accuracy
            seconds = 0
            for part in node.children():
                if part.tag == der.INTEGER:
                    seconds = part.as_int()
                elif part.tag & 0xC0 == 0x80 and (part.tag & 0x1F) in (0, 1):
                    # millis / micros: round up to a whole second rather than
                    # discarding, so the late edge stays conservative.
                    if int.from_bytes(part.content, "big"):
                        seconds += 1
            info["accuracy_seconds"] = seconds
        elif node.tag == der.INTEGER:
            info["nonce"] = node.as_int()
    return info


def verify_token(
    token_der: bytes,
    expected_digest: bytes,
    *,
    roots: Sequence[x509.Certificate] = (),
    nonce: Optional[int] = None,
) -> TimestampToken:
    """Check a token end to end and say what it establishes.

    Raises :class:`TimestampError` when the token is not a token, or is a token
    over something other than *expected_digest*. Softer failures -- an untrusted
    or non-conforming TSA certificate -- come back on the result as ``problems``
    with ``trusted`` False, because "there is a token but I cannot rely on it"
    is a different and more useful answer than an exception.
    """
    from .pki import verify_chain

    content_info = der.parse(token_der).expect(der.SEQUENCE).children()
    if not content_info or content_info[0].as_oid() != OID_SIGNED_DATA:
        raise TimestampError("the token is not a CMS SignedData")
    wrapper = der.find_context(content_info, 0)
    if wrapper is None:
        raise TimestampError("the token's SignedData content is missing")
    signed_data = wrapper.child(0).expect(der.SEQUENCE).children()
    if len(signed_data) < 4:
        raise TimestampError("SignedData is missing required fields")

    encap = signed_data[2].expect(der.SEQUENCE).children()
    if encap[0].as_oid() != OID_CT_TSTINFO:
        raise TimestampError(
            f"the token encapsulates {encap[0].as_oid()}, not a TSTInfo; it is a signed "
            "object but not a timestamp"
        )
    if len(encap) < 2:
        raise TimestampError("the token carries no TSTInfo content")
    tstinfo_der = encap[1].child(0).as_octets()
    info = _parse_tstinfo(tstinfo_der)

    if info["hash_algorithm"] != OID_SHA256:
        raise TimestampError(
            f"the token was made over a {info['hash_algorithm']} digest; only SHA-256 is accepted"
        )
    if info["hashed_message"] != expected_digest:
        # A token over a different digest is perfectly valid and completely
        # irrelevant. Accepting it would let any real token vouch for any data.
        raise TimestampError(
            "the token is over a different digest than the one asked about "
            f"(token: sha256:{info['hashed_message'].hex()})"
        )
    if nonce is not None and info["nonce"] != nonce:
        raise TimestampError(
            "the token does not echo the nonce that was sent, so it may be a replay of an "
            "older response"
        )

    token = TimestampToken(
        gen_time=info["gen_time"],
        serial=info["serial"],
        policy=info["policy"],
        accuracy_seconds=info["accuracy_seconds"],
        nonce=info["nonce"],
    )

    signer_infos = signed_data[-1].expect(der.SET).children()
    if len(signer_infos) != 1:
        raise TimestampError(
            f"the token carries {len(signer_infos)} signers; exactly one is expected, because "
            "a token with several is a token that says several things"
        )
    signer = signer_infos[0].expect(der.SEQUENCE).children()
    sid = signer[1]
    signed_attrs = der.find_context(signer, 0)
    if signed_attrs is None:
        raise TimestampError("the token has no signed attributes")

    remaining = [n for n in signer[2:] if n.tag not in (der.context(0), der.context(1))]
    if len(remaining) < 3:
        raise TimestampError("SignerInfo is missing its algorithm or signature")
    sig_alg = _algorithm_oid(remaining[1])
    signature = remaining[2].as_octets()

    attrs = {}
    for attr in signed_attrs.children():
        kids = attr.expect(der.SEQUENCE).children()
        attrs[kids[0].as_oid()] = kids[1].expect(der.SET).children()

    if OID_ATTR_CONTENT_TYPE not in attrs or attrs[OID_ATTR_CONTENT_TYPE][0].as_oid() != OID_CT_TSTINFO:
        raise TimestampError("the signed content-type attribute is missing or is not TSTInfo")
    if OID_ATTR_MESSAGE_DIGEST not in attrs:
        raise TimestampError("the signed message-digest attribute is missing")
    if attrs[OID_ATTR_MESSAGE_DIGEST][0].as_octets() != sha256(tstinfo_der):
        raise TimestampError(
            "the signed message-digest does not match the TSTInfo it travels with"
        )

    certs = _certificates_from(signed_data)
    tsa_cert = _match_signer(sid, certs)
    if tsa_cert is None:
        raise TimestampError(
            "the token does not carry the certificate it was signed with, so it cannot be "
            "checked offline; the TSA was asked for one (certReq) and did not supply it"
        )
    token.tsa_certificate = tsa_cert

    # signedAttrs travels as [0] IMPLICIT but is signed as a universal SET OF.
    # Signing or verifying the wire form yields a token nothing can check.
    message = der.retag(signed_attrs, der.SET)
    if not _verify_cms_signature(tsa_cert, signature, message, sig_alg):
        raise TimestampError("the timestamp token's signature does not verify")

    token.problems.extend(_check_tsa_certificate(tsa_cert))

    intermediates = [c for c in certs if c is not tsa_cert]
    if roots:
        # At genTime, not at "now": an archived token must not stop verifying the
        # day the TSA certificate expires, or the archive has a shelf life.
        chain = verify_chain(tsa_cert, intermediates, roots, at_time=token.gen_time,
                             leaf_usage=("digital_signature", "content_commitment"),
                             leaf_eku=OID_TIME_STAMPING)
        token.chain = chain.chain
        if chain.ok:
            token.trusted = not token.problems
            if token.problems:
                token.notes.append(
                    "the chain reaches a trusted root, but the certificate does not meet "
                    "RFC 3161's requirements for a timestamping certificate"
                )
        else:
            token.problems.append(f"the TSA certificate is not trusted: {chain.reason}")
    else:
        token.problems.append(
            "no trust anchor was supplied for the timestamp authority, so this token "
            "establishes internal consistency and nothing about who issued it"
        )
    return token


# --------------------------------------------------------------------------
# what a set of tokens is worth
# --------------------------------------------------------------------------

@dataclass
class TimeEvidence:
    """How well the signing time of an object is established."""

    level: str = EVIDENCE_SELF
    #: The earliest instant any trusted token places the data at. This is the
    #: value revocation scoping uses: it is what shows a signature predates a
    #: compromise.
    established_at: Optional[_dt.datetime] = None
    tokens: List[TimestampToken] = field(default_factory=list)
    limits: List[str] = field(default_factory=list)

    @property
    def usable(self) -> bool:
        """Is there time evidence a verifier may rely on at all?"""
        return self.established_at is not None and self.level != EVIDENCE_SELF

    def headline(self) -> str:
        return {
            EVIDENCE_SELF: "self-asserted - the signing time is not evidence",
            EVIDENCE_ISSUER: "timestamped by the certificate issuer's own authority",
            EVIDENCE_INDEPENDENT: "independently timestamped",
            EVIDENCE_LOGGED: "logged in an append-only transparency log",
        }[self.level]

    def to_dict(self) -> dict:
        return {
            "level": self.level,
            "established_at": None if self.established_at is None
            else self.established_at.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "usable": self.usable,
            "tokens": [t.to_dict() for t in self.tokens],
            "limits": self.limits,
        }


def _organisations(cert: Optional[x509.Certificate]) -> set:
    if cert is None:
        return set()
    from cryptography.x509.oid import NameOID

    out = set()
    for name in (cert.subject, cert.issuer):
        for attr in name.get_attributes_for_oid(NameOID.ORGANIZATION_NAME):
            out.add(str(attr.value).strip().casefold())
    return out


def assess_time_evidence(
    tokens: Sequence[TimestampToken],
    signing_certificates: Sequence[x509.Certificate] = (),
) -> TimeEvidence:
    """Rank the time evidence for one signed object.

    Independence is decided by comparing organisations across the timestamping
    and signing chains. It is a coarse test and deliberately errs towards
    calling things *dependent*: two arms of one company sharing an O= are not
    independent, and treating them as though they were would overstate exactly
    the property that matters.
    """
    evidence = TimeEvidence(tokens=list(tokens))
    trusted = [t for t in tokens if t.trusted]

    if not tokens:
        evidence.limits.append(
            "no timestamp: the only signing time available is the one the signer wrote "
            "into the manifest, which a compromised key sets to whatever suits it"
        )
        return evidence
    if not trusted:
        evidence.limits.append(
            f"{len(tokens)} timestamp token(s) present, none of them from a trusted "
            "authority; a token nobody can attribute is not evidence of time"
        )
        for token in tokens:
            evidence.limits.extend(token.problems)
        return evidence

    signer_orgs = set()
    for cert in signing_certificates:
        signer_orgs |= _organisations(cert)

    independent = [t for t in trusted if not (_organisations(t.tsa_certificate) & signer_orgs)]

    if independent:
        evidence.level = EVIDENCE_INDEPENDENT
        chosen = independent
    else:
        evidence.level = EVIDENCE_ISSUER
        chosen = trusted
        evidence.limits.append(
            "every timestamp comes from the same organisation that issued the signing "
            "certificate, so a compromise of that organisation would let it both sign "
            "and backdate; this establishes time against the data's author, not against "
            "the issuer"
        )

    # The earliest trusted token is what bounds the data's age. Take the late
    # edge of its accuracy window, so an accuracy claim can never be used to
    # move a signature earlier than the TSA actually vouched for.
    evidence.established_at = min(t.not_after for t in chosen)
    return evidence
