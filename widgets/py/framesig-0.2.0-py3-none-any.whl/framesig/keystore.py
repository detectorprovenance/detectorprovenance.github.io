"""Private key custody.

The rule this file enforces
--------------------------

**A private key exists in exactly two acceptable places: inside a device that
cannot export it, or inside an encrypted file. Never anywhere else.**

Against the threat model in ``docs/DESIGN.md`` §2.0 -- where the adversary is
the author, not a stranger -- a key on disk in the clear is not a weaker form of
security, it is none: anyone who can read the file can produce frames that
verify. So this module refuses to write one without an explicit, ugly opt-in,
and refuses several other things that are easy to do by accident:

* passphrases are never taken from the command line. ``--password secret`` is
  visible in ``ps``, in Windows Task Manager's command-line column, in shell
  history, and in any CI log that echoes the invocation. It is one of the most
  reliable ways to leak a key, and it looks completely safe.
* the default on-disk form is **encrypted PKCS#8 DER** -- binary, standard,
  and readable by OpenSSL and every language's crypto stack. PEM is accepted on
  read because the world is full of it.
* an existing key file is never silently overwritten. Overwriting a signing key
  destroys the ability to ever sign as that identity again, and there is no
  recovery.
* a key file that is group- or world-readable is reported, because "encrypted"
  and "encrypted with a weak passphrase that anyone can now grind offline" are
  different things.

None of this protects against a determined author who wants to hand out their
own key -- nothing can. It protects against the key leaking by accident, which
is what actually happens.
"""

from __future__ import annotations

import getpass
import os
import pathlib
import stat
import sys
from typing import Optional

from cryptography.hazmat.primitives import serialization

from ._fs import atomic_write
from .keys import algorithm_of

__all__ = [
    "KeyCustodyError",
    "PassphraseRequired",
    "load_private_key_for",
    "PLAINTEXT_OPT_IN",
    "resolve_passphrase",
    "write_private_key",
    "read_private_key",
    "check_key_file_permissions",
]


class KeyCustodyError(RuntimeError):
    """A key would have been handled in a way that leaks it."""


class PassphraseRequired(KeyCustodyError):
    """The key file is encrypted and no passphrase was available."""


#: Deliberately verbose. Anybody typing this has been told what it means.
PLAINTEXT_OPT_IN = "--i-accept-an-unencrypted-key"

_MIN_PASSPHRASE = 8


# --------------------------------------------------------------------------
# passphrases
# --------------------------------------------------------------------------

def resolve_passphrase(
    *,
    env_var: Optional[str] = None,
    file_path: Optional[str] = None,
    confirm: bool = False,
    prompt: str = "Passphrase for the private key: ",
    allow_empty: bool = False,
) -> Optional[bytes]:
    """Obtain a passphrase without it ever appearing in a command line.

    Order: ``--password-env`` (for CI), then ``--password-file`` (for a secret
    mounted by an orchestrator), then an interactive prompt. Never argv.
    """
    if env_var:
        value = os.environ.get(env_var)
        if value is None:
            raise KeyCustodyError(
                f"environment variable {env_var!r} is not set, so there is no passphrase to use"
            )
        return value.encode("utf-8")

    if file_path:
        data = pathlib.Path(file_path).read_bytes()
        # A trailing newline from `echo` is the classic silent mismatch.
        return data.rstrip(b"\r\n")

    if not sys.stdin.isatty():
        if allow_empty:
            return None
        raise KeyCustodyError(
            "no passphrase source and no terminal to prompt on; use --password-env "
            "or --password-file (never --password, which leaks via the process list)"
        )

    first = getpass.getpass(prompt)
    if not first:
        if allow_empty:
            return None
        raise KeyCustodyError("empty passphrase")
    if len(first) < _MIN_PASSPHRASE:
        raise KeyCustodyError(
            f"passphrase must be at least {_MIN_PASSPHRASE} characters; this one "
            "would be trivially recoverable from the key file offline"
        )
    if confirm:
        second = getpass.getpass("Repeat passphrase: ")
        if first != second:
            raise KeyCustodyError("passphrases do not match")
    return first.encode("utf-8")


# --------------------------------------------------------------------------
# writing
# --------------------------------------------------------------------------

def write_private_key(
    private_key,
    path,
    passphrase: Optional[bytes],
    *,
    allow_plaintext: bool = False,
    encoding: str = "der",
    overwrite: bool = False,
) -> pathlib.Path:
    """Write a private key, encrypted unless explicitly told otherwise."""
    path = pathlib.Path(path)
    if path.exists() and not overwrite:
        raise KeyCustodyError(
            f"{path} already exists. Overwriting a signing key destroys the ability "
            "to sign as that identity ever again, and there is no recovery; move it "
            "aside deliberately if that is what you want."
        )
    if not passphrase:
        if not allow_plaintext:
            raise KeyCustodyError(
                "refusing to write an unencrypted private key. Supply a passphrase, "
                f"use a device-held key (framesig tpm), or pass {PLAINTEXT_OPT_IN} "
                "if you genuinely want a key anyone who reads the file can forge with."
            )
        encryption = serialization.NoEncryption()
    else:
        encryption = serialization.BestAvailableEncryption(passphrase)

    enc = (
        serialization.Encoding.DER if encoding == "der" else serialization.Encoding.PEM
    )
    blob = private_key.private_bytes(
        encoding=enc,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=encryption,
    )

    path.parent.mkdir(parents=True, exist_ok=True)
    # A fresh 0600 file renamed into place. Opening *path* with O_TRUNC would
    # write the key into whatever already sits there: a symlink's target, or a
    # file someone else pre-created and can still read.
    atomic_write(path, blob, 0o600)
    return path


# --------------------------------------------------------------------------
# reading
# --------------------------------------------------------------------------

def _looks_encrypted(blob: bytes) -> bool:
    """Is this key file encrypted?  Determined from its structure, not by
    guessing from exception types.

    ``load_pem_private_key`` raises ``TypeError`` when a passphrase is needed,
    but ``load_der_private_key`` raises ``ValueError`` with an ASN.1 parse
    error instead -- indistinguishable from a genuinely corrupt file. Sniffing
    the structure keeps "encrypted" and "damaged" apart, which matters because
    one is fixed by typing a passphrase and the other by restoring a backup.

    PKCS#8 unencrypted is ``SEQUENCE { INTEGER version, AlgorithmIdentifier,
    OCTET STRING }``; encrypted is ``SEQUENCE { AlgorithmIdentifier, OCTET
    STRING }``. So the first child being an INTEGER means unencrypted.
    """
    stripped = blob.lstrip()
    if stripped.startswith(b"-----BEGIN"):
        first_line = stripped.split(b"\n", 1)[0]
        return b"ENCRYPTED" in first_line

    if not blob or blob[0] != 0x30:
        return False
    pos = 1
    length = blob[pos]
    pos += 1
    if length & 0x80:
        pos += length & 0x7F
    return pos < len(blob) and blob[pos] != 0x02  # 0x02 = INTEGER = unencrypted


def read_private_key(path, passphrase: Optional[bytes] = None):
    """Load a private key from PEM or DER, encrypted or not.

    Reports whether the file was encrypted, so callers can warn about a key that
    is sitting on disk in the clear.
    """
    path = pathlib.Path(path)
    blob = path.read_bytes()
    is_pem = blob.lstrip().startswith(b"-----BEGIN")
    loader = (
        serialization.load_pem_private_key if is_pem else serialization.load_der_private_key
    )
    encrypted = _looks_encrypted(blob)

    if encrypted and passphrase is None:
        raise PassphraseRequired(f"{path} is encrypted; a passphrase is required")
    try:
        key = loader(blob, password=passphrase if encrypted else None)
    except (TypeError, ValueError) as exc:
        raise KeyCustodyError(f"could not load {path}: {exc}") from exc

    algorithm_of(key.public_key())  # reject unsupported key types early
    return key, encrypted


def check_key_file_permissions(path) -> Optional[str]:
    """Return a warning if others can read the key file, else None."""
    path = pathlib.Path(path)
    try:
        mode = path.stat().st_mode
    except OSError:  # pragma: no cover
        return None
    if os.name == "nt":
        # Windows ACLs are not represented in st_mode; a meaningful check needs
        # icacls. Saying nothing is better than a false reassurance.
        return None
    if mode & (stat.S_IRGRP | stat.S_IROTH):
        return (
            f"{path} is readable by other users (mode {oct(mode & 0o777)}); "
            "an encrypted key still hands an offline attacker unlimited guesses"
        )
    return None


def load_private_key_for(path, *, env_var=None, file_path=None, prompt=None):
    """Load a key, prompting for a passphrase only if one is actually needed.

    Prompting unconditionally is how an unattended command silently hangs
    forever waiting on a terminal nobody is watching, so the encrypted case has
    to be discovered rather than assumed.
    """
    try:
        return read_private_key(path, None)
    except PassphraseRequired:
        pass
    passphrase = resolve_passphrase(
        env_var=env_var,
        file_path=file_path,
        prompt=prompt or f"Passphrase for {pathlib.Path(path).name}: ",
    )
    return read_private_key(path, passphrase)
