"""Folder browser with per-frame validation badges and a diffraction viewer.

    framesig view /path/to/frames --trust vendor-root.pem
    framesig view dataset.framebundle

Badges follow *origin*, not integrity:

    green tick   an instrument attests it produced this frame
    amber "?"    no evidence of origin -- unsigned, or signed only by whoever
                 produced the file
    red cross    signed, but the signature disagrees with the contents

The amber state covers two different situations on purpose. An unsigned frame
and a self-signed frame carry exactly the same amount of evidence about where
they came from, and a fabricator reaches the second for free. Neither is a
detected forgery, so neither is red; neither is proof, so neither is green.

Rendered with Tkinter and nothing else, so it runs on a stock Python. numpy is
used when present, purely for speed on multi-megapixel frames.
"""

from __future__ import annotations

import base64
import math
import pathlib
import queue
import struct
import threading
import zlib
from typing import Dict, List, Optional, Sequence, Tuple

from .api import verify_data, verify_file
from .display import (
    COLORMAPS,
    DEFAULT_COLORMAP,
    DEFAULT_SIGMA_FACTOR,
    DEFAULT_STRETCH,
    MASKED_COLOUR,
    STRETCHES,
    apply_stretch,
    colormap_lut,
    robust_window,
)
from .formats import adapter_for
from .formats.base import FormatError

__all__ = ["run_viewer", "load_frame_values", "render_png"]

FRAME_SUFFIXES = (".cbf", ".img", ".mccd", ".mar", ".osc")

STATE_VALID = "valid"
STATE_UNSIGNED = "unsigned"
STATE_BAD = "bad"
STATE_PENDING = "pending"

_COLOURS = {
    STATE_VALID: "#1a9850",
    STATE_UNSIGNED: "#e8a317",
    STATE_BAD: "#d7191c",
    STATE_PENDING: "#9aa0a6",
}

_LABEL = {
    STATE_VALID: "instrument-attested",
    STATE_UNSIGNED: "no origin evidence",
    STATE_BAD: "SIGNATURE DISAGREES",
    STATE_PENDING: "checking...",
}


# --------------------------------------------------------------------------
# badge rasteriser -- geometry only, no image files to ship or lose
# --------------------------------------------------------------------------

def _dist_to_segment(px, py, ax, ay, bx, by) -> float:
    vx, vy = bx - ax, by - ay
    wx, wy = px - ax, py - ay
    L2 = vx * vx + vy * vy
    t = 0.0 if L2 == 0 else max(0.0, min(1.0, (wx * vx + wy * vy) / L2))
    dx, dy = wx - t * vx, wy - t * vy
    return math.hypot(dx, dy)


def _glyph_hit(state: str, x: float, y: float) -> bool:
    """Is normalised point (x, y) inside the state's glyph? y grows downward."""
    w = 0.115
    if state == STATE_VALID:
        return (
            _dist_to_segment(x, y, -0.34, 0.02, -0.09, 0.26) <= w
            or _dist_to_segment(x, y, -0.09, 0.26, 0.36, -0.30) <= w
        )
    if state == STATE_BAD:
        return (
            _dist_to_segment(x, y, -0.28, -0.28, 0.28, 0.28) <= w
            or _dist_to_segment(x, y, -0.28, 0.28, 0.28, -0.28) <= w
        )
    if state == STATE_UNSIGNED:
        cx, cy, r = 0.0, -0.17, 0.215
        d = math.hypot(x - cx, y - cy)
        if abs(d - r) <= w:
            ang = math.degrees(math.atan2(y - cy, x - cx)) % 360.0
            if 170.0 <= ang <= 360.0 or ang <= 25.0:
                return True
        if _dist_to_segment(x, y, 0.195, -0.08, 0.02, 0.15) <= w:
            return True
        return math.hypot(x - 0.02, y - 0.33) <= 0.115
    return False  # pending: a plain disc


def _badge_rows(state: str, size: int, supersample: int = 4) -> List[List[str]]:
    fg = (255, 255, 255)
    bg = _COLOURS[state]
    br, bgc, bb = int(bg[1:3], 16), int(bg[3:5], 16), int(bg[5:7], 16)
    rows: List[List[str]] = []
    half = size / 2.0
    ss2 = supersample * supersample
    for py in range(size):
        row: List[str] = []
        for px in range(size):
            disc = glyph = 0
            for sy in range(supersample):
                for sx in range(supersample):
                    nx = ((px + (sx + 0.5) / supersample) - half) / half
                    ny = ((py + (sy + 0.5) / supersample) - half) / half
                    if nx * nx + ny * ny <= 0.94 * 0.94:
                        disc += 1
                        if _glyph_hit(state, nx, ny):
                            glyph += 1
            if disc == 0:
                row.append("#f5f5f5")
                continue
            a_disc, a_glyph = disc / ss2, glyph / ss2
            r = br * (1 - a_glyph) + fg[0] * a_glyph
            g = bgc * (1 - a_glyph) + fg[1] * a_glyph
            b = bb * (1 - a_glyph) + fg[2] * a_glyph
            r = 245 * (1 - a_disc) + r * a_disc
            g = 245 * (1 - a_disc) + g * a_disc
            b = 245 * (1 - a_disc) + b * a_disc
            row.append("#%02x%02x%02x" % (int(r), int(g), int(b)))
        rows.append(row)
    return rows


def _make_badge(state: str, size: int):
    import tkinter as tk

    img = tk.PhotoImage(width=size, height=size)
    img.put([" ".join(row) for row in _badge_rows(state, size)])
    return img


# --------------------------------------------------------------------------
# decoding and rendering
# --------------------------------------------------------------------------

def load_frame_values(source) -> Tuple[Sequence[int], int, int]:
    """Decode the first payload of a frame given as bytes or a path."""
    data = source if isinstance(source, (bytes, bytearray)) else pathlib.Path(source).read_bytes()
    adapter = adapter_for(data)
    layout = adapter.parse(data)
    if not layout.payloads:
        raise FormatError("no binary payload found in this file")
    p = layout.payloads[0]
    if len(p.dimensions) < 2:
        raise FormatError("payload does not declare two image dimensions")
    width, height = p.dimensions[0], p.dimensions[1]

    form, chunks = adapter.canonical_payload_stream(data[: layout.signed_length], p)
    if form != "int64-le":
        raise FormatError(f"cannot display payloads of canonical form {form!r}")
    raw = b"".join(chunks)
    try:
        import numpy as np

        values = np.frombuffer(raw, dtype="<i8")
    except ImportError:
        values = struct.unpack("<%dq" % (len(raw) // 8), raw)
    return values, width, height


def _downsample(values, width: int, height: int, target: int):
    """Max-pool to fit *target* pixels.

    Max rather than mean: averaging a 2500-pixel frame down to 900 dilutes
    single-pixel Bragg peaks into the background and the image looks empty.
    Max-pooling keeps every spot visible, at the cost of exaggerating hot
    pixels -- the right trade for "does this look like a diffraction pattern".
    """
    step = max(1, int(math.ceil(max(width, height) / float(target))))
    ow, oh = (width + step - 1) // step, (height + step - 1) // step
    try:
        import numpy as np

        arr = np.asarray(values).reshape(height, width)
        ph, pw = oh * step - height, ow * step - width
        if ph or pw:
            arr = np.pad(arr, ((0, ph), (0, pw)), mode="edge")
        return arr.reshape(oh, step, ow, step).max(axis=(1, 3)), ow, oh
    except ImportError:
        out = [[-(2**62)] * ow for _ in range(oh)]
        for y in range(height):
            row = out[y // step]
            base = y * width
            for x in range(width):
                ox = x // step
                v = values[base + x]
                if v > row[ox]:
                    row[ox] = v
        return out, ow, oh


def _png(rgb: bytes, width: int, height: int) -> bytes:
    """Minimal PNG encoder.

    Tk 8.6 accepts base64 PNG through ``PhotoImage(data=...)`` but not base64
    PPM, and 25 lines of zlib is cheaper than depending on Pillow for a viewer
    whose selling point is that it installs anywhere.
    """
    stride = width * 3
    raw = b"".join(b"\x00" + rgb[y * stride : (y + 1) * stride] for y in range(height))

    def chunk(tag: bytes, data: bytes) -> bytes:
        body = tag + data
        return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body))

    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(raw, 6))
        + chunk(b"IEND", b"")
    )


def render_png(
    values,
    width: int,
    height: int,
    *,
    target: int = 900,
    window: Optional[Tuple[float, float]] = None,
    colormap: str = DEFAULT_COLORMAP,
    stretch: str = DEFAULT_STRETCH,
    sigma_factor: float = DEFAULT_SIGMA_FACTOR,
) -> Tuple[bytes, int, int, Tuple[float, float]]:
    """Render a frame. Returns ``(png, out_w, out_h, window_used)``."""
    grid, ow, oh = _downsample(values, width, height, target)
    low, high = window if window is not None else robust_window(grid, sigma_factor)
    span = (high - low) or 1.0
    lut = colormap_lut(colormap)

    try:
        import numpy as np

        arr = np.asarray(grid, dtype="float64")
        mask = arr < 0
        norm = np.clip((arr - low) / span, 0.0, 1.0)
        if stretch == "linear":
            curved = norm
        elif stretch == "sqrt":
            curved = np.sqrt(norm)
        else:
            curved = np.log1p(999.0 * norm) / math.log(1000.0)
        idx = np.clip((curved * 255.0).astype("int32"), 0, 255)
        table = np.asarray(lut, dtype="uint8")
        rgb = table[idx]
        rgb[mask] = MASKED_COLOUR
        body = rgb.tobytes()
    except ImportError:
        out = bytearray()
        for row in grid:
            for v in row:
                if v < 0:
                    out += bytes(MASKED_COLOUR)
                    continue
                t = apply_stretch((v - low) / span, stretch)
                out += bytes(lut[max(0, min(255, int(t * 255.0)))])
        body = bytes(out)

    return _png(body, ow, oh), ow, oh, (low, high)


def render_legend_png(
    colormap: str, stretch: str, width: int = 26, height: int = 260
) -> bytes:
    """The colour ramp, drawn top = bright, as a strip the user can drag."""
    lut = colormap_lut(colormap)
    rows = []
    for y in range(height):
        t = apply_stretch(1.0 - (y / (height - 1)), stretch)
        colour = bytes(lut[max(0, min(255, int(t * 255.0)))])
        rows.append(colour * width)
    return _png(b"".join(rows), width, height)


# --------------------------------------------------------------------------
# frame sources: a folder, or a single-file bundle
# --------------------------------------------------------------------------

class FolderSource:
    """Frames on disk, walked recursively."""

    def __init__(self, folder):
        self.root = pathlib.Path(folder)
        self.container = None
        self.bundle_envelope = None

    @property
    def label(self) -> str:
        return str(self.root)

    def list(self) -> List[str]:
        if not self.root.is_dir():
            return []
        found = [
            p for p in self.root.rglob("*")
            if p.is_file() and p.suffix.lower() in FRAME_SUFFIXES
        ]
        return sorted(
            (str(p.relative_to(self.root)).replace("\\", "/") for p in found),
            key=lambda s: [part.lower() for part in s.split("/")],
        )

    def read(self, key: str) -> bytes:
        return (self.root / key).read_bytes()

    def verify(self, key: str, roots, public_keys):
        return verify_file(self.root / key, roots=roots, public_key_paths=public_keys)

    def read_and_verify(self, key: str, roots, public_keys):
        """One read, used for both the verdict and the picture."""
        from .keys import load_public_key

        data = (self.root / key).read_bytes()
        sidecar = None
        sidecar_path = pathlib.Path(str(self.root / key) + ".framesig")
        if sidecar_path.exists():
            import json

            try:
                sidecar = json.loads(sidecar_path.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                sidecar = None
        keys = [load_public_key(pathlib.Path(k).read_bytes()) for k in public_keys]
        return data, verify_data(data, roots=roots, public_keys=keys, sidecar=sidecar)


class ContainerSource:
    """Frames inside a ``.framebundle``, read without extracting anything."""

    def __init__(self, path):
        from .container import open_container

        self.path = pathlib.Path(path)
        self.container = open_container(path)
        self.bundle_envelope = self.container.envelope

    @property
    def label(self) -> str:
        return f"{self.path.name} (bundle)"

    def list(self) -> List[str]:
        return sorted(
            self.container.frame_names,
            key=lambda s: [part.lower() for part in s.split("/")],
        )

    def read(self, key: str) -> bytes:
        return self.container.read_frame(key)

    def verify(self, key: str, roots, public_keys):
        return self.read_and_verify(key, roots, public_keys)[1]

    def read_and_verify(self, key: str, roots, public_keys):
        """One read, used for both the verdict and the picture."""
        from .keys import load_public_key

        data = self.container.read_frame(key)
        keys = [load_public_key(pathlib.Path(k).read_bytes()) for k in public_keys]
        return data, verify_data(data, roots=roots, public_keys=keys)


def make_source(target):
    from .container import is_container

    path = pathlib.Path(target)
    if path.is_file() and is_container(path):
        return ContainerSource(path)
    return FolderSource(path)


# --------------------------------------------------------------------------
# the application
# --------------------------------------------------------------------------

class ViewerApp:
    def __init__(self, root, folder: str, trust: Sequence[str], public_keys: Sequence[str]):
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self.ttk = ttk
        self.root = root
        self.trust_paths = list(trust)
        self.public_keys = list(public_keys)
        self.roots = self._load_roots()
        self.results: Dict[str, object] = {}
        self.files: List[str] = []
        self._dir_nodes: Dict[str, dict] = {}
        self._queue: "queue.Queue" = queue.Queue()
        self._photo = None
        self._legend_photo = None
        self._values = None
        self._dims = (0, 0)
        self._generation = 0
        self._drag = None

        # Display state. `window` is None until the first frame sets it from
        # the data; `auto` means "recompute the window for each new frame".
        self.cmap = DEFAULT_COLORMAP
        self.stretch = DEFAULT_STRETCH
        self.sigma_factor = DEFAULT_SIGMA_FACTOR
        self.window: Optional[Tuple[float, float]] = None
        self.auto = True

        try:
            self.source = make_source(folder)
        except Exception as exc:  # noqa: BLE001
            self.source = FolderSource(folder)
            print(f"could not open {folder} as a bundle: {exc}")

        root.title("framesig - frame authenticity viewer")
        root.geometry("1280x820")
        self.badges = {s: _make_badge(s, 18) for s in _COLOURS}
        self.big_badges = {s: _make_badge(s, 56) for s in _COLOURS}

        self._build_ui()
        self.reload()

    # -- construction ------------------------------------------------------

    def _build_ui(self):
        tk, ttk = self.tk, self.ttk

        bar = ttk.Frame(self.root, padding=(8, 6))
        bar.pack(fill="x")
        ttk.Button(bar, text="Open folder...", command=self.choose_folder).pack(side="left")
        ttk.Button(bar, text="Open bundle...", command=self.choose_bundle).pack(
            side="left", padx=(6, 0)
        )
        ttk.Button(bar, text="Re-verify", command=self.reload).pack(side="left", padx=(6, 0))
        ttk.Button(bar, text="Trust anchor...", command=self.choose_trust).pack(
            side="left", padx=(6, 0)
        )
        self.path_var = tk.StringVar(value=self.source.label)
        ttk.Label(bar, textvariable=self.path_var, foreground="#555").pack(
            side="left", padx=(14, 0)
        )
        self.trust_var = tk.StringVar(value=self._trust_label())
        ttk.Label(bar, textvariable=self.trust_var, foreground="#777").pack(side="right")

        panes = ttk.PanedWindow(self.root, orient="horizontal")
        panes.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        left = ttk.Frame(panes)
        self.tree = ttk.Treeview(left, columns=("state",), show="tree headings", height=28)
        self.tree.heading("#0", text="frame")
        self.tree.heading("state", text="status")
        self.tree.column("#0", width=250, stretch=True)
        self.tree.column("state", width=155, stretch=False)
        sb = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        panes.add(left, weight=1)

        right = ttk.Frame(panes)

        # -- display controls ------------------------------------------------
        controls = ttk.Frame(right, padding=(0, 4))
        controls.pack(fill="x")
        ttk.Label(controls, text="colour").pack(side="left")
        self.cmap_var = tk.StringVar(value=self.cmap)
        cmap_box = ttk.Combobox(
            controls, textvariable=self.cmap_var, width=9, state="readonly",
            values=list(COLORMAPS),
        )
        cmap_box.pack(side="left", padx=(4, 12))
        cmap_box.bind("<<ComboboxSelected>>", self._on_display_change)

        ttk.Label(controls, text="stretch").pack(side="left")
        self.stretch_var = tk.StringVar(value=self.stretch)
        stretch_box = ttk.Combobox(
            controls, textvariable=self.stretch_var, width=7, state="readonly",
            values=list(STRETCHES),
        )
        stretch_box.pack(side="left", padx=(4, 12))
        stretch_box.bind("<<ComboboxSelected>>", self._on_display_change)

        ttk.Button(controls, text="Auto", command=self.reset_window).pack(side="left")
        self.window_var = tk.StringVar(value="")
        ttk.Label(controls, textvariable=self.window_var, foreground="#777").pack(
            side="left", padx=(12, 0)
        )

        # -- image + legend --------------------------------------------------
        image_row = ttk.Frame(right)
        image_row.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(image_row, background="#101010", highlightthickness=0)
        self.canvas.pack(side="left", fill="both", expand=True)

        legend_col = ttk.Frame(image_row, padding=(6, 4))
        legend_col.pack(side="right", fill="y")
        self.legend_top = ttk.Label(legend_col, text="", font=("Consolas", 8))
        self.legend_top.pack()
        self.legend = tk.Canvas(legend_col, width=26, height=260, highlightthickness=1,
                                highlightbackground="#555", cursor="sb_v_double_arrow")
        self.legend.pack(pady=2)
        self.legend_bottom = ttk.Label(legend_col, text="", font=("Consolas", 8))
        self.legend_bottom.pack()
        ttk.Label(legend_col, text="drag: shift\nctrl-drag: contrast\nwheel: contrast\n"
                                   "double-click: auto",
                  font=("Segoe UI", 7), foreground="#888", justify="center").pack(pady=(6, 0))

        self.legend.bind("<ButtonPress-1>", self._legend_press)
        self.legend.bind("<B1-Motion>", self._legend_drag)
        self.legend.bind("<ButtonRelease-1>", lambda e: setattr(self, "_drag", None))
        self.legend.bind("<Control-ButtonPress-1>", self._legend_press)
        self.legend.bind("<Control-B1-Motion>", self._legend_contrast_drag)
        self.legend.bind("<Double-Button-1>", lambda e: self.reset_window())
        self.legend.bind("<MouseWheel>", self._legend_wheel)
        self.legend.bind("<Button-4>", lambda e: self._legend_wheel(e, 1))
        self.legend.bind("<Button-5>", lambda e: self._legend_wheel(e, -1))

        self.canvas_note = tk.Label(self.canvas, text="", bg="#101010", fg="#8b9199",
                                    font=("Consolas", 8))

        # -- verdict ---------------------------------------------------------
        self.summary_var = tk.StringVar(value="")
        head = ttk.Frame(right, padding=(0, 6))
        head.pack(fill="x")
        self.badge_label = ttk.Label(head)
        self.badge_label.pack(side="left")
        ttk.Label(head, textvariable=self.summary_var, font=("Segoe UI", 11, "bold")).pack(
            side="left", padx=(10, 0)
        )
        self.detail = tk.Text(right, height=11, wrap="word", font=("Consolas", 9),
                              background="#fafafa", relief="flat")
        self.detail.pack(fill="x")
        panes.add(right, weight=3)

        self.status_var = tk.StringVar(value="")
        ttk.Label(self.root, textvariable=self.status_var, anchor="w",
                  padding=(10, 3)).pack(fill="x")
        self._draw_legend()

    def _trust_label(self) -> str:
        if self.roots:
            return f"trust anchors: {len(self.roots)}"
        if self.public_keys:
            return f"pinned keys: {len(self.public_keys)}"
        return "no trust anchor - origin cannot be established"

    def _load_roots(self):
        from .pki import load_certificates_pem

        roots = []
        for p in self.trust_paths:
            try:
                roots.extend(load_certificates_pem(pathlib.Path(p).read_bytes()))
            except (OSError, ValueError):
                pass
        return roots

    # -- display controls --------------------------------------------------

    def _on_display_change(self, _event=None):
        self.cmap = self.cmap_var.get()
        self.stretch = self.stretch_var.get()
        self._draw_legend()
        self._render()

    def reset_window(self):
        self.auto = True
        self.window = None
        self._render()

    def _draw_legend(self):
        png = render_legend_png(self.cmap, self.stretch)
        self._legend_photo = self.tk.PhotoImage(data=base64.b64encode(png).decode("ascii"))
        self.legend.delete("all")
        self.legend.create_image(0, 0, image=self._legend_photo, anchor="nw")

    def _legend_press(self, event):
        if self.window is None:
            return
        self._drag = (event.y, self.window[0], self.window[1])

    def _legend_drag(self, event):
        """Drag the ramp: slide the whole window, i.e. brightness."""
        if not self._drag or self.window is None:
            return
        y0, low0, high0 = self._drag
        span = high0 - low0
        # Dragging the ramp *up* should brighten, which means lowering the
        # window: the same counts land higher on the colour bar.
        shift = ((event.y - y0) / max(1, int(self.legend["height"]))) * span
        self.auto = False
        self.window = (low0 + shift, high0 + shift)
        self._render()

    def _legend_contrast_drag(self, event):
        """Ctrl-drag: widen or narrow the window about its centre."""
        if not self._drag or self.window is None:
            return
        y0, low0, high0 = self._drag
        centre = (low0 + high0) / 2.0
        half = (high0 - low0) / 2.0
        factor = math.exp((event.y - y0) / 90.0)
        self.auto = False
        self.window = (centre - half * factor, centre + half * factor)
        self._render()

    def _legend_wheel(self, event, direction=None):
        if self.window is None:
            return
        if direction is None:
            direction = 1 if event.delta > 0 else -1
        low, high = self.window
        centre = (low + high) / 2.0
        half = (high - low) / 2.0 * (0.88 if direction > 0 else 1.0 / 0.88)
        self.auto = False
        self.window = (centre - half, centre + half)
        self._render()

    # -- actions -----------------------------------------------------------

    def choose_folder(self):
        from tkinter import filedialog

        chosen = filedialog.askdirectory()
        if chosen:
            self.source = FolderSource(chosen)
            self.path_var.set(self.source.label)
            self.reload()

    def choose_bundle(self):
        from tkinter import filedialog, messagebox

        chosen = filedialog.askopenfilename(
            title="Open a signed bundle",
            filetypes=[("framesig bundle", "*.framebundle *.zip"), ("All files", "*.*")],
        )
        if not chosen:
            return
        try:
            self.source = ContainerSource(chosen)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Cannot open bundle", str(exc))
            return
        self.path_var.set(self.source.label)
        self.reload()

    def choose_trust(self):
        from tkinter import filedialog

        chosen = filedialog.askopenfilename(
            title="Vendor root certificate (PEM)",
            filetypes=[("PEM certificate", "*.pem *.crt *.cer"), ("All files", "*.*")],
        )
        if chosen:
            self.trust_paths = [chosen]
            self.roots = self._load_roots()
            self.trust_var.set(self._trust_label())
            self.reload()

    def reload(self):
        self._generation += 1
        generation = self._generation
        self.results.clear()
        self.tree.delete(*self.tree.get_children())
        self._dir_nodes = {}
        try:
            self.files = self.source.list()
        except Exception as exc:  # noqa: BLE001
            self.files = []
            self.status_var.set(f"could not read {self.source.label}: {exc}")
            return
        self._insert_tree(self.files)
        self.status_var.set(f"{len(self.files)} frame(s); verifying...")
        if not self.files:
            self.status_var.set(f"no frames found in {self.source.label}")
            return

        self._worker = threading.Thread(
            target=self._verify_all, args=(list(self.files), generation), daemon=True
        )
        self._worker.start()
        self.root.after(60, self._drain)
        self.tree.selection_set(self.files[0])

    # -- tree --------------------------------------------------------------

    def _ensure_dir_node(self, relative: str) -> str:
        if relative in ("", "."):
            return ""
        if relative in self._dir_nodes:
            return relative
        parent = self._ensure_dir_node(relative.rsplit("/", 1)[0] if "/" in relative else "")
        self.tree.insert(parent, "end", iid=relative, text=relative.rsplit("/", 1)[-1],
                         values=("",), open=True)
        self._dir_nodes[relative] = {"files": []}
        return relative

    def _insert_tree(self, keys: List[str]) -> None:
        for key in keys:
            parent_path = key.rsplit("/", 1)[0] if "/" in key else ""
            parent = self._ensure_dir_node(parent_path)
            self.tree.insert(
                parent, "end", iid=key, text=key.rsplit("/", 1)[-1],
                values=(_LABEL[STATE_PENDING],), image=self.badges[STATE_PENDING],
            )
            ancestor = parent_path
            while ancestor:
                self._dir_nodes[ancestor]["files"].append(key)
                ancestor = ancestor.rsplit("/", 1)[0] if "/" in ancestor else ""

    def _update_dir_tallies(self) -> None:
        """Folders get a count, never a badge.

        Rolling a subtree up into one worst-case icon would say "this run is
        tampered" when one frame of nine hundred failed -- a much stronger
        claim than the evidence supports.
        """
        for key, info in self._dir_nodes.items():
            counts = {}
            for path in info["files"]:
                s = self._state_of(self.results.get(path))
                counts[s] = counts.get(s, 0) + 1
            parts = []
            for s, word in (
                (STATE_VALID, "attested"), (STATE_UNSIGNED, "unattested"), (STATE_BAD, "failing")
            ):
                if counts.get(s):
                    parts.append(f"{counts[s]} {word}")
            if counts.get(STATE_PENDING):
                parts.append("checking...")
            if self.tree.exists(key):
                self.tree.item(key, values=(", ".join(parts) or "empty",))

    def _verify_all(self, keys, generation):
        for key in keys:
            try:
                result = self.source.verify(key, self.roots, self.public_keys)
            except Exception as exc:  # noqa: BLE001 - a viewer must not die on one file
                result = exc
            self._queue.put((generation, key, result))
        self._queue.put((generation, None, None))

    def _drain(self):
        done = False
        while True:
            try:
                generation, key, result = self._queue.get_nowait()
            except queue.Empty:
                break
            if generation != self._generation:
                continue
            if key is None:
                done = True
                continue
            self.results[key] = result
            state = self._state_of(result)
            if self.tree.exists(key):
                self.tree.item(key, values=(_LABEL[state],), image=self.badges[state])
            if self.tree.selection() and self.tree.selection()[0] == key:
                self._show_details(key)
        self._update_dir_tallies()
        if done:
            counts = {}
            for r in self.results.values():
                s = self._state_of(r)
                counts[s] = counts.get(s, 0) + 1
            self.status_var.set(
                f"{len(self.files)} frame(s):  "
                f"{counts.get(STATE_VALID, 0)} instrument-attested,  "
                f"{counts.get(STATE_UNSIGNED, 0)} without origin evidence,  "
                f"{counts.get(STATE_BAD, 0)} failing"
            )
        else:
            self.root.after(60, self._drain)

    @staticmethod
    def _state_of(result) -> str:
        """The badge follows *origin*, not integrity.

        Green for "the signature verifies" would be exactly wrong: a fabricated
        frame signed with a self-generated key verifies perfectly. Green means
        an instrument attests it produced the frame.
        """
        if isinstance(result, Exception):
            return STATE_BAD
        if result is None:
            return STATE_PENDING
        if not result.intact:
            return STATE_UNSIGNED if result.status == "unsigned" else STATE_BAD
        return STATE_VALID if result.ok else STATE_UNSIGNED

    # -- display -----------------------------------------------------------

    def on_select(self, _event=None):
        sel = self.tree.selection()
        if not sel or sel[0] in self._dir_nodes:
            return
        key = sel[0]
        self._show_details(key)
        self._load_image(key)

    def _show_details(self, key: str):
        result = self.results.get(key)
        state = self._state_of(result)
        self.badge_label.configure(image=self.big_badges[state])
        self.badge_label.image = self.big_badges[state]

        self.detail.delete("1.0", "end")
        if result is None:
            self.summary_var.set("checking...")
            return
        if isinstance(result, Exception):
            self.summary_var.set("could not be checked")
            self.detail.insert("end", f"{type(result).__name__}: {result}\n")
            return

        self.summary_var.set(f"{key.rsplit('/', 1)[-1]} - {_LABEL[state]}")
        lines = [result.summary()]
        m = result.manifest or {}
        if m.get("claims"):
            lines.append("")
            lines.append("signed claims:")
            for k, v in sorted(m["claims"].items()):
                lines.append(f"    {k} = {v}")
        if state == STATE_UNSIGNED and result.status == "unsigned":
            lines.append("")
            lines.append(
                "An unsigned frame is not suspicious in itself - virtually every\n"
                "frame recorded to date is unsigned.  It simply carries no evidence\n"
                "of where it came from."
            )
        elif state == STATE_UNSIGNED:
            lines.append("")
            lines.append(
                "The bytes are unchanged since signing - but that is all.  This\n"
                "signature does not establish that the frame came from an\n"
                "instrument, so it does not rule out a simulated or generated\n"
                "image.  Anyone who can produce a frame can also produce a\n"
                "signature for it."
            )
        elif state == STATE_VALID:
            lines.append("")
            lines.append(
                "A manufacturer-provisioned key inside the instrument attests that\n"
                "this frame was produced by a physical exposure."
            )
        self.detail.insert("end", "\n".join(lines))

    def _load_image(self, key: str):
        """Render the bytes that were verified, never a second read.

        Reading again for display would let the file change in between, and the
        viewer would then show one image beside another image's badge -- a green
        tick over a picture nobody checked. Under this threat model that is the
        precise deception the tool exists to prevent, so the selected frame is
        read once and both the verdict and the picture come from that read.
        """
        self._values = None
        try:
            data, result = self.source.read_and_verify(key, self.roots, self.public_keys)
            self.results[key] = result
            state = self._state_of(result)
            if self.tree.exists(key):
                self.tree.item(key, values=(_LABEL[state],), image=self.badges[state])
            self._show_details(key)
            self._values, w, h = load_frame_values(data)
            self._dims = (w, h)
        except Exception as exc:  # noqa: BLE001
            self.canvas.delete("all")
            self.canvas.create_text(
                20, 20, anchor="nw", fill="#bbb",
                text=f"cannot render this frame:\n{type(exc).__name__}: {exc}",
            )
            self.window_var.set("")
            return
        if self.auto:
            self.window = None
        self._render()

    def _render(self):
        if self._values is None:
            return
        w, h = self._dims
        try:
            png, ow, oh, used = render_png(
                self._values, w, h,
                window=self.window,
                colormap=self.cmap,
                stretch=self.stretch,
                sigma_factor=self.sigma_factor,
            )
        except Exception as exc:  # noqa: BLE001
            self.canvas.delete("all")
            self.canvas.create_text(20, 20, anchor="nw", fill="#bbb", text=str(exc))
            return
        self.window = used
        self._photo = self.tk.PhotoImage(data=base64.b64encode(png).decode("ascii"))
        self.canvas.delete("all")
        self.canvas.create_image(
            self.canvas.winfo_width() // 2 or 420,
            self.canvas.winfo_height() // 2 or 320,
            image=self._photo, anchor="center",
        )
        self.canvas.create_text(
            8, 8, anchor="nw", fill="#8a8a8a",
            text=f"{w} x {h}  (shown {ow} x {oh}, max-pooled)",
        )
        low, high = used
        self.legend_top.configure(text=f"{high:,.0f}")
        self.legend_bottom.configure(text=f"{low:,.0f}")
        self.window_var.set(
            f"window {low:,.0f} .. {high:,.0f}" + ("  (auto)" if self.auto else "")
        )


def run_viewer(folder: str = ".", trust: Sequence[str] = (), public_keys: Sequence[str] = ()) -> int:
    try:
        import tkinter as tk
    except ImportError:
        print(
            "the viewer needs tkinter, which this Python was built without.\n"
            "Use 'framesig verify' for the command line report instead."
        )
        return 1
    root = tk.Tk()
    try:
        from tkinter import ttk

        ttk.Style().theme_use("vista")
    except Exception:  # noqa: BLE001 - theme is cosmetic
        pass
    ViewerApp(root, folder, trust, public_keys)
    root.mainloop()
    return 0
