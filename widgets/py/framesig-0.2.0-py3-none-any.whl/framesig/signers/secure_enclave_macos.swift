// Secure Enclave helper for framesig (macOS). Compiled once by
// secure_enclave_macos.py; see that module for the why.
//
//   helper available
//   helper create <blob>          -> writes the key blob, prints base64 X9.63 public key
//   helper public <blob>          -> prints base64 X9.63 public key
//   helper sign <blob> <message>  -> prints base64 DER ECDSA signature over SHA-256(message)
//
// The blob is the Secure Enclave's own wrapped key: usable only by this
// machine's enclave, so it is not a private key file in any useful sense.

import CryptoKit
import Foundation

func fail(_ msg: String) -> Never {
    FileHandle.standardError.write((msg + "\n").data(using: .utf8)!)
    exit(1)
}

func load(_ path: String) -> SecureEnclave.P256.Signing.PrivateKey {
    guard let blob = FileManager.default.contents(atPath: path) else { fail("cannot read \(path)") }
    do { return try SecureEnclave.P256.Signing.PrivateKey(dataRepresentation: blob) }
    catch { fail("Secure Enclave refused the key blob: \(error)") }
}

let args = CommandLine.arguments
guard args.count >= 2 else { fail("usage: helper available|create|public|sign ...") }

switch (args[1], args.count) {
case ("available", 2):
    if !SecureEnclave.isAvailable { fail("this Mac has no Secure Enclave") }
    do { _ = try SecureEnclave.P256.Signing.PrivateKey() }  // prove it issues keys
    catch { fail("Secure Enclave present but refused a key: \(error)") }
    print("OK")
case ("create", 3):
    do {
        let key = try SecureEnclave.P256.Signing.PrivateKey()
        try key.dataRepresentation.write(to: URL(fileURLWithPath: args[2]), options: .withoutOverwriting)
        print(key.publicKey.x963Representation.base64EncodedString())
    } catch { fail("could not create a Secure Enclave key: \(error)") }
case ("public", 3):
    print(load(args[2]).publicKey.x963Representation.base64EncodedString())
case ("sign", 4):
    guard let msg = FileManager.default.contents(atPath: args[3]) else { fail("cannot read \(args[3])") }
    do { print(try load(args[2]).signature(for: msg).derRepresentation.base64EncodedString()) }
    catch { fail("Secure Enclave signing failed: \(error)") }
default:
    fail("usage: helper available|create|public|sign ...")
}
