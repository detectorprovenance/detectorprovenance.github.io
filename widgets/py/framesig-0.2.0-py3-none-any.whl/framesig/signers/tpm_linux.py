"""Sign with a key held in the machine's TPM 2.0 (Linux, via ``tpm2-tools``).

The Linux counterpart of :mod:`tpm_windows`; read that module's docstring for
why a hardware-held key matters. Same key type (P-256, non-exportable), same
signature encoding, same command-line surface.

How a TPM key "lives" here
--------------------------

A TPM has almost no storage, so ``tpm2_create`` does not keep the key: it hands
back the private part *wrapped* (encrypted) under the owner hierarchy's storage
key, which is derived from a seed that never leaves the chip. Those two blobs
are written to ``$XDG_DATA_HOME/framesig/hwkeys/<name>.{pub,priv}``. They are
not secret in the usual sense -- on any other machine, or after a TPM clear,
they are noise -- but on *this* TPM they can be loaded and used, so they are
kept mode 0600 all the same. Deleting them is deleting the key.

The storage primary is re-derived on every call (``tpm2_createprimary`` is
deterministic for a given seed and template) rather than made persistent, so
nothing is written to the TPM's own NV storage and no owner password is needed.

Needs ``tpm2-tools`` (``apt install tpm2-tools``) and read/write access to
``/dev/tpmrm0``, which on most distributions means membership of the ``tss``
group. The TCTI comes from ``TPM2TOOLS_TCTI`` as usual, so the tests run against
``swtpm`` with ``TPM2TOOLS_TCTI=swtpm:port=2321``.
"""

from __future__ import annotations

import os
import pathlib
import shutil
import subprocess
import tempfile
from typing import List, Tuple

from cryptography.hazmat.primitives.asymmetric import utils as asym_utils
from cryptography.hazmat.primitives.serialization import load_pem_public_key

from ..keys import ALG_ECDSA_P256, Signer, key_id, public_key_pem
from .tpm_windows import TpmError, _check_key_name

__all__ = [
    "LinuxTpmSigner",
    "tpm_available",
    "tpm_create_key",
    "tpm_delete_key",
    "tpm_key_exists",
    "tpm_public_key",
    "key_dir",
]

_KEY_ATTRS = "fixedtpm|fixedparent|sensitivedataorigin|userwithauth|sign"


def key_dir() -> pathlib.Path:
    """Where the wrapped key blobs live (``FRAMESIG_KEY_DIR`` overrides)."""
    override = os.environ.get("FRAMESIG_KEY_DIR")
    if override:
        return pathlib.Path(override)
    base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    return pathlib.Path(base) / "framesig" / "hwkeys"


def _paths(key_name: str) -> Tuple[pathlib.Path, pathlib.Path, pathlib.Path]:
    base = str(key_dir() / _check_key_name(key_name))  # not with_suffix: names may hold dots
    return (pathlib.Path(base + ".pub"), pathlib.Path(base + ".priv"),
            pathlib.Path(base + ".pem"))


def _run(*args: str, cwd: str) -> str:
    exe = shutil.which(args[0])
    if not exe:
        raise TpmError(f"{args[0]} not found; install tpm2-tools (e.g. apt install tpm2-tools)")
    proc = subprocess.run([exe, *args[1:]], cwd=cwd, capture_output=True, text=True)
    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout).strip().splitlines()
        message = " / ".join(detail[-2:]) if detail else f"exit code {proc.returncode}"
        if "tpmrm0" in message or "Permission denied" in message:
            message += " (is your user in the 'tss' group?)"
        raise TpmError(f"{args[0]} failed: {message}")
    return proc.stdout


def _tpm(d: str, *args: str) -> str:
    """Run one tpm2-tools command in session directory *d*, then flush.

    Without a resource manager (swtpm, or ``/dev/tpm0`` directly) every tool
    that reads a ``.ctx`` file loads another transient object and leaves it
    there, and the TPM runs out of its three or so object slots inside a single
    signature. The saved context files stay usable after a flush; with
    ``/dev/tpmrm0`` the flush finds nothing to do.
    """
    out = _run(*args, cwd=d)
    _run("tpm2_flushcontext", "-t", cwd=d)
    return out


class _Session:
    """A scratch directory holding the storage primary's context."""

    def __enter__(self) -> str:
        self._tmp = tempfile.TemporaryDirectory(prefix="framesig-tpm-")
        _tpm(self._tmp.name, "tpm2_createprimary", "-Q", "-C", "o", "-g", "sha256",
             "-G", "ecc", "-c", "primary.ctx")
        return self._tmp.name

    def __exit__(self, *exc) -> None:
        self._tmp.cleanup()


def _load(d: str, pub: pathlib.Path, priv: pathlib.Path) -> None:
    _tpm(d, "tpm2_load", "-Q", "-C", "primary.ctx", "-u", str(pub), "-r", str(priv),
         "-c", "key.ctx")


# --------------------------------------------------------------------------
# key management
# --------------------------------------------------------------------------

def tpm_available(provider: str = "") -> Tuple[bool, str]:
    """Can this machine derive a storage key in its TPM right now?"""
    try:
        with _Session():
            pass
    except TpmError as exc:
        return False, str(exc)
    tcti = os.environ.get("TPM2TOOLS_TCTI") or "default TCTI"
    return True, f"TPM 2.0 via tpm2-tools ({tcti}) is usable"


def tpm_create_key(key_name: str, provider: str = ""):
    """Create a non-exportable P-256 key in the TPM. Returns its public key."""
    pub, priv, pem = _paths(key_name)
    if pub.exists() or priv.exists():
        raise TpmError(f"a TPM key named {key_name!r} already exists in {key_dir()}")
    pub.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with _Session() as d:
        _tpm(d, "tpm2_create", "-Q", "-C", "primary.ctx", "-g", "sha256",
             "-G", "ecc256:ecdsa-sha256", "-a", _KEY_ATTRS,
             "-u", "key.pub", "-r", "key.priv")
        _load(d, pathlib.Path(d, "key.pub"), pathlib.Path(d, "key.priv"))
        _tpm(d, "tpm2_readpublic", "-Q", "-c", "key.ctx", "-f", "pem", "-o", "key.pem")
        for src, dst in (("key.pub", pub), ("key.priv", priv), ("key.pem", pem)):
            fd = os.open(dst, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "wb") as fh:
                fh.write(pathlib.Path(d, src).read_bytes())
    return load_pem_public_key(pem.read_bytes())


def tpm_public_key(key_name: str, provider: str = ""):
    # The PEM is a convenience copy written at creation; a swapped file cannot
    # make a forgery verify, because sign_and_verify checks every signature
    # the TPM returns against it.
    pem = _paths(key_name)[2]
    if not pem.exists():
        raise TpmError(f"no TPM key named {key_name!r} in {key_dir()}")
    return load_pem_public_key(pem.read_bytes())


def tpm_key_exists(key_name: str, provider: str = "") -> bool:
    return all(p.exists() for p in _paths(key_name))


def tpm_delete_key(key_name: str, provider: str = "") -> None:
    paths = _paths(key_name)
    if not any(p.exists() for p in paths):
        raise TpmError(f"no TPM key named {key_name!r} in {key_dir()}")
    for p in paths:
        if p.exists():
            p.unlink()


# --------------------------------------------------------------------------
# the signer
# --------------------------------------------------------------------------

class LinuxTpmSigner(Signer):
    """A :class:`Signer` whose private key only ever exists inside the TPM."""

    def __init__(self, key_name: str, provider: str = ""):
        self.key_name = key_name
        self._public_key = tpm_public_key(key_name)
        self.algorithm = ALG_ECDSA_P256
        self.key_id = key_id(self._public_key)

    @property
    def public_key(self):
        return self._public_key

    def public_key_pem(self) -> bytes:
        return public_key_pem(self._public_key)

    def sign(self, message: bytes) -> bytes:
        pub, priv, _ = _paths(self.key_name)
        with _Session() as d:
            pathlib.Path(d, "msg.bin").write_bytes(message)
            _load(d, pub, priv)
            _tpm(d, "tpm2_sign", "-Q", "-c", "key.ctx", "-g", "sha256", "-s", "ecdsa",
                 "-f", "plain", "-o", "sig.bin", "msg.bin")
            raw = pathlib.Path(d, "sig.bin").read_bytes()
        if len(raw) == 64:  # r||s; SPEC 6.1 wants DER SEQUENCE {r, s}
            return asym_utils.encode_dss_signature(
                int.from_bytes(raw[:32], "big"), int.from_bytes(raw[32:], "big"))
        if raw[:1] == b"\x30":  # tpm2-tools >= 5.3 emits DER for "plain" ECDSA
            return raw
        raise TpmError(f"unrecognised ECDSA signature from tpm2_sign ({len(raw)} bytes)")

    def __repr__(self) -> str:  # pragma: no cover - diagnostics
        return f"<LinuxTpmSigner key_name={self.key_name!r} key_id={self.key_id}>"
