"""Sign with a key held in the machine's TPM (Windows).

Why this matters more than it looks
-----------------------------------

Everything else in this repository is a software proof of concept, and says so:
with a software key the trust anchor is whoever can read the key file. This
back end is the first point where that stops being true. The private key is
generated *inside* the TPM by the Microsoft Platform Crypto Provider and marked
non-exportable, so it cannot be copied out -- not by framesig, not by the user,
not by malware running as the user. Signing is a request to the chip.

That is the same shape as the eventual detector: a key that exists in one place,
which can be asked to sign but never to reveal itself. It is the difference
between "these bytes were signed by someone who had the key file" and "these
bytes were signed by *this machine*".

It also validates the algorithm choice. TPM 2.0 and the secure elements a
detector would use speak ECDSA over P-256 and generally do not speak Ed25519,
which is exactly why P-256 is a first-class algorithm here rather than a
concession.

Implementation notes
--------------------

Signing goes through a PowerShell helper because CNG has no usable Python
binding. The cost is process startup, roughly a quarter of a second per
signature -- which is a fair imitation of real hardware, where an ATECC608
needs tens of milliseconds and a TPM rather more. Signing a thousand frames
individually would take minutes; signing a thousand frames as a *series* takes
one TPM operation, because only the Merkle root is signed. The hardware back
end is where that design stops being theoretical.
"""

from __future__ import annotations

import base64
import os
import re
import pathlib
import shutil
import subprocess
import tempfile
from typing import List, Optional, Tuple

from cryptography.hazmat.primitives.asymmetric import ec, utils as asym_utils

from ..keys import ALG_ECDSA_P256, Signer, key_id, public_key_pem

__all__ = [
    "TpmError",
    "WindowsTpmSigner",
    "tpm_available",
    "tpm_create_key",
    "tpm_delete_key",
    "tpm_public_key",
    "DEFAULT_PROVIDER",
]

DEFAULT_PROVIDER = "Microsoft Platform Crypto Provider"
_SCRIPT = pathlib.Path(__file__).with_name("tpm_windows.ps1")


class TpmError(RuntimeError):
    """The TPM helper could not do what was asked."""


def _powershell() -> str:
    """Prefer PowerShell 7; fall back to Windows PowerShell.

    The helper script is written to work under both, so this is only about
    finding one of them.
    """
    for candidate in ("pwsh", "powershell"):
        found = shutil.which(candidate)
        if found:
            return found
    raise TpmError(
        "no PowerShell interpreter found on PATH; the TPM back end is Windows-only"
    )


#: Key names reach PowerShell as parameter values. The call is list-form with
#: no shell, so there is no command injection -- but PowerShell still *binds*
#: arguments, and a name beginning with "-" can be taken for another parameter
#: (``-Action``, ``-InFile``). Constraining the charset removes the ambiguity
#: rather than relying on the binder to resolve it the way we hope.
_SAFE_KEY_NAME = re.compile(r"\A[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")


def _check_key_name(key_name: str) -> str:
    if not _SAFE_KEY_NAME.match(key_name or ""):
        raise TpmError(
            f"invalid TPM key name {key_name!r}: use 1-128 characters from "
            "A-Z a-z 0-9 . _ - starting with a letter or digit"
        )
    return key_name


def _run(action: str, *, key_name: Optional[str] = None, in_file: Optional[str] = None,
         provider: str = DEFAULT_PROVIDER) -> List[str]:
    if os.name != "nt":
        raise TpmError("the TPM back end is Windows-only (it uses CNG via PowerShell)")
    cmd = [
        _powershell(), "-NoProfile", "-NonInteractive",
        "-ExecutionPolicy", "Bypass",
        "-File", str(_SCRIPT),
        "-Action", action,
        "-Provider", provider,
    ]
    if key_name:
        cmd += ["-KeyName", _check_key_name(key_name)]
    if in_file:
        cmd += ["-InFile", in_file]

    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout).strip().splitlines()
        message = detail[0] if detail else f"exit code {proc.returncode}"
        raise TpmError(f"TPM helper failed during {action!r}: {message}")
    return [line.strip() for line in proc.stdout.splitlines() if line.strip()]


def _public_key_from_xy(x_b64: str, y_b64: str):
    x = int.from_bytes(base64.b64decode(x_b64), "big")
    y = int.from_bytes(base64.b64decode(y_b64), "big")
    return ec.EllipticCurvePublicNumbers(x, y, ec.SECP256R1()).public_key()


# --------------------------------------------------------------------------
# key management
# --------------------------------------------------------------------------

def tpm_available(provider: str = DEFAULT_PROVIDER) -> Tuple[bool, str]:
    """Can this machine actually create a TPM-backed key?

    Checks by creating and immediately deleting a throwaway key, because the
    provider being *listed* does not mean it works -- a TPM can be present,
    disabled in firmware, or owned in a way that refuses new keys.
    """
    if os.name != "nt":
        return False, "not Windows"
    try:
        out = _run("provider", provider=provider)
    except TpmError as exc:
        return False, str(exc)
    if out and out[0] == "OK":
        return True, f"{provider} is usable"
    return False, out[0] if out else "unknown failure"


def tpm_create_key(key_name: str, provider: str = DEFAULT_PROVIDER):
    """Create a non-exportable P-256 key in the TPM. Returns its public key."""
    out = _run("create", key_name=key_name, provider=provider)
    if len(out) < 2:
        raise TpmError(f"unexpected output creating key: {out!r}")
    return _public_key_from_xy(out[0], out[1])


def tpm_public_key(key_name: str, provider: str = DEFAULT_PROVIDER):
    out = _run("public", key_name=key_name, provider=provider)
    if len(out) < 2:
        raise TpmError(f"unexpected output reading public key: {out!r}")
    return _public_key_from_xy(out[0], out[1])


def tpm_key_exists(key_name: str, provider: str = DEFAULT_PROVIDER) -> bool:
    out = _run("exists", key_name=key_name, provider=provider)
    return bool(out) and out[0].lower() == "true"


def tpm_delete_key(key_name: str, provider: str = DEFAULT_PROVIDER) -> None:
    _run("delete", key_name=key_name, provider=provider)


# --------------------------------------------------------------------------
# the signer
# --------------------------------------------------------------------------

class WindowsTpmSigner(Signer):
    """A :class:`Signer` whose private key lives in the TPM and never leaves it."""

    def __init__(self, key_name: str, provider: str = DEFAULT_PROVIDER):
        self.key_name = key_name
        self.provider = provider
        self._public_key = tpm_public_key(key_name, provider)
        self.algorithm = ALG_ECDSA_P256
        self.key_id = key_id(self._public_key)

    @property
    def public_key(self):
        return self._public_key

    def public_key_pem(self) -> bytes:
        return public_key_pem(self._public_key)

    def sign(self, message: bytes) -> bytes:
        # The message goes via a temp file rather than stdin: PowerShell's
        # stdin handling mangles binary, and the pre-image contains NUL bytes
        # by design (the domain-separation prefix).
        handle, path = tempfile.mkstemp(prefix="framesig-tpm-", suffix=".bin")
        try:
            with os.fdopen(handle, "wb") as fh:
                fh.write(message)
            out = _run("sign", key_name=self.key_name, in_file=path, provider=self.provider)
        finally:
            try:
                os.unlink(path)
            except OSError:  # pragma: no cover
                pass
        if not out:
            raise TpmError("TPM returned no signature")
        raw = base64.b64decode(out[0])
        if len(raw) != 64:
            raise TpmError(f"expected a 64-byte raw ECDSA signature, got {len(raw)} bytes")
        # SPEC 6.1 requires DER SEQUENCE {r, s}; CNG hands back raw r||s.
        r = int.from_bytes(raw[:32], "big")
        s = int.from_bytes(raw[32:], "big")
        return asym_utils.encode_dss_signature(r, s)

    def __repr__(self) -> str:  # pragma: no cover - diagnostics
        return f"<WindowsTpmSigner key_name={self.key_name!r} key_id={self.key_id}>"
