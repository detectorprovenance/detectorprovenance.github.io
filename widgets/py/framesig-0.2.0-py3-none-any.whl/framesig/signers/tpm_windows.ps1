# TPM-backed signing helper for framesig (Windows).
#
# The private key is created inside the TPM through the Microsoft Platform
# Crypto Provider and is marked non-exportable, so it cannot be read out by
# this script, by framesig, or by anything else running as this user. That is
# the entire point: it is the closest a commodity PC gets to the detector
# secure element this design is ultimately aimed at.
#
# Deliberately avoids every .NET 5+ only API (ExportSubjectPublicKeyInfo,
# DSASignatureFormat) so the same script runs under Windows PowerShell 5.1 and
# PowerShell 7+. Public keys come out as raw affine coordinates and signatures
# as raw r||s; framesig assembles the SPKI and the DER signature on the Python
# side, where the encoding is already implemented and tested.

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet("create", "public", "sign", "delete", "exists", "provider", "authrequired")]
    [string]$Action,

    [string]$KeyName,
    [string]$InFile,
    [string]$Provider = "Microsoft Platform Crypto Provider",

    # The key's usage authorization arrives on stdin as 64 hex digits (the
    # SHA-256 framesig derives from the PIN), never as an argument: argv is
    # readable by every process on the machine.
    [switch]$AuthFromStdin
)

$ErrorActionPreference = "Stop"

$UsageAuth = $null
if ($AuthFromStdin) {
    $hex = [Console]::In.ReadLine()
    if ($hex -cnotmatch '^[0-9a-f]{64}$') { throw "malformed authorization value on stdin" }
    $UsageAuth = New-Object byte[] 32
    for ($i = 0; $i -lt 32; $i++) { $UsageAuth[$i] = [Convert]::ToByte($hex.Substring(2 * $i, 2), 16) }
}

function New-UsageAuthProperty {
    # PCP_USAGEAUTH takes the TPM auth value itself, so the bytes presented at
    # signing are exactly the bytes set at creation, with no provider-side
    # hashing of a PIN string in between.
    return New-Object System.Security.Cryptography.CngProperty(
        "PCP_USAGEAUTH", $UsageAuth, [System.Security.Cryptography.CngPropertyOptions]::None)
}

function Test-AuthRequired($key) {
    # A one-byte BOOLEAN on the PCP (read off a real key); any non-zero byte
    # counts, and an empty value is refused rather than guessed.
    $v = $key.GetProperty("PCP_PASSWORD_REQUIRED", [System.Security.Cryptography.CngPropertyOptions]::None).GetValue()
    if ($null -eq $v -or $v.Length -lt 1) { throw "cannot tell whether TPM key '$KeyName' needs a PIN" }
    return [bool]($v | Where-Object { $_ -ne 0 })
}

function Get-Provider {
    return New-Object System.Security.Cryptography.CngProvider($Provider)
}

function Open-Key {
    $p = Get-Provider
    if (-not [System.Security.Cryptography.CngKey]::Exists($KeyName, $p)) {
        throw "no TPM key named '$KeyName' in provider '$Provider'"
    }
    # Silent: a key that needs a PIN must fail here, not pop a dialog that
    # hangs an unattended signer.
    return [System.Security.Cryptography.CngKey]::Open(
        $KeyName, $p, [System.Security.Cryptography.CngKeyOpenOptions]::Silent)
}

switch ($Action) {

    "provider" {
        # Report whether a TPM-backed provider is usable at all, without
        # creating anything persistent.
        $p = Get-Provider
        $probe = "framesig-availability-probe"
        try {
            if ([System.Security.Cryptography.CngKey]::Exists($probe, $p)) {
                [System.Security.Cryptography.CngKey]::Open($probe, $p).Delete()
            }
            $cp = New-Object System.Security.Cryptography.CngKeyCreationParameters
            $cp.Provider = $p
            $cp.ExportPolicy = [System.Security.Cryptography.CngExportPolicies]::None
            $k = [System.Security.Cryptography.CngKey]::Create(
                [System.Security.Cryptography.CngAlgorithm]::ECDsaP256, $probe, $cp)
            $k.Delete()
            Write-Output "OK"
        } catch {
            Write-Output "UNAVAILABLE: $($_.Exception.Message)"
        }
    }

    "authrequired" {
        Write-Output (Test-AuthRequired (Open-Key)).ToString()
    }

    "exists" {
        $p = Get-Provider
        Write-Output ([System.Security.Cryptography.CngKey]::Exists($KeyName, $p)).ToString()
    }

    "create" {
        $p = Get-Provider
        if ([System.Security.Cryptography.CngKey]::Exists($KeyName, $p)) {
            throw "a TPM key named '$KeyName' already exists; delete it first or pick another name"
        }
        $cp = New-Object System.Security.Cryptography.CngKeyCreationParameters
        $cp.Provider = $p
        # None = non-exportable. The key material never leaves the TPM.
        $cp.ExportPolicy = [System.Security.Cryptography.CngExportPolicies]::None
        if ($null -ne $UsageAuth) { $cp.Parameters.Add((New-UsageAuthProperty)) }  # set before finalize
        $key = [System.Security.Cryptography.CngKey]::Create(
            [System.Security.Cryptography.CngAlgorithm]::ECDsaP256, $KeyName, $cp)
        $ecdsa = New-Object System.Security.Cryptography.ECDsaCng($key)
        $pub = $ecdsa.ExportParameters($false)
        Write-Output ([Convert]::ToBase64String($pub.Q.X))
        Write-Output ([Convert]::ToBase64String($pub.Q.Y))
    }

    "public" {
        $ecdsa = New-Object System.Security.Cryptography.ECDsaCng(Open-Key)
        $pub = $ecdsa.ExportParameters($false)
        Write-Output ([Convert]::ToBase64String($pub.Q.X))
        Write-Output ([Convert]::ToBase64String($pub.Q.Y))
    }

    "sign" {
        if (-not (Test-Path -LiteralPath $InFile)) { throw "input file not found: $InFile" }
        $bytes = [System.IO.File]::ReadAllBytes($InFile)
        $key = Open-Key
        # Decide locally, before the TPM sees anything: presenting a value the
        # key was not created with counts against the dictionary-attack lockout.
        $required = Test-AuthRequired $key
        if ($required -and $null -eq $UsageAuth) { throw "TPM key '$KeyName' requires its PIN and none was supplied" }
        if ($null -ne $UsageAuth -and -not $required) { throw "TPM key '$KeyName' has no PIN; refusing to present one" }
        if ($null -ne $UsageAuth) { $key.SetProperty((New-UsageAuthProperty)) }
        $ecdsa = New-Object System.Security.Cryptography.ECDsaCng($key)
        # Two-argument SignData returns raw r||s on every .NET edition; the
        # DER-format overload exists only on .NET 5+.
        $sig = $ecdsa.SignData($bytes, [System.Security.Cryptography.HashAlgorithmName]::SHA256)
        Write-Output ([Convert]::ToBase64String($sig))
    }

    "delete" {
        (Open-Key).Delete()
        Write-Output "deleted"
    }
}
