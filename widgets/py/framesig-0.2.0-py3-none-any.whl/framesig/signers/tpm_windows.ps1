# TPM-backed signing helper for framesig (Windows).
#
# The private key is created inside the TPM through the Microsoft Platform
# Crypto Provider and is marked non-exportable, so it cannot be read out by
# this script, by framesig, or by anything else running as this user. That is
# the entire point: it is the closest a commodity PC gets to the detector
# secure element this design is ultimately aimed at.
#
# Deliberately avoids every .NET 5+ only API (ExportSubjectPublicKeyInfo,
# DSASignatureFormat) so the same script runs under Windows PowerShell 5.1 and
# PowerShell 7+. Public keys come out as raw affine coordinates and signatures
# as raw r||s; framesig assembles the SPKI and the DER signature on the Python
# side, where the encoding is already implemented and tested.

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet("create", "public", "sign", "delete", "exists", "provider")]
    [string]$Action,

    [string]$KeyName,
    [string]$InFile,
    [string]$Provider = "Microsoft Platform Crypto Provider"
)

$ErrorActionPreference = "Stop"

function Get-Provider {
    return New-Object System.Security.Cryptography.CngProvider($Provider)
}

function Open-Key {
    $p = Get-Provider
    if (-not [System.Security.Cryptography.CngKey]::Exists($KeyName, $p)) {
        throw "no TPM key named '$KeyName' in provider '$Provider'"
    }
    return [System.Security.Cryptography.CngKey]::Open($KeyName, $p)
}

switch ($Action) {

    "provider" {
        # Report whether a TPM-backed provider is usable at all, without
        # creating anything persistent.
        $p = Get-Provider
        $probe = "framesig-availability-probe"
        try {
            if ([System.Security.Cryptography.CngKey]::Exists($probe, $p)) {
                [System.Security.Cryptography.CngKey]::Open($probe, $p).Delete()
            }
            $cp = New-Object System.Security.Cryptography.CngKeyCreationParameters
            $cp.Provider = $p
            $cp.ExportPolicy = [System.Security.Cryptography.CngExportPolicies]::None
            $k = [System.Security.Cryptography.CngKey]::Create(
                [System.Security.Cryptography.CngAlgorithm]::ECDsaP256, $probe, $cp)
            $k.Delete()
            Write-Output "OK"
        } catch {
            Write-Output "UNAVAILABLE: $($_.Exception.Message)"
        }
    }

    "exists" {
        $p = Get-Provider
        Write-Output ([System.Security.Cryptography.CngKey]::Exists($KeyName, $p)).ToString()
    }

    "create" {
        $p = Get-Provider
        if ([System.Security.Cryptography.CngKey]::Exists($KeyName, $p)) {
            throw "a TPM key named '$KeyName' already exists; delete it first or pick another name"
        }
        $cp = New-Object System.Security.Cryptography.CngKeyCreationParameters
        $cp.Provider = $p
        # None = non-exportable. The key material never leaves the TPM.
        $cp.ExportPolicy = [System.Security.Cryptography.CngExportPolicies]::None
        $key = [System.Security.Cryptography.CngKey]::Create(
            [System.Security.Cryptography.CngAlgorithm]::ECDsaP256, $KeyName, $cp)
        $ecdsa = New-Object System.Security.Cryptography.ECDsaCng($key)
        $pub = $ecdsa.ExportParameters($false)
        Write-Output ([Convert]::ToBase64String($pub.Q.X))
        Write-Output ([Convert]::ToBase64String($pub.Q.Y))
    }

    "public" {
        $ecdsa = New-Object System.Security.Cryptography.ECDsaCng(Open-Key)
        $pub = $ecdsa.ExportParameters($false)
        Write-Output ([Convert]::ToBase64String($pub.Q.X))
        Write-Output ([Convert]::ToBase64String($pub.Q.Y))
    }

    "sign" {
        if (-not (Test-Path -LiteralPath $InFile)) { throw "input file not found: $InFile" }
        $bytes = [System.IO.File]::ReadAllBytes($InFile)
        $ecdsa = New-Object System.Security.Cryptography.ECDsaCng(Open-Key)
        # Two-argument SignData returns raw r||s on every .NET edition; the
        # DER-format overload exists only on .NET 5+.
        $sig = $ecdsa.SignData($bytes, [System.Security.Cryptography.HashAlgorithmName]::SHA256)
        Write-Output ([Convert]::ToBase64String($sig))
    }

    "delete" {
        (Open-Key).Delete()
        Write-Output "deleted"
    }
}
