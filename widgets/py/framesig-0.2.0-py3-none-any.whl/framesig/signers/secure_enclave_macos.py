"""Sign with a key held in the Mac's Secure Enclave.

The macOS counterpart of :mod:`tpm_windows` and :mod:`tpm_linux`; read the
Windows module's docstring for why a hardware-held key matters. The Secure
Enclave (Apple silicon, or an Intel Mac with a T2 chip) generates P-256 keys
that never leave it, which is exactly the key type the rest of framesig uses.

The enclave hands back a wrapped key blob -- encrypted under a key that never
leaves *this* enclave -- which is stored at
``~/Library/Application Support/framesig/hwkeys/<name>.se`` (mode 0600). On any
other Mac the blob is useless; deleting it is deleting the key.

CryptoKit has no Python binding, so a small Swift helper does the work. It is
compiled on first use (needs the Xcode command line tools: ``xcode-select
--install``) into ``~/Library/Caches/framesig``, keyed by the source's hash, so
later calls cost one process start rather than a Swift interpreter start-up.
No access control is attached to the key, so signing never prompts; that suits
an unattended signer and means anything running as the user can *use* the key,
though nothing can copy it.

PIN binding (the ``auth`` the TPM back ends take) is **not supported here
yet**: a Secure Enclave key can only be created deliberately unprotected
(``allow_unprotected=True``), and passing ``auth`` is refused rather than
silently ignored. CryptoKit's ``SecAccessControl`` with an application
password is the likely route; it has not been built or tested.
"""

from __future__ import annotations

import base64
import hashlib
import os
import pathlib
import subprocess
import sys
import tempfile
from typing import List, Optional, Tuple

from cryptography.hazmat.primitives.asymmetric import ec

from .._fs import find_executable
from ..keys import ALG_ECDSA_P256, Signer, key_id, public_key_pem
from .tpm_windows import TpmError, _check_key_name, _no_auth_opt_in

__all__ = [
    "SecureEnclaveSigner",
    "tpm_available",
    "tpm_create_key",
    "tpm_delete_key",
    "tpm_key_exists",
    "tpm_key_requires_auth",
    "tpm_public_key",
    "key_dir",
]

_SOURCE = pathlib.Path(__file__).with_name("secure_enclave_macos.swift")


def key_dir() -> pathlib.Path:
    """Where the wrapped key blobs live (``FRAMESIG_KEY_DIR`` overrides)."""
    override = os.environ.get("FRAMESIG_KEY_DIR")
    if override:
        return pathlib.Path(override)
    return pathlib.Path.home() / "Library" / "Application Support" / "framesig" / "hwkeys"


def _blob(key_name: str) -> pathlib.Path:
    return key_dir() / (_check_key_name(key_name) + ".se")


def _helper() -> str:
    if sys.platform != "darwin":
        raise TpmError("the Secure Enclave back end is macOS-only")
    source = _SOURCE.read_bytes()
    cache = pathlib.Path.home() / "Library" / "Caches" / "framesig"
    exe = cache / f"se-helper-{hashlib.sha256(source).hexdigest()[:16]}"
    if exe.exists():
        return str(exe)
    swiftc = find_executable("swiftc")
    if not swiftc:
        raise TpmError("swiftc not found; install the Xcode command line tools "
                       "(xcode-select --install)")
    cache.mkdir(parents=True, exist_ok=True)
    tmp = exe.with_name(exe.name + f".{os.getpid()}.tmp")
    proc = subprocess.run([swiftc, "-O", str(_SOURCE), "-o", str(tmp)],
                          capture_output=True, text=True)
    if proc.returncode != 0:
        raise TpmError(f"could not compile the Secure Enclave helper: {proc.stderr.strip()}")
    os.replace(tmp, exe)  # atomic, so two first calls cannot see half a binary
    return str(exe)


def _run(*args: str) -> List[str]:
    proc = subprocess.run([_helper(), *args], capture_output=True, text=True)
    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout).strip().splitlines()
        raise TpmError(detail[0] if detail else f"exit code {proc.returncode}")
    return [line.strip() for line in proc.stdout.splitlines() if line.strip()]


def _public_key(x963_b64: str):
    return ec.EllipticCurvePublicKey.from_encoded_point(
        ec.SECP256R1(), base64.b64decode(x963_b64))


# --------------------------------------------------------------------------
# key management (same names as the TPM back ends, so the CLI is shared)
# --------------------------------------------------------------------------

def tpm_available(provider: str = "") -> Tuple[bool, str]:
    """Can this Mac's Secure Enclave issue a key right now?"""
    try:
        _run("available")
    except TpmError as exc:
        return False, str(exc)
    return True, "Secure Enclave is usable"


_NO_PIN = ("PIN binding is not supported on the Secure Enclave back end yet; create the "
           "key deliberately unprotected (--i-accept-an-unprotected-hardware-key)")


def tpm_create_key(key_name: str, provider: str = "", *,
                   auth: Optional[bytes] = None, allow_unprotected: bool = False):
    """Create a non-exportable P-256 key in the Secure Enclave (no PIN yet)."""
    if auth is not None:
        raise TpmError(_NO_PIN)
    _no_auth_opt_in(auth, allow_unprotected)
    blob = _blob(key_name)
    if blob.exists():
        raise TpmError(f"a Secure Enclave key named {key_name!r} already exists in {key_dir()}")
    blob.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    # The helper writes with the default umask; tighten it before it appears
    # under its real name.
    with tempfile.TemporaryDirectory(dir=blob.parent) as d:
        tmp = pathlib.Path(d, "key.se")
        out = _run("create", str(tmp))
        os.chmod(tmp, 0o600)
        os.replace(tmp, blob)
    return _public_key(out[0])


def tpm_public_key(key_name: str, provider: str = ""):
    blob = _blob(key_name)
    if not blob.exists():
        raise TpmError(f"no Secure Enclave key named {key_name!r} in {key_dir()}")
    return _public_key(_run("public", str(blob))[0])


def tpm_key_exists(key_name: str, provider: str = "") -> bool:
    return _blob(key_name).exists()


def tpm_key_requires_auth(key_name: str, provider: str = "") -> bool:
    return False  # ponytail: no PIN binding on the enclave yet, see the docstring


def tpm_delete_key(key_name: str, provider: str = "") -> None:
    blob = _blob(key_name)
    if not blob.exists():
        raise TpmError(f"no Secure Enclave key named {key_name!r} in {key_dir()}")
    blob.unlink()


# --------------------------------------------------------------------------
# the signer
# --------------------------------------------------------------------------

class SecureEnclaveSigner(Signer):
    """A :class:`Signer` whose private key only ever exists in the Secure Enclave."""

    def __init__(self, key_name: str, provider: str = "", *, auth: Optional[bytes] = None):
        if auth is not None:
            raise TpmError(_NO_PIN)
        self.key_name = key_name
        self._public_key = tpm_public_key(key_name)
        self.algorithm = ALG_ECDSA_P256
        self.key_id = key_id(self._public_key)

    @property
    def public_key(self):
        return self._public_key

    def public_key_pem(self) -> bytes:
        return public_key_pem(self._public_key)

    def sign(self, message: bytes) -> bytes:
        handle, path = tempfile.mkstemp(prefix="framesig-se-", suffix=".bin")
        try:
            with os.fdopen(handle, "wb") as fh:
                fh.write(message)
            out = _run("sign", str(_blob(self.key_name)), path)
        finally:
            os.unlink(path)
        return base64.b64decode(out[0])  # CryptoKit already returns DER

    def __repr__(self) -> str:  # pragma: no cover - diagnostics
        return f"<SecureEnclaveSigner key_name={self.key_name!r} key_id={self.key_id}>"
