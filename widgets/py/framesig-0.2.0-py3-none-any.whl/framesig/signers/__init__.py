"""Signing back ends.

The :class:`~framesig.keys.Signer` interface is three members wide -- algorithm,
key_id, sign -- precisely so that back ends like this can exist without the
manifest, PKI or CLI code knowing anything about them.

``HardwareSigner`` and the ``tpm_*`` functions are this platform's hardware key
store: the TPM via CNG on Windows, the TPM via ``tpm2-tools`` on Linux, the
Secure Enclave on macOS. All three hold a non-exportable P-256 key.
"""

import sys

from .tpm_windows import TpmError, WindowsTpmSigner

if sys.platform == "darwin":
    from .secure_enclave_macos import (
        SecureEnclaveSigner as HardwareSigner,
        tpm_available,
        tpm_create_key,
        tpm_delete_key,
        tpm_key_exists,
        tpm_public_key,
    )
elif sys.platform.startswith("linux"):
    from .tpm_linux import (
        LinuxTpmSigner as HardwareSigner,
        tpm_available,
        tpm_create_key,
        tpm_delete_key,
        tpm_key_exists,
        tpm_public_key,
    )
else:
    from .tpm_windows import (
        WindowsTpmSigner as HardwareSigner,
        tpm_available,
        tpm_create_key,
        tpm_delete_key,
        tpm_key_exists,
        tpm_public_key,
    )

__all__ = [
    "HardwareSigner",
    "WindowsTpmSigner",
    "TpmError",
    "tpm_available",
    "tpm_create_key",
    "tpm_delete_key",
    "tpm_key_exists",
    "tpm_public_key",
]
