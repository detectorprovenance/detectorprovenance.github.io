"""Canonical JSON serialisation (RFC 8785 / JCS), restricted subset.

The manifest is signed as bytes, so the *exact* serialisation matters.  We use
JCS because every language has a JSON parser and a third party must be able to
write an independent verifier without pulling in a CBOR/COSE stack.

Restrictions relative to full RFC 8785, deliberately:

* No floating point numbers.  ECMAScript ``Number::toString`` is the single
  nastiest part of JCS to reimplement, and nothing in a manifest needs a float.
  Anything fractional must be expressed as an integer with a stated unit or as
  a string.  Encoding a float raises :class:`CanonError`.
* Integers must fit in the IEEE-754 double-safe range so that a JSON parser in
  any language round-trips them exactly.

These restrictions are part of the on-the-wire spec, not an implementation
detail -- see ``docs/SPEC.md``.
"""

from __future__ import annotations

import json
from typing import Any

__all__ = ["canonicalize", "CanonError", "MAX_SAFE_INT"]

# 2**53 - 1: the largest integer an IEEE-754 double represents exactly.
MAX_SAFE_INT = 9007199254740991


class CanonError(ValueError):
    """Raised when a value cannot be canonicalised under the restricted subset."""


def _sort_key(key: str) -> bytes:
    """RFC 8785 orders object members by their UTF-16 code units."""
    return key.encode("utf-16-be", errors="surrogatepass")


def _write(obj: Any, out: list) -> None:
    if obj is None:
        out.append("null")
    elif obj is True:
        out.append("true")
    elif obj is False:
        out.append("false")
    elif isinstance(obj, int):
        if abs(obj) > MAX_SAFE_INT:
            raise CanonError(f"integer {obj} outside the JSON-safe range")
        out.append(str(obj))
    elif isinstance(obj, float):
        raise CanonError(
            "floats are not permitted in a framesig manifest; use an integer "
            "with an explicit unit, or a string"
        )
    elif isinstance(obj, str):
        # Python's json emits exactly the escapes RFC 8785 mandates: \" \\ \b
        # \f \n \r \t and \u00xx for the remaining C0 controls.
        out.append(json.dumps(obj, ensure_ascii=False))
    elif isinstance(obj, (list, tuple)):
        out.append("[")
        for i, item in enumerate(obj):
            if i:
                out.append(",")
            _write(item, out)
        out.append("]")
    elif isinstance(obj, dict):
        out.append("{")
        for i, key in enumerate(sorted(obj, key=_sort_key)):
            if not isinstance(key, str):
                raise CanonError(f"object keys must be strings, got {type(key)!r}")
            if i:
                out.append(",")
            out.append(json.dumps(key, ensure_ascii=False))
            out.append(":")
            _write(obj[key], out)
        out.append("}")
    else:
        raise CanonError(f"cannot canonicalise value of type {type(obj)!r}")


def canonicalize(obj: Any) -> bytes:
    """Return the RFC 8785 canonical UTF-8 encoding of *obj*."""
    out: list = []
    _write(obj, out)
    return "".join(out).encode("utf-8")
