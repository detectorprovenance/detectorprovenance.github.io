"""Sign an HDF5 file in place, and verify one (SPEC §7.2, profile ``hdf5/1``).

Works for any HDF5 file -- HyperSpy ``.hspy``, EMD, NeXus, a plain ``.h5`` --
because it signs the logical tree (``tree.py``), not a particular layout. The
signature is stored in a ``/framesig`` group:

    /framesig              group, @spec = "framesig-hdf5/1"
    /framesig/envelope     string: the envelope (SPEC §6) as JSON
    /framesig/structure    uint8: the signed structure document, for reporting
                           which node changed; its digest is in the manifest

Before any value is read, the walk rejects what a verifier cannot vouch for:
external links (the content lives in a file the signature does not cover),
virtual datasets, external raw storage, and filters other than the ones
built into libhdf5 or h5py. Filter plugins are never loaded: a filter id makes
HDF5 dlopen a plugin library, from a directory that is user-writable on
Windows. Soft links are recorded, with their target, and never followed.

h5py and numpy are optional dependencies (``pip install framesig[hdf5]``).
"""

from __future__ import annotations

import json
import os
from typing import List, Optional, Sequence, Tuple

from .tree import RESERVED, Node, sign_tree, slabs_of, verify_tree

__all__ = ["HDF5_SPEC", "PROFILE", "HDF5_MAGIC", "sign_hdf5", "verify_hdf5", "is_signed_hdf5"]

HDF5_SPEC = "framesig-hdf5/1"
PROFILE = "hdf5/1"
HDF5_MAGIC = b"\x89HDF\r\n\x1a\n"
#: deflate, shuffle, fletcher32, n-bit, scale-offset (libhdf5) and LZF (h5py).
ALLOWED_FILTERS = {1, 2, 3, 5, 6, 32000}


def _h5():
    """h5py and numpy, with HDF5 filter plugins disabled."""
    os.environ["HDF5_PLUGIN_PRELOAD"] = "::"
    try:
        import h5py
        import numpy as np
    except ImportError as exc:  # pragma: no cover - depends on the install
        raise SystemExit("signing HDF5 needs h5py and numpy: pip install framesig[hdf5]") from exc
    while h5py.h5pl.size():
        h5py.h5pl.remove(0)
    return h5py, np


def _attrs(obj) -> dict:
    out = {}
    for k in obj.attrs:
        try:
            out[k] = obj.attrs[k]
        except (OSError, TypeError, ValueError) as exc:  # an attribute h5py cannot decode
            out[k] = {"$unreadable": type(exc).__name__}
    return out


def _array_node(h5py, np, path, ds) -> Node:
    string = h5py.check_string_dtype(ds.dtype)
    if string is not None:
        dtype = np.dtype("U") if string.encoding == "utf-8" else np.dtype("S")
        view = ds.asstr() if string.encoding == "utf-8" else ds
    else:
        dtype, view = ds.dtype, ds

    def getitem(idx):
        return np.asarray(view[idx])

    return Node(path=path, kind="array", attrs=_attrs(ds), dtype=dtype, shape=tuple(ds.shape),
                slabs=lambda: slabs_of(np, getitem, ds.shape, max(ds.dtype.itemsize, 1)))


def walk(h5py, np, h) -> Tuple[List[Node], List[str]]:
    """Every node except /framesig, and the problems that forbid verification."""
    nodes = [Node(path="/", kind="group", attrs=_attrs(h))]
    problems: List[str] = []

    def visit(name, link):
        if name == RESERVED or name.startswith(RESERVED + "/"):
            return
        path = "/" + name
        if isinstance(link, h5py.SoftLink):
            nodes.append(Node(path=path, kind="link", target=link.path))
            return
        if not isinstance(link, h5py.HardLink):
            problems.append(f"{path} is a {type(link).__name__}: its content lies outside the signed file")
            return
        obj = h[name]
        if isinstance(obj, h5py.Group):
            nodes.append(Node(path=path, kind="group", attrs=_attrs(obj)))
        elif isinstance(obj, h5py.Dataset):
            if obj.is_virtual:
                problems.append(f"{path} is a virtual dataset")
                return
            plist = obj.id.get_create_plist()
            if plist.get_external_count():
                problems.append(f"{path} keeps its data in external files")
                return
            filters = {plist.get_filter(i)[0] for i in range(plist.get_nfilters())}
            if filters - ALLOWED_FILTERS:
                problems.append(f"{path} uses filters {sorted(filters - ALLOWED_FILTERS)}, "
                                "which would need an HDF5 plugin")
                return
            nodes.append(_array_node(h5py, np, path, obj))
        else:  # a committed datatype
            nodes.append(Node(path=path, kind="group", attrs={"$datatype": str(obj.dtype)}))

    h.visititems_links(visit)
    return nodes, problems


def is_signed_hdf5(path) -> bool:
    """An HDF5 file with a /framesig group of this spec. Checks the magic bytes first."""
    try:
        with open(path, "rb") as fh:
            if fh.read(8) != HDF5_MAGIC:
                return False
        h5py, _ = _h5()
        with h5py.File(path, "r") as h:
            return (isinstance(h.get(RESERVED, getlink=True), h5py.HardLink)
                    and h[RESERVED].attrs.get("spec") == HDF5_SPEC)
    except (OSError, KeyError, ValueError, TypeError, SystemExit):
        return False


def sign_hdf5(path, signer, *, certificates_der: Sequence[bytes] = (), claims: Optional[dict] = None,
              attestation: Optional[dict] = None) -> dict:
    """Sign the HDF5 file at *path* in place. Re-signing replaces /framesig.

    Raises ValueError, before writing anything, if the file holds content a
    verifier could not vouch for (external links, virtual or external storage,
    plugin filters). The file is verified before this returns.
    """
    h5py, np = _h5()
    with h5py.File(path, "r") as h:
        nodes, problems = walk(h5py, np, h)
        if problems:
            raise ValueError("cannot sign this file: " + "; ".join(problems))
        envelope, structure = sign_tree(PROFILE, nodes, signer, certificates_der=certificates_der,
                                        claims=claims, attestation=attestation)
    with h5py.File(path, "r+") as h:
        if RESERVED in h:
            del h[RESERVED]
        fs = h.create_group(RESERVED)
        fs.attrs["spec"] = HDF5_SPEC
        fs.create_dataset("envelope", data=json.dumps(envelope))
        fs.create_dataset("structure", data=np.frombuffer(structure, dtype=np.uint8))
    check = verify_hdf5(path, public_keys=[signer.public_key])
    if check.status != "valid":
        raise RuntimeError(f"the file just signed does not verify: {check.problems}")
    return {"path": str(path), "arrays": len(check.payload_reports)}


def verify_hdf5(path, *, roots=(), public_keys=(), at_time=None, timestamp_roots=()):
    """Verify an HDF5 file signed in place. Returns an ``api.VerificationResult``.

    A malformed or hostile file gives a verdict, never an exception.
    """
    from cryptography.exceptions import UnsupportedAlgorithm

    from . import manifest as _m
    from .api import VerificationResult, _authenticate_single

    result = VerificationResult(status="invalid")
    try:
        h5py, np = _h5()
        with h5py.File(path, "r") as h:
            link = h.get(RESERVED, getlink=True)
            if link is None:
                result.status = "unsigned"
                result.problems.append("no signature found: the file has no /framesig group")
                return result
            if not isinstance(link, h5py.HardLink) or h[RESERVED].attrs.get("spec") != HDF5_SPEC:
                result.problems.append(f"/framesig is not a {HDF5_SPEC} signature")
                return result
            envelope = json.loads(h[RESERVED]["envelope"][()])
            stored = bytes(h[RESERVED]["structure"][()]) if "structure" in h[RESERVED] else None
            nodes, problems = walk(h5py, np, h)
            if problems:
                # Content the signature cannot cover. Say whether the signature
                # itself is genuine, without reading any value.
                result.problems.extend(problems)
                _authenticate_single(envelope, list(public_keys), result)
                result.status = "tampered" if result.signature_valid else "invalid"
                return result
            verify_tree(PROFILE, nodes, envelope, stored, result, roots=roots,
                        public_keys=public_keys, at_time=at_time, timestamp_roots=timestamp_roots)
    except (KeyError, TypeError, ValueError, OSError, AttributeError, IndexError,
            UnicodeDecodeError, UnsupportedAlgorithm, _m.EnvelopeError) as exc:
        result.problems.append(f"malformed signed HDF5: {type(exc).__name__}: {exc}")
        if result.status in ("valid", "metadata-modified"):
            result.status = "tampered" if result.signature_valid else "invalid"
    return result
