"""Local file-system hygiene: find executables, write outputs.

Two habits of the standard library are hijack vectors when framesig runs in a
directory somebody else can write to (a shared beamline data directory, a
download folder):

* On Windows, ``shutil.which("pwsh")`` and ``subprocess.run(["git", ...])``
  look in the *current directory* before PATH, so a ``git.exe`` dropped next
  to the frames runs as the user who signs them.
* ``Path.write_bytes`` and ``open(path, "w")`` follow a symlink or write
  through a hardlink planted under the output name, so a sidecar or key file
  can be redirected onto any file the user can write.
"""

from __future__ import annotations

import contextlib
import os
import stat
import tempfile
from typing import BinaryIO, Iterator, Optional

__all__ = ["find_executable", "atomic_write", "replacing"]


def find_executable(name: str) -> Optional[str]:
    """``shutil.which`` without the current directory or relative PATH entries.

    Windows looks for ``name.exe`` only: a planted ``.bat``/``.cmd`` would run
    through ``cmd.exe`` with its own quoting rules.
    """
    exe = name + (".exe" if os.name == "nt" else "")
    for d in os.environ.get("PATH", "").split(os.pathsep):
        p = os.path.join(d, exe)
        if os.path.isabs(d) and os.path.isfile(p) and os.access(p, os.X_OK):
            return p
    return None


def _target_mode(path: str) -> int:
    """Keep the mode of a file we own that is being replaced; else umask default."""
    try:
        st = os.lstat(path)
        if stat.S_ISREG(st.st_mode) and getattr(os, "getuid", lambda: st.st_uid)() == st.st_uid:
            return st.st_mode & 0o777
    except FileNotFoundError:
        pass
    umask = os.umask(0)  # ponytail: process-wide read; fine outside threaded writers
    os.umask(umask)
    return 0o666 & ~umask


@contextlib.contextmanager
def _fresh(path, mode: Optional[int]) -> Iterator[tuple]:
    path = os.fspath(path)
    if os.path.islink(path):
        raise FileExistsError(f"refusing to write through the symbolic link {path}")
    # mkstemp: O_CREAT|O_EXCL (|O_NOFOLLOW), mode 0600, in the target's own
    # directory so os.replace stays a rename on one volume.
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(os.path.abspath(path)),
                               prefix=".framesig-", suffix=".tmp")
    mode = _target_mode(path) if mode is None else mode
    try:
        # By descriptor, before the caller closes it: a chmod by name would
        # follow a link another user swapped in for tmp (non-sticky directory)
        # and loosen the mode of whatever it points at. Windows sets only the
        # read-only bit, and only after the writes it would block.
        if os.name != "nt":
            os.fchmod(fd, mode)
        yield fd, tmp
        if os.name == "nt":
            os.chmod(tmp, mode)
        os.replace(tmp, path)  # replaces a planted hardlink/symlink, never writes through it
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def atomic_write(path, data: bytes, mode: Optional[int] = None) -> None:
    """Write *data* to *path* as a new file, then rename it into place.

    Refuses a symlink at *path*; breaks a hardlink rather than writing through
    it; a crash leaves the old file, never half a new one.
    """
    with _fresh(path, mode) as (fd, _):
        with os.fdopen(fd, "wb") as fh:  # file object: os.write may write short
            fh.write(data)


@contextlib.contextmanager
def replacing(path, mode: Optional[int] = None) -> Iterator[BinaryIO]:
    """Yield the fresh temp file, open ``w+b``, for writers that take a file
    object (h5py, zipfile); on success it replaces *path*.

    A file object rather than the temp name: a writer that reopened the name
    could, in a directory where another user may delete files (non-sticky,
    group-writable), be handed a file swapped in after mkstemp.
    """
    with _fresh(path, mode) as (fd, _):
        with os.fdopen(fd, "w+b") as fh:  # closed before the rename: Windows needs it
            yield fh
