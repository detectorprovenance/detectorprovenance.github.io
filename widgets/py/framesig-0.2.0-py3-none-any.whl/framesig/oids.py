"""Object identifiers, and the one number that has to be registered.

Why this is its own module
--------------------------

An assurance claim is only meaningful if everybody means the same thing by it.
A verifier that meets a detector vendor for the first time has to recognise
"this key is inside the instrument" from the certificate alone, which means the
identifier for that claim must be globally unique. Object identifiers are how
X.509 does that, and uniqueness comes from IANA delegating an arc.

**An unregistered OID that later collides is worse than no OID at all**, and
this project has already proved it the hard way: the first implementation used
``1.3.6.1.4.1.62630`` as a placeholder, which turns out to be registered to
White Castle. A verifier honouring that arc would have been honouring a
hamburger chain's namespace.

So the placeholder is now ``1.3.6.1.4.1.32473``, which RFC 5612 reserves
permanently for documentation and examples. It cannot collide with anyone,
because it is nobody's; and its presence in a real certificate is
self-documenting as "this deployment has not registered an arc yet", which
:func:`describe_pen` turns into a visible warning rather than a silent
assumption.

Going to production
-------------------

1. Apply for a Private Enterprise Number at
   https://www.iana.org/assignments/enterprise-numbers/assignment/apply/ --
   free, first-come-first-served, reviewed manually (RFC 9371). See
   ``docs/OIDS.md`` for the exact application text.
2. Set :data:`ACTIVE_PEN` to the assigned number.
3. Leave the old number in :data:`RECOGNISED_PENS` for as long as certificates
   issued under it are still in the field.

The arc
-------

::

    1.3.6.1.4.1.<PEN>.1          framesig
    1.3.6.1.4.1.<PEN>.1.1        certificate policies
    1.3.6.1.4.1.<PEN>.1.1.1        instrument attestation
    1.3.6.1.4.1.<PEN>.1.1.2        custodial key
    1.3.6.1.4.1.<PEN>.1.1.3        timestamp authority policy
    1.3.6.1.4.1.<PEN>.1.2        certificate extensions   (reserved)
    1.3.6.1.4.1.<PEN>.1.3        attestation vocabularies (reserved)

Sub-arcs are reserved rather than used, because retrofitting structure onto a
flat namespace once identifiers are in the field is not possible.
"""

from __future__ import annotations

from typing import Iterable, List, Optional, Sequence, Tuple

__all__ = [
    "DOCUMENTATION_PEN",
    "ACTIVE_PEN",
    "RECOGNISED_PENS",
    "IANA_APPLY_URL",
    "arc",
    "instrument_attestation_oid",
    "custodial_oid",
    "timestamp_policy_oid",
    "all_instrument_oids",
    "all_custodial_oids",
    "classify_policies",
    "is_provisional",
    "describe_pen",
    "PROVISIONAL_WARNING",
]

#: RFC 5612 reserves this permanently for documentation and examples, so it can
#: never collide with a real organisation's arc.
DOCUMENTATION_PEN = 32473

#: **Change this one number after registration, and nothing else.**
ACTIVE_PEN = DOCUMENTATION_PEN

#: Arcs a verifier accepts. During a migration this holds the new number *and*
#: the old one, so certificates already in the field keep working; drop the old
#: entry only once none remain valid. Order is significant only for reporting.
RECOGNISED_PENS: Tuple[int, ...] = (ACTIVE_PEN,)

IANA_APPLY_URL = "https://www.iana.org/assignments/enterprise-numbers/assignment/apply/"

PROVISIONAL_WARNING = (
    "the certificate's policy OID is under the RFC 5612 documentation arc "
    f"(1.3.6.1.4.1.{DOCUMENTATION_PEN}), which is reserved for examples and is "
    "not a registered namespace; a production deployment needs its own IANA "
    "Private Enterprise Number"
)


def arc(pen: Optional[int] = None) -> str:
    """The framesig arc under a given Private Enterprise Number."""
    return f"1.3.6.1.4.1.{ACTIVE_PEN if pen is None else pen}.1"


def _policies_arc(pen: Optional[int] = None) -> str:
    return arc(pen) + ".1"


def instrument_attestation_oid(pen: Optional[int] = None) -> str:
    """The manufacturer's assertion that the key lives inside the instrument.

    A verifier cannot check this cryptographically -- it takes the
    manufacturer's word, which is the point: a certificate policy is how a
    CA becomes answerable for a statement it cannot prove.
    """
    return _policies_arc(pen) + ".1"


def custodial_oid(pen: Optional[int] = None) -> str:
    """Explicitly *not* an instrument attestation: a software- or facility-held
    key. Present so a custodial signer can say so rather than staying silent and
    being mistaken for one."""
    return _policies_arc(pen) + ".2"


def timestamp_policy_oid(pen: Optional[int] = None) -> str:
    """The policy a framesig timestamp authority stamps into its tokens.

    RFC 3161 requires every token to name the policy it was issued under, so
    that "what does this TSA promise about its clock" is answerable from the
    token rather than from a web page that may not outlive the data.
    """
    return _policies_arc(pen) + ".3"


def all_instrument_oids() -> List[str]:
    return [instrument_attestation_oid(p) for p in RECOGNISED_PENS]


def all_custodial_oids() -> List[str]:
    return [custodial_oid(p) for p in RECOGNISED_PENS]


def is_provisional(pen: int) -> bool:
    return pen == DOCUMENTATION_PEN


def classify_policies(policy_oids: Iterable[str]) -> Tuple[Optional[str], Optional[int]]:
    """Map a certificate's policy OIDs to ``(kind, pen)``.

    ``kind`` is ``"instrument"``, ``"custodial"`` or ``None``. Only arcs listed
    in :data:`RECOGNISED_PENS` are honoured: an OID that merely *looks* like a
    framesig policy but sits under somebody else's enterprise number means
    nothing here, and treating it as equivalent is how namespaces get quietly
    squatted.
    """
    policies = set(policy_oids)
    for pen in RECOGNISED_PENS:
        if instrument_attestation_oid(pen) in policies:
            return "instrument", pen
    for pen in RECOGNISED_PENS:
        if custodial_oid(pen) in policies:
            return "custodial", pen
    return None, None


def describe_pen(pen: Optional[int]) -> Optional[str]:
    """A warning to surface alongside a policy, or None if the arc is real."""
    if pen is not None and is_provisional(pen):
        return PROVISIONAL_WARNING
    return None


def registry() -> Sequence[Tuple[str, str]]:
    """Every identifier this project defines, for ``docs/OIDS.md`` and tests."""
    return (
        (arc(), "framesig"),
        (_policies_arc(), "certificate policies"),
        (instrument_attestation_oid(), "instrument attestation"),
        (custodial_oid(), "custodial key"),
        (timestamp_policy_oid(), "timestamp authority policy"),
        (arc() + ".2", "certificate extensions (reserved)"),
        (arc() + ".3", "attestation vocabularies (reserved)"),
    )
