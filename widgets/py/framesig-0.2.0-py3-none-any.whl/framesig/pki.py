"""X.509 handling: a demo CA, and chain validation for verifiers.

The long-term trust model is the one TLS uses, with the roles renamed:

    vendor root CA  ->  vendor issuing CA  ->  detector unit certificate

The detector's private key never leaves its secure element.  The unit
certificate binds that key to a serial number and is signed by the vendor, who
publishes the root.  A verifier then needs nothing from the network except the
vendor root -- everything else travels inside the frame.

For the software proof of concept the same structure is used with software
keys, so that the code path exercised in the PoC is the code path that will
run against real hardware.

Scope limits of :func:`verify_chain`, stated rather than implied:

* no name constraints, no certificate policies, no path-length enforcement
  beyond basicConstraints CA:TRUE;
* no revocation checking (CRL/OCSP) -- see ``docs/DESIGN.md`` for why that
  matters and what replaces it in the interim (RFC 3161 timestamps);
* no cross-certificate or alternative-path search: the chain must be linear.

It is a deliberately small, readable implementation, not a general PKI stack.
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from typing import List, Optional, Sequence

from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, ed25519
from cryptography.x509.oid import NameOID

from .keys import public_key_bytes

__all__ = [
    "ChainResult",
    "verify_chain",
    "make_root_ca",
    "make_intermediate_ca",
    "make_device_certificate",
    "make_device_ca_certificate",
    "make_state_certificate",
    "load_certificates_pem",
    "certificate_der",
    "subject_string",
]


def _not_before(cert: x509.Certificate) -> _dt.datetime:
    try:
        return cert.not_valid_before_utc
    except AttributeError:  # cryptography < 42
        return cert.not_valid_before.replace(tzinfo=_dt.timezone.utc)


def _not_after(cert: x509.Certificate) -> _dt.datetime:
    try:
        return cert.not_valid_after_utc
    except AttributeError:  # cryptography < 42
        return cert.not_valid_after.replace(tzinfo=_dt.timezone.utc)


def subject_string(cert: x509.Certificate) -> str:
    return cert.subject.rfc4514_string()


def certificate_der(cert: x509.Certificate) -> bytes:
    from cryptography.hazmat.primitives.serialization import Encoding

    return cert.public_bytes(Encoding.DER)


def load_certificates_pem(data: bytes) -> List[x509.Certificate]:
    return list(x509.load_pem_x509_certificates(data))


# --------------------------------------------------------------------------
# validation
# --------------------------------------------------------------------------

@dataclass
class ChainResult:
    ok: bool
    reason: Optional[str] = None
    chain: List[str] = field(default_factory=list)
    root_subject: Optional[str] = None


def _cert_signature_ok(cert: x509.Certificate, issuer_public_key) -> bool:
    try:
        if isinstance(issuer_public_key, ed25519.Ed25519PublicKey):
            issuer_public_key.verify(cert.signature, cert.tbs_certificate_bytes)
        elif isinstance(issuer_public_key, ec.EllipticCurvePublicKey):
            algo = cert.signature_hash_algorithm or hashes.SHA256()
            issuer_public_key.verify(cert.signature, cert.tbs_certificate_bytes, ec.ECDSA(algo))
        else:
            return False
        return True
    except Exception:
        return False


def _path_length(cert: x509.Certificate) -> Optional[int]:
    """``pathLenConstraint``, or None when unconstrained."""
    try:
        return cert.extensions.get_extension_for_class(x509.BasicConstraints).value.path_length
    except x509.ExtensionNotFound:
        return None


def _is_ca(cert: x509.Certificate) -> bool:
    try:
        bc = cert.extensions.get_extension_for_class(x509.BasicConstraints).value
    except x509.ExtensionNotFound:
        return False
    return bool(bc.ca)


def verify_chain(
    leaf: x509.Certificate,
    intermediates: Sequence[x509.Certificate],
    roots: Sequence[x509.Certificate],
    at_time: Optional[_dt.datetime] = None,
) -> ChainResult:
    """Walk from *leaf* to a certificate in *roots*.

    *at_time* is the instant the chain must have been valid at.  Passing the
    signature's timestamp rather than "now" is what lets an old frame stay
    verifiable after the detector certificate has expired -- see
    ``docs/DESIGN.md`` on long-lived data.
    """
    if at_time is None:
        at_time = _dt.datetime.now(_dt.timezone.utc)
    if at_time.tzinfo is None:
        at_time = at_time.replace(tzinfo=_dt.timezone.utc)

    by_subject = {}
    for c in list(intermediates) + list(roots):
        by_subject.setdefault(c.subject, []).append(c)
    root_set = {certificate_der(c) for c in roots}

    chain: List[x509.Certificate] = [leaf]
    current = leaf
    for _ in range(8):  # depth guard
        if not (_not_before(current) <= at_time <= _not_after(current)):
            return ChainResult(
                False,
                f"certificate {subject_string(current)!r} not valid at {at_time.isoformat()} "
                f"(valid {_not_before(current).isoformat()} .. {_not_after(current).isoformat()})",
                [subject_string(c) for c in chain],
            )

        if certificate_der(current) in root_set:
            return ChainResult(
                True,
                None,
                [subject_string(c) for c in chain],
                subject_string(current),
            )

        candidates = by_subject.get(current.issuer, [])
        issuer = None
        for cand in candidates:
            if not _is_ca(cand):
                continue
            if _cert_signature_ok(current, cand.public_key()):
                issuer = cand
                break
        if issuer is not None:
            # basicConstraints pathLenConstraint: how many CAs may still appear
            # *below* this one. Enforced because the three-layer hierarchy
            # (vendor -> device -> state) depends on it to stop a device
            # certificate minting a whole sub-hierarchy of its own. Skipping the
            # check would make our verifier accept chains that OpenSSL rejects,
            # which is the worst of both: frames that pass here and fail at a
            # referee's desk.
            limit = _path_length(issuer)
            below = sum(1 for c in chain if _is_ca(c))
            if limit is not None and below > limit:
                return ChainResult(
                    False,
                    f"{subject_string(issuer)!r} permits {limit} CA(s) beneath it "
                    f"but the chain presents {below}",
                    [subject_string(c) for c in chain],
                )
        if issuer is None:
            return ChainResult(
                False,
                f"no trusted issuer found for {subject_string(current)!r} "
                f"(issuer {current.issuer.rfc4514_string()!r})",
                [subject_string(c) for c in chain],
            )
        chain.append(issuer)
        current = issuer

    return ChainResult(False, "certificate chain too long", [subject_string(c) for c in chain])


# --------------------------------------------------------------------------
# demo CA -- enough to model vendor -> detector, not a production CA
# --------------------------------------------------------------------------

def _name(cn: str, org: str, ou: Optional[str] = None) -> x509.Name:
    parts = [
        x509.NameAttribute(NameOID.COMMON_NAME, cn),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, org),
    ]
    if ou:
        parts.append(x509.NameAttribute(NameOID.ORGANIZATIONAL_UNIT_NAME, ou))
    return x509.Name(parts)


def _sign_cert(builder: x509.CertificateBuilder, issuer_key) -> x509.Certificate:
    if isinstance(issuer_key, ed25519.Ed25519PrivateKey):
        return builder.sign(issuer_key, None)
    return builder.sign(issuer_key, hashes.SHA256())


def _base_builder(subject, issuer, public_key, days, serial=None):
    now = _dt.datetime.now(_dt.timezone.utc)
    return (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(public_key)
        .serial_number(serial or x509.random_serial_number())
        .not_valid_before(now - _dt.timedelta(minutes=5))
        .not_valid_after(now + _dt.timedelta(days=days))
    )


def make_root_ca(private_key, common_name: str, org: str, days: int = 7300) -> x509.Certificate:
    subject = _name(common_name, org)
    pub = private_key.public_key()
    builder = (
        _base_builder(subject, subject, pub, days)
        .add_extension(x509.BasicConstraints(ca=True, path_length=2), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=False, content_commitment=False, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=True,
                crl_sign=True, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(pub), critical=False)
    )
    return _sign_cert(builder, private_key)


def make_intermediate_ca(
    ca_key, ca_cert: x509.Certificate, private_key, common_name: str, org: str, days: int = 3650
) -> x509.Certificate:
    pub = private_key.public_key()
    builder = (
        _base_builder(_name(common_name, org), ca_cert.subject, pub, days)
        .add_extension(x509.BasicConstraints(ca=True, path_length=1), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=False, content_commitment=False, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=True,
                crl_sign=True, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(pub), critical=False)
    )
    return _sign_cert(builder, ca_key)


def make_device_certificate(
    ca_key,
    ca_cert: x509.Certificate,
    public_key,
    serial_number: str,
    model: str,
    org: str,
    days: int = 3650,
    instrument_attested: bool = False,
) -> x509.Certificate:
    """A detector unit certificate: CN is the unit serial, OU the model.

    ``instrument_attested`` stamps the certificate policy that says "this key is
    inside the instrument's secure element and was provisioned during
    manufacture". It is the single assertion that separates a signature worth
    something from one a fabricator could also produce, so it is opt-in and
    never inferred: a manufacturer has to state it deliberately, and is then
    answerable for it.
    """
    from .oids import custodial_oid, instrument_attestation_oid

    policy_oid = instrument_attestation_oid() if instrument_attested else custodial_oid()
    builder = (
        _base_builder(_name(serial_number, org, ou=model), ca_cert.subject, public_key, days)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            x509.CertificatePolicies([
                x509.PolicyInformation(
                    x509.ObjectIdentifier(policy_oid), policy_qualifiers=None
                )
            ]),
            critical=False,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, content_commitment=True, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=False,
                crl_sign=False, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(public_key), critical=False)
    )
    return _sign_cert(builder, ca_key)


def make_device_ca_certificate(
    ca_key,
    ca_cert: x509.Certificate,
    public_key,
    serial_number: str,
    model: str,
    org: str,
    days: int = 7300,
    instrument_attested: bool = True,
) -> x509.Certificate:
    """The device's permanent identity, which issues state certificates.

    Layer 2 of the vendor / device / state hierarchy, and IEEE 802.1AR calls it
    an **IDevID**: installed at manufacture, keyed to the serial number, never
    replaced for the life of the unit.

    Unlike :func:`make_device_certificate` this is a CA, so it does **not** sign
    frames -- ``api.check_signing_certificates`` refuses a CA certificate as a
    signing leaf, which is the behaviour we want. Its one job is to issue the
    state certificates of :func:`make_state_certificate`, and ``path_length=0``
    stops it minting a sub-hierarchy of its own.

    The payoff is operational: because the *device* issues them, a service
    engineer can re-key a repaired detector without the vendor being reachable.
    A scheme that requires phoning the manufacturer after every repair is a
    scheme that gets skipped.

    It is deliberately longer-lived than the state certificates beneath it: this
    one has to outlast every repair the unit will ever see.
    """
    from .oids import custodial_oid, instrument_attestation_oid

    policy_oid = instrument_attestation_oid() if instrument_attested else custodial_oid()
    builder = (
        _base_builder(_name(serial_number, org, ou=model), ca_cert.subject, public_key, days)
        .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
        .add_extension(
            x509.CertificatePolicies([
                x509.PolicyInformation(
                    x509.ObjectIdentifier(policy_oid), policy_qualifiers=None
                )
            ]),
            critical=False,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=False, content_commitment=False, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=True,
                crl_sign=True, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(public_key), critical=False)
    )
    return _sign_cert(builder, ca_key)


def make_state_certificate(
    device_key,
    device_cert: x509.Certificate,
    public_key,
    state_id: str,
    org: str,
    days: int = 1825,
    instrument_attested: bool = True,
) -> x509.Certificate:
    """The key that actually signs frames, scoped to one configuration epoch.

    Layer 3, and 802.1AR's **LDevID**. Re-issued whenever the instrument
    materially changes -- sensor swap, board replacement, firmware update,
    recalibration -- so that a frame is attributable to a *configuration* and
    not merely to a serial number.

    Three things that buys, worth keeping separate:

    * a sensor swap changes the flat-field, the gain map and the dead-pixel map,
      so "which detector, in which state" is a materially stronger statement
      than "which detector";
    * a leaked state key calls one epoch into question rather than the whole
      service life of the instrument;
    * **the epoch becomes self-identifying.** Without this, working out which
      configuration produced a frame means inferring it from a signing date and
      a service log. With it, the signing key *is* the answer -- which needs no
      trusted clock, and so survives the absence of a timestamp authority.

    ``state_id`` should name the epoch in a way a service record can be matched
    against: a monotonically increasing counter, or a firmware version plus a
    service date. It goes in the CN, beneath the device's serial in the chain,
    so the inventory and the revocation machinery already see it as a distinct
    identity without any further work.
    """
    from .oids import custodial_oid, instrument_attestation_oid

    policy_oid = instrument_attestation_oid() if instrument_attested else custodial_oid()
    serial_cn = device_cert.subject.rfc4514_string()
    builder = (
        _base_builder(_name(state_id, org, ou=_common_name(device_cert) or serial_cn),
                      device_cert.subject, public_key, days)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            x509.CertificatePolicies([
                x509.PolicyInformation(
                    x509.ObjectIdentifier(policy_oid), policy_qualifiers=None
                )
            ]),
            critical=False,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, content_commitment=True, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=False,
                crl_sign=False, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(public_key), critical=False)
    )
    return _sign_cert(builder, device_key)


def _common_name(cert: x509.Certificate) -> Optional[str]:
    values = cert.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
    return str(values[0].value) if values else None


def public_key_matches(cert: x509.Certificate, public_key) -> bool:
    return public_key_bytes(cert.public_key()) == public_key_bytes(public_key)
