"""X.509 handling: a demo CA, and chain validation for verifiers.

The long-term trust model is the one TLS uses, with the roles renamed:

    vendor root CA  ->  vendor issuing CA  ->  detector unit certificate

The detector's private key never leaves its secure element.  The unit
certificate binds that key to a serial number and is signed by the vendor, who
publishes the root.  A verifier then needs nothing from the network except the
vendor root -- everything else travels inside the frame.

For the software proof of concept the same structure is used with software
keys, so that the code path exercised in the PoC is the code path that will
run against real hardware.

What :func:`verify_chain` enforces: signatures, validity at the instant asked
about, basicConstraints CA and pathLenConstraint, keyUsage (keyCertSign on every
issuer, the caller's purpose on the leaf), nameConstraints for directoryName,
dNSName, rfc822Name and URI (any other form fails the chain closed), refusal of
any unrecognised critical extension, and a bounded search over alternative
issuers (key rollover, cross-certificates).

Scope limits, stated rather than implied:

* no RFC 5280 policy tree. Certificate policies are read off the leaf by
  :func:`framesig.oids.classify_policies`; policy mappings, policy constraints
  and inhibitAnyPolicy are not processed, so a certificate marking one of them
  critical is refused;
* no revocation checking here. Withdrawal is a separate, signed list
  (:mod:`framesig.revocation`); a certificate may name where its issuer
  publishes that list (``crl_url``, read back by :func:`crl_urls`), which
  :mod:`framesig.online` fetches only when asked to.

It is a deliberately small, readable implementation, not a general PKI stack.
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from typing import List, Optional, Sequence
from urllib.parse import urlsplit

from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, ed25519
from cryptography.x509.oid import ExtendedKeyUsageOID, ExtensionOID, NameOID

from .keys import public_key_bytes

__all__ = [
    "ChainResult",
    "verify_chain",
    "make_root_ca",
    "make_intermediate_ca",
    "make_device_certificate",
    "make_device_ca_certificate",
    "make_state_certificate",
    "load_certificates_pem",
    "certificate_der",
    "subject_string",
    "crl_urls",
]


def _not_before(cert: x509.Certificate) -> _dt.datetime:
    try:
        return cert.not_valid_before_utc
    except AttributeError:  # cryptography < 42
        return cert.not_valid_before.replace(tzinfo=_dt.timezone.utc)


def _not_after(cert: x509.Certificate) -> _dt.datetime:
    try:
        return cert.not_valid_after_utc
    except AttributeError:  # cryptography < 42
        return cert.not_valid_after.replace(tzinfo=_dt.timezone.utc)


def subject_string(cert: x509.Certificate) -> str:
    return cert.subject.rfc4514_string()


def certificate_der(cert: x509.Certificate) -> bytes:
    from cryptography.hazmat.primitives.serialization import Encoding

    return cert.public_bytes(Encoding.DER)


def load_certificates_pem(data: bytes) -> List[x509.Certificate]:
    return list(x509.load_pem_x509_certificates(data))


# --------------------------------------------------------------------------
# validation
# --------------------------------------------------------------------------

@dataclass
class ChainResult:
    ok: bool
    reason: Optional[str] = None
    chain: List[str] = field(default_factory=list)
    root_subject: Optional[str] = None


def _cert_signature_ok(cert: x509.Certificate, issuer: x509.Certificate) -> bool:
    """Did *issuer*'s key sign *cert*? False, never an exception, on hostile input."""
    try:
        issuer_public_key = issuer.public_key()  # raises on an unsupported key type
        if isinstance(issuer_public_key, ed25519.Ed25519PublicKey):
            issuer_public_key.verify(cert.signature, cert.tbs_certificate_bytes)
        elif isinstance(issuer_public_key, ec.EllipticCurvePublicKey):
            algo = cert.signature_hash_algorithm or hashes.SHA256()
            issuer_public_key.verify(cert.signature, cert.tbs_certificate_bytes, ec.ECDSA(algo))
        else:
            return False
        return True
    except Exception:
        return False


#: Bounds on path building. A file carries its own intermediates, so the
#: candidate pool is attacker-chosen: the depth caps how long a path may get,
#: and the budget caps how many issuer candidates are tried across *all*
#: alternative paths, so a pile of same-subject certificates or a loop of
#: cross-certificates costs a bounded number of signature checks.
MAX_CHAIN_DEPTH = 8
MAX_ISSUER_CANDIDATES = 64

#: Extensions :func:`verify_chain` acts on. Any other extension marked critical
#: makes the certificate unusable (RFC 5280 §4.2): its issuer said "do not rely
#: on me if you do not understand this", so we do not. That includes the policy
#: processing extensions (policyMappings, policyConstraints, inhibitAnyPolicy),
#: which are out of scope. extendedKeyUsage is handled separately: a critical
#: one is understood on the leaf only, against the purpose the caller names.
_UNDERSTOOD_CRITICAL = {
    ExtensionOID.BASIC_CONSTRAINTS,
    ExtensionOID.KEY_USAGE,
    ExtensionOID.NAME_CONSTRAINTS,
    ExtensionOID.SUBJECT_ALTERNATIVE_NAME,  # read by name constraints
    ExtensionOID.CERTIFICATE_POLICIES,  # read by attestation.classify_policies
    ExtensionOID.SUBJECT_KEY_IDENTIFIER,
    ExtensionOID.AUTHORITY_KEY_IDENTIFIER,
    ExtensionOID.CRL_DISTRIBUTION_POINTS,
}

#: Name-constraint forms evaluated. A constraint of any other form (IP address,
#: otherName, registeredID, ...) fails the chain closed rather than being skipped.
_NC_TYPES = (x509.DirectoryName, x509.DNSName, x509.RFC822Name, x509.UniformResourceIdentifier)


@dataclass
class _Cert:
    """One certificate with everything validation reads, parsed once, up front.

    Parsing a hostile certificate's extensions can raise; doing it here means
    the failure becomes a reported problem instead of escaping mid-walk.
    """

    cert: x509.Certificate
    der: bytes
    name: str
    subject: x509.Name
    issuer: x509.Name
    not_before: _dt.datetime
    not_after: _dt.datetime
    exts: x509.Extensions

    def ext(self, cls):
        try:
            return self.exts.get_extension_for_class(cls)
        except x509.ExtensionNotFound:
            return None

    @property
    def is_ca(self) -> bool:
        bc = self.ext(x509.BasicConstraints)
        return bool(bc and bc.value.ca)

    @property
    def self_issued(self) -> bool:
        return self.subject == self.issuer


def _parse(cert: x509.Certificate):
    """A :class:`_Cert`, or a string saying why the certificate cannot be read."""
    try:
        return _Cert(cert, certificate_der(cert), subject_string(cert), cert.subject,
                     cert.issuer, _not_before(cert), _not_after(cert), cert.extensions)
    except Exception as exc:  # noqa: BLE001 - malformed DER is data, not a crash
        return f"a certificate in the chain cannot be parsed: {exc}"


def _dn_parts(name: x509.Name) -> list:
    # ponytail: case-folded, whitespace-collapsed values, not full RFC 4518
    # string preparation; enough that a case variant cannot dodge an exclusion.
    return [frozenset((a.oid.dotted_string, " ".join(str(a.value).split()).casefold())
                      for a in rdn) for rdn in name.rdns]


def _host_in(host: str, constraint: str) -> bool:
    """RFC 5280 host matching: ``.example.org`` means any subdomain, else exact."""
    host, constraint = host.lower().rstrip("."), constraint.lower()
    if constraint.startswith("."):
        return host.endswith(constraint)
    return host == constraint


def _name_in(name: x509.GeneralName, subtree: x509.GeneralName) -> Optional[bool]:
    """Is *name* inside *subtree*? None when the two are of different forms."""
    if type(name) is not type(subtree):
        return None
    if isinstance(name, x509.DirectoryName):
        prefix = _dn_parts(subtree.value)
        return _dn_parts(name.value)[:len(prefix)] == prefix
    if isinstance(name, x509.DNSName):
        # dNSName: the constraint plus zero or more labels on the left.
        host, c = name.value.lower().rstrip("."), subtree.value.lower().lstrip(".")
        return not c or host == c or host.endswith("." + c)
    # A mailbox without "@" or a URI without a host cannot be placed in or out
    # of a subtree; "not inside" would let it slip past an exclusion, so raise
    # and let the caller refuse the chain.
    if isinstance(name, x509.RFC822Name):
        if "@" not in name.value:
            raise ValueError(f"{name.value!r} is not a mailbox")
        if "@" in subtree.value:
            return name.value.casefold() == subtree.value.casefold()
        return _host_in(name.value.rpartition("@")[2], subtree.value)
    host = urlsplit(name.value).hostname  # UniformResourceIdentifier
    if not host:
        raise ValueError(f"{name.value!r} has no host")
    return _host_in(host, subtree.value)


def _names_of(c: _Cert) -> list:
    """Every name a certificate asserts, as general names."""
    names = [x509.DirectoryName(c.subject)] if c.subject.rdns else []
    names += [x509.RFC822Name(str(a.value))
              for a in c.subject.get_attributes_for_oid(NameOID.EMAIL_ADDRESS)]
    san = c.ext(x509.SubjectAlternativeName)
    return names + (list(san.value) if san else [])


def _name_constraint_problem(ca: _Cert, below: Sequence[_Cert]) -> Optional[str]:
    """Do the certificates *below* respect *ca*'s nameConstraints?"""
    nc = ca.ext(x509.NameConstraints)
    if nc is None:
        return None
    permitted = list(nc.value.permitted_subtrees or [])
    excluded = list(nc.value.excluded_subtrees or [])
    for subtree in permitted + excluded:
        if not isinstance(subtree, _NC_TYPES):
            return (f"{ca.name!r} carries a name constraint of a form framesig does not "
                    f"evaluate ({type(subtree).__name__}), so the chain is refused rather "
                    "than the constraint ignored")
    for c in below:
        for name in _names_of(c):
            if any(_name_in(name, s) for s in excluded):
                return f"{c.name!r} asserts {name.value!r}, which {ca.name!r} excludes"
            allowed = [s for s in permitted if type(s) is type(name)]
            if allowed and not any(_name_in(name, s) for s in allowed):
                return (f"{c.name!r} asserts {name.value!r}, outside the names "
                        f"{ca.name!r} permits")
    return None


def _cert_problem(c: _Cert, at_time: _dt.datetime, is_leaf: bool) -> Optional[str]:
    """What rules a certificate out on its own, wherever it sits in a path."""
    for ext in c.exts:
        if ext.critical and ext.oid not in _UNDERSTOOD_CRITICAL and not (
                is_leaf and ext.oid == ExtensionOID.EXTENDED_KEY_USAGE):
            return (f"{c.name!r} carries a critical extension framesig does not "
                    f"process ({ext.oid.dotted_string}), so it may not be relied on")
    if not (c.not_before <= at_time <= c.not_after):
        return (f"certificate {c.name!r} not valid at {at_time.isoformat()} "
                f"(valid {c.not_before.isoformat()} .. {c.not_after.isoformat()})")
    return None


def _leaf_problem(c: _Cert, usage: Sequence[str], eku: Optional[str]) -> Optional[str]:
    """Is the end of the path allowed to do what the caller is checking it for?"""
    ku = c.ext(x509.KeyUsage)
    if ku is not None and not any(getattr(ku.value, bit) for bit in usage):
        return f"{c.name!r} does not permit {' or '.join(usage)} in its keyUsage"
    xku = c.ext(x509.ExtendedKeyUsage)
    if xku is not None and xku.critical:
        allowed = {o.dotted_string for o in xku.value}
        if not allowed & {eku, ExtendedKeyUsageOID.ANY_EXTENDED_KEY_USAGE.dotted_string}:
            return (f"{c.name!r} restricts its key to other purposes in a critical "
                    f"extendedKeyUsage ({', '.join(sorted(allowed))})")
    return None


def _issuer_problem(cand: _Cert, path: Sequence[_Cert]) -> Optional[str]:
    """May *cand* have issued ``path[-1]``, given everything below it?"""
    child = path[-1]
    if not cand.is_ca:
        return f"{cand.name!r} is not a CA certificate, so it cannot issue {child.name!r}"
    ku = cand.ext(x509.KeyUsage)
    if ku is not None and not ku.value.key_cert_sign:
        return f"{cand.name!r} does not permit keyCertSign, so it cannot issue certificates"
    if not _cert_signature_ok(child.cert, cand.cert):
        return f"the signature on {child.name!r} does not verify under {cand.name!r}"
    # basicConstraints pathLenConstraint: how many CAs may still appear *below*
    # this one, not counting the end of the path or self-issued (rollover)
    # certificates (RFC 5280 §6.1.4). The three-layer hierarchy (vendor ->
    # device -> state) depends on it to stop a device certificate minting a
    # whole sub-hierarchy of its own. Skipping the check would make our
    # verifier accept chains that OpenSSL rejects, which is the worst of both:
    # frames that pass here and fail at a referee's desk.
    bc = cand.ext(x509.BasicConstraints)
    limit = bc.value.path_length if bc else None
    below = sum(1 for c in path[1:] if not c.self_issued)
    if limit is not None and below > limit:
        return (f"{cand.name!r} permits {limit} CA(s) beneath it "
                f"but the chain presents {below}")
    try:
        return _name_constraint_problem(
            cand, [path[0]] + [c for c in path[1:] if not c.self_issued])
    except Exception as exc:  # noqa: BLE001 - a name we cannot read is not a pass
        return f"the names beneath {cand.name!r} cannot be checked against its constraints: {exc}"


def crl_urls(cert: x509.Certificate) -> List[str]:
    """HTTP(S) addresses the certificate's issuer publishes withdrawals at."""
    try:
        points = cert.extensions.get_extension_for_class(x509.CRLDistributionPoints).value
    except (x509.ExtensionNotFound, ValueError):
        return []
    return [name.value for point in points for name in (point.full_name or [])
            if isinstance(name, x509.UniformResourceIdentifier)
            and name.value.lower().startswith(("http://", "https://"))]


def verify_chain(
    leaf: x509.Certificate,
    intermediates: Sequence[x509.Certificate],
    roots: Sequence[x509.Certificate],
    at_time: Optional[_dt.datetime] = None,
    *,
    leaf_usage: Sequence[str] = ("digital_signature",),
    leaf_eku: Optional[str] = None,
) -> ChainResult:
    """Find a path from *leaf* to a certificate in *roots*.

    *at_time* is the instant the chain must have been valid at.  Passing the
    signature's timestamp rather than "now" is what lets an old frame stay
    verifiable after the detector certificate has expired -- see
    ``docs/DESIGN.md`` on long-lived data.

    *leaf_usage* names the keyUsage bits (any one suffices) the leaf must permit
    when it carries keyUsage: ``digital_signature`` for a frame signer,
    ``crl_sign`` for the CA a withdrawal list is checked under. *leaf_eku* is the
    one purpose a *critical* extendedKeyUsage on the leaf must include.

    When several certificates could have issued the same one (key rollover,
    cross-certificates, a reused subject), each is tried, depth-first, within
    :data:`MAX_CHAIN_DEPTH` and :data:`MAX_ISSUER_CANDIDATES`. If none leads to
    a root, the reason given is the one from the path that got furthest.
    """
    if at_time is None:
        at_time = _dt.datetime.now(_dt.timezone.utc)
    if at_time.tzinfo is None:
        at_time = at_time.replace(tzinfo=_dt.timezone.utc)

    start = _parse(leaf)
    if isinstance(start, str):
        return ChainResult(False, start)
    pool, root_set = {}, set()
    for i, cert in enumerate([*intermediates, *roots]):
        c = _parse(cert)
        if isinstance(c, str):
            continue  # an unreadable candidate is simply not an issuer
        if i >= len(intermediates):
            root_set.add(c.der)
        same = pool.setdefault(c.subject, [])
        if all(c.der != o.der for o in same):
            same.append(c)

    budget = [MAX_ISSUER_CANDIDATES]
    failure: List[ChainResult] = []

    def fail(path, reason):
        # The deepest failure is the informative one; ties keep the first.
        if not failure or len(path) > len(failure[0].chain):
            failure[:] = [ChainResult(False, reason, [c.name for c in path])]

    def walk(path: List[_Cert]) -> Optional[ChainResult]:
        current = path[-1]
        problem = _cert_problem(current, at_time, len(path) == 1)
        if problem:
            return fail(path, problem)
        if current.der in root_set:
            return ChainResult(True, None, [c.name for c in path], current.name)
        if len(path) >= MAX_CHAIN_DEPTH:
            return fail(path, "certificate chain too long")
        on_path = {c.der for c in path}  # a cross-certificate loop ends here
        candidates = [c for c in pool.get(current.issuer, []) if c.der not in on_path]
        if not candidates:
            return fail(path, f"no trusted issuer found for {current.name!r} "
                              f"(issuer {current.issuer.rfc4514_string()!r})")
        for cand in candidates:
            if budget[0] <= 0:
                # Overrides any deeper failure: the path that would have worked
                # may be among the candidates never tried, and that must show.
                failure[:] = [ChainResult(
                    False, f"gave up after trying {MAX_ISSUER_CANDIDATES} candidate "
                           "issuers without reaching a trusted root", [c.name for c in path])]
                return None
            budget[0] -= 1
            problem = _issuer_problem(cand, path)
            if problem:
                fail(path, problem)  # a refused candidate is no progress
                continue
            found = walk(path + [cand])
            if found:
                return found
        return None

    problem = _leaf_problem(start, leaf_usage, leaf_eku)
    if problem:
        return ChainResult(False, problem, [start.name])
    return walk([start]) or failure[0]


# --------------------------------------------------------------------------
# demo CA -- enough to model vendor -> detector, not a production CA
# --------------------------------------------------------------------------

def _name(cn: str, org: str, ou: Optional[str] = None) -> x509.Name:
    parts = [
        x509.NameAttribute(NameOID.COMMON_NAME, cn),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, org),
    ]
    if ou:
        parts.append(x509.NameAttribute(NameOID.ORGANIZATIONAL_UNIT_NAME, ou))
    return x509.Name(parts)


def _sign_cert(builder: x509.CertificateBuilder, issuer_key,
               crl_url: Optional[str] = None) -> x509.Certificate:
    if crl_url:
        # Where the *issuer* publishes its withdrawal list. It sits inside the
        # signed certificate, so a verifier never takes the address from the
        # file it is checking -- the issuer chose it when it signed.
        builder = builder.add_extension(x509.CRLDistributionPoints([
            x509.DistributionPoint([x509.UniformResourceIdentifier(crl_url)],
                                   None, None, None)]), critical=False)
    if isinstance(issuer_key, ed25519.Ed25519PrivateKey):
        return builder.sign(issuer_key, None)
    return builder.sign(issuer_key, hashes.SHA256())


def _base_builder(subject, issuer, public_key, days, serial=None):
    now = _dt.datetime.now(_dt.timezone.utc)
    return (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(public_key)
        .serial_number(serial or x509.random_serial_number())
        .not_valid_before(now - _dt.timedelta(minutes=5))
        .not_valid_after(now + _dt.timedelta(days=days))
    )


def make_root_ca(private_key, common_name: str, org: str, days: int = 7300) -> x509.Certificate:
    subject = _name(common_name, org)
    pub = private_key.public_key()
    builder = (
        _base_builder(subject, subject, pub, days)
        .add_extension(x509.BasicConstraints(ca=True, path_length=2), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=False, content_commitment=False, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=True,
                crl_sign=True, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(pub), critical=False)
    )
    return _sign_cert(builder, private_key)


def make_intermediate_ca(
    ca_key, ca_cert: x509.Certificate, private_key, common_name: str, org: str, days: int = 3650,
    crl_url: Optional[str] = None,
) -> x509.Certificate:
    pub = private_key.public_key()
    builder = (
        _base_builder(_name(common_name, org), ca_cert.subject, pub, days)
        .add_extension(x509.BasicConstraints(ca=True, path_length=1), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=False, content_commitment=False, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=True,
                crl_sign=True, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(pub), critical=False)
    )
    return _sign_cert(builder, ca_key, crl_url)


def make_device_certificate(
    ca_key,
    ca_cert: x509.Certificate,
    public_key,
    serial_number: str,
    model: str,
    org: str,
    days: int = 3650,
    instrument_attested: bool = False,
    crl_url: Optional[str] = None,
) -> x509.Certificate:
    """A detector unit certificate: CN is the unit serial, OU the model.

    ``instrument_attested`` stamps the certificate policy that says "this key is
    inside the instrument's secure element and was provisioned during
    manufacture". It is the single assertion that separates a signature worth
    something from one a fabricator could also produce, so it is opt-in and
    never inferred: a manufacturer has to state it deliberately, and is then
    answerable for it.
    """
    from .oids import custodial_oid, instrument_attestation_oid

    policy_oid = instrument_attestation_oid() if instrument_attested else custodial_oid()
    builder = (
        _base_builder(_name(serial_number, org, ou=model), ca_cert.subject, public_key, days)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            x509.CertificatePolicies([
                x509.PolicyInformation(
                    x509.ObjectIdentifier(policy_oid), policy_qualifiers=None
                )
            ]),
            critical=False,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, content_commitment=True, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=False,
                crl_sign=False, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(public_key), critical=False)
    )
    return _sign_cert(builder, ca_key, crl_url)


def make_device_ca_certificate(
    ca_key,
    ca_cert: x509.Certificate,
    public_key,
    serial_number: str,
    model: str,
    org: str,
    days: int = 7300,
    instrument_attested: bool = True,
    crl_url: Optional[str] = None,
) -> x509.Certificate:
    """The device's permanent identity, which issues state certificates.

    Layer 2 of the vendor / device / state hierarchy, and IEEE 802.1AR calls it
    an **IDevID**: installed at manufacture, keyed to the serial number, never
    replaced for the life of the unit.

    Unlike :func:`make_device_certificate` this is a CA, so it does **not** sign
    frames -- ``api.check_signing_certificates`` refuses a CA certificate as a
    signing leaf, which is the behaviour we want. Its one job is to issue the
    state certificates of :func:`make_state_certificate`, and ``path_length=0``
    stops it minting a sub-hierarchy of its own.

    The payoff is operational: because the *device* issues them, a service
    engineer can re-key a repaired detector without the vendor being reachable.
    A scheme that requires phoning the manufacturer after every repair is a
    scheme that gets skipped.

    It is deliberately longer-lived than the state certificates beneath it: this
    one has to outlast every repair the unit will ever see.
    """
    from .oids import custodial_oid, instrument_attestation_oid

    policy_oid = instrument_attestation_oid() if instrument_attested else custodial_oid()
    builder = (
        _base_builder(_name(serial_number, org, ou=model), ca_cert.subject, public_key, days)
        .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
        .add_extension(
            x509.CertificatePolicies([
                x509.PolicyInformation(
                    x509.ObjectIdentifier(policy_oid), policy_qualifiers=None
                )
            ]),
            critical=False,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=False, content_commitment=False, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=True,
                crl_sign=True, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(public_key), critical=False)
    )
    return _sign_cert(builder, ca_key, crl_url)


def make_state_certificate(
    device_key,
    device_cert: x509.Certificate,
    public_key,
    state_id: str,
    org: str,
    days: int = 1825,
    instrument_attested: bool = True,
    crl_url: Optional[str] = None,
) -> x509.Certificate:
    """The key that actually signs frames, scoped to one configuration epoch.

    Layer 3, and 802.1AR's **LDevID**. Re-issued whenever the instrument
    materially changes -- sensor swap, board replacement, firmware update,
    recalibration -- so that a frame is attributable to a *configuration* and
    not merely to a serial number.

    Three things that buys, worth keeping separate:

    * a sensor swap changes the flat-field, the gain map and the dead-pixel map,
      so "which detector, in which state" is a materially stronger statement
      than "which detector";
    * a leaked state key calls one epoch into question rather than the whole
      service life of the instrument;
    * **the epoch becomes self-identifying.** Without this, working out which
      configuration produced a frame means inferring it from a signing date and
      a service log. With it, the signing key *is* the answer -- which needs no
      trusted clock, and so survives the absence of a timestamp authority.

    ``state_id`` should name the epoch in a way a service record can be matched
    against: a monotonically increasing counter, or a firmware version plus a
    service date. It goes in the CN, beneath the device's serial in the chain,
    so the inventory and the revocation machinery already see it as a distinct
    identity without any further work.
    """
    from .oids import custodial_oid, instrument_attestation_oid

    policy_oid = instrument_attestation_oid() if instrument_attested else custodial_oid()
    serial_cn = device_cert.subject.rfc4514_string()
    builder = (
        _base_builder(_name(state_id, org, ou=_common_name(device_cert) or serial_cn),
                      device_cert.subject, public_key, days)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            x509.CertificatePolicies([
                x509.PolicyInformation(
                    x509.ObjectIdentifier(policy_oid), policy_qualifiers=None
                )
            ]),
            critical=False,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, content_commitment=True, key_encipherment=False,
                data_encipherment=False, key_agreement=False, key_cert_sign=False,
                crl_sign=False, encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(public_key), critical=False)
    )
    return _sign_cert(builder, device_key, crl_url)


def _common_name(cert: x509.Certificate) -> Optional[str]:
    values = cert.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
    return str(values[0].value) if values else None


def public_key_matches(cert: x509.Certificate, public_key) -> bool:
    return public_key_bytes(cert.public_key()) == public_key_bytes(public_key)
